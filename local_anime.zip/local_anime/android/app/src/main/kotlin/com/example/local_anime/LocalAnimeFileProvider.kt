package com.example.local_anime

import androidx.core.content.FileProvider

class LocalAnimeFileProvider : FileProvider()
