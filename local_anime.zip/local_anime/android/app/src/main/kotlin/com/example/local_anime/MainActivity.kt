package com.example.local_anime

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "local_anime/thumb")
            .setMethodCallHandler { call, result ->
                if (call.method != "thumbnail") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                val video = call.argument<String>("video")
                val out = call.argument<String>("out")
                val timeMs: Long = call.argument<Number>("timeMs")?.toLong() ?: 0L
                val maxWidth: Int = call.argument<Number>("maxWidth")?.toInt() ?: 480
                if (video == null || out == null) {
                    result.error("bad_args", "video/out is null", null)
                    return@setMethodCallHandler
                }
                executor.execute {
                    var ok = false
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(video)
                        val frame = retriever.getFrameAtTime(
                            timeMs * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                        )
                        if (frame != null) {
                            val bmp = if (frame.width > maxWidth) {
                                val h = (frame.height.toLong() * maxWidth / frame.width).toInt()
                                Bitmap.createScaledBitmap(frame, maxWidth, h, true)
                            } else {
                                frame
                            }
                            FileOutputStream(File(out)).use {
                                bmp.compress(Bitmap.CompressFormat.JPEG, 80, it)
                            }
                            ok = true
                        }
                    } catch (e: Exception) {
                        ok = false
                    } finally {
                        try {
                            retriever.release()
                        } catch (e: Exception) {
                        }
                    }
                    mainHandler.post { result.success(ok) }
                }
            }
    }
}
