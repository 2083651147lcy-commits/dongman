package com.example.local_anime

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ContentUris
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.StrictMode
import android.view.HapticFeedbackConstants
import android.provider.MediaStore
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "local_anime/native")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "thumbnail" -> thumbnail(call.argument("video"), call.argument("out"),
                        call.argument<Number>("timeMs")?.toLong() ?: 0L,
                        call.argument<Number>("maxWidth")?.toInt() ?: 480, result)
                    "imageThumb" -> imageThumb(call.argument("src"), call.argument("out"),
                        call.argument<Number>("maxWidth")?.toInt() ?: 480, result)
                    "duration" -> duration(call.argument("path"), result)
                    "haptic" -> {
                        // 系统导航栏按键同款触感，跟随系统“触摸振动”开关
                        window.decorView.performHapticFeedback(
                            HapticFeedbackConstants.VIRTUAL_KEY)
                        result.success(null)
                    }
                    "listPlayers" -> listPlayers(result)
                    "play" -> play(call.argument("path"), call.argument("mime"),
                        call.argument("package"), result)
                    else -> result.notImplemented()
                }
            }
    }

    private fun thumbnail(video: String?, out: String?, timeMs: Long, maxWidth: Int,
                          result: MethodChannel.Result) {
        if (video == null || out == null) {
            result.error("bad_args", "video/out is null", null)
            return
        }
        executor.execute {
            var ok = false
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(video)
                val frame = retriever.getFrameAtTime(
                    timeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (frame != null) {
                    val bmp = if (frame.width > maxWidth) {
                        val h = (frame.height.toLong() * maxWidth / frame.width).toInt()
                        Bitmap.createScaledBitmap(frame, maxWidth, h, true)
                    } else {
                        frame
                    }
                    FileOutputStream(File(out)).use {
                        bmp.compress(Bitmap.CompressFormat.JPEG, 80, it)
                    }
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            } finally {
                try { retriever.release() } catch (e: Exception) {}
            }
            mainHandler.post { result.success(ok) }
        }
    }

    /// 把图片缩小成封面（用于没有视频、只有图片的番剧）
    private fun imageThumb(src: String?, out: String?, maxWidth: Int,
                           result: MethodChannel.Result) {
        if (src == null || out == null) {
            result.error("bad_args", "src/out is null", null)
            return
        }
        executor.execute {
            var ok = false
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(src, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= maxWidth) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = BitmapFactory.decodeFile(src, opts)
                if (bmp != null) {
                    val scaled = if (bmp.width > maxWidth) {
                        val h = (bmp.height.toLong() * maxWidth / bmp.width).toInt()
                        Bitmap.createScaledBitmap(bmp, maxWidth, h, true)
                    } else {
                        bmp
                    }
                    FileOutputStream(File(out)).use {
                        scaled.compress(Bitmap.CompressFormat.JPEG, 80, it)
                    }
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            }
            mainHandler.post { result.success(ok) }
        }
    }

    private fun duration(path: String?, result: MethodChannel.Result) {
        if (path == null) {
            result.error("bad_args", "path is null", null)
            return
        }
        executor.execute {
            var ms = 0L
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(path)
                ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
            } catch (e: Exception) {
                ms = 0L
            } finally {
                try { retriever.release() } catch (e: Exception) {}
            }
            mainHandler.post { result.success(ms) }
        }
    }

    private fun listPlayers(result: MethodChannel.Result) {
        try {
            val probe = Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse("content://local.anime/sample.mp4"), "video/*")
            val pm = packageManager
            val seen = HashSet<String>()
            val list = ArrayList<Map<String, String>>()
            for (ri in pm.queryIntentActivities(probe, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName) continue
                if (seen.add(pkg)) {
                    list.add(mapOf("label" to ri.loadLabel(pm).toString(), "package" to pkg))
                }
            }
            result.success(list)
        } catch (e: Exception) {
            result.error("list_failed", e.message, null)
        }
    }

    private fun play(path: String?, mime: String?, pkg: String?, result: MethodChannel.Result) {
        if (path == null) {
            result.error("bad_args", "path is null", null)
            return
        }
        try {
            val file = File(path)
            val providerUri = FileProvider.getUriForFile(
                this, "$packageName.localanime.fileprovider", file)
            // 迅雷不认 FileProvider 地址：只对它改用 MediaStore 地址，查不到就用 file:// 真实路径。
            // 其他播放器仍用 FileProvider 地址，行为不变。
            val xunlei = pkg != null && pkg.contains("xunlei", ignoreCase = true)
            var uri: Uri = providerUri
            if (xunlei) {
                val media = mediaStoreUri(path)
                if (media != null) {
                    uri = media
                } else {
                    try {
                        // 允许把 file:// 交给其他应用（本应用已有所有文件访问权限）
                        StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
                        uri = Uri.fromFile(file)
                    } catch (e: Exception) {
                        uri = providerUri
                    }
                }
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime ?: "video/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newRawUri("", uri)
                if (pkg != null) setPackage(pkg)
            }
            val launch = if (pkg == null) Intent.createChooser(intent, "选择播放器") else intent
            startActivity(launch)
            result.success("ok")
        } catch (e: ActivityNotFoundException) {
            result.success("noapp")
        } catch (e: Exception) {
            result.success(e.message ?: "error")
        }
    }

    /// 在系统媒体库里按路径查这个视频，返回 content://media/... 地址；查不到返回 null
    private fun mediaStoreUri(path: String): Uri? {
        return try {
            val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            contentResolver.query(
                collection,
                arrayOf(MediaStore.Video.Media._ID),
                MediaStore.Video.Media.DATA + "=?",
                arrayOf(path),
                null
            )?.use { c ->
                if (c.moveToFirst()) ContentUris.withAppendedId(collection, c.getLong(0)) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
