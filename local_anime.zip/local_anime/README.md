# 本地番剧库（local_anime）

手动导入本地视频，自己填写名称、简介、标签、封面的离线动漫播放器。
无任何联网功能，播放内核与 Kazumi 相同（media_kit / mpv）。

## 功能
- 添加番剧：名称、简介、标签、封面、多集视频（批量选择，自然排序，可改集名、拖动排序）
- 首页：封面网格、按标签筛选、搜索（名称/简介/标签）
- 播放：断点续播、记录每集进度、播完自动下一集、剧集列表切换
- 视频文件会复制到应用私有目录；删除番剧时一并清理

## 编译（需要已装好 Flutter 3.22+）
```bash
flutter create --org com.example --project-name local_anime local_anime
cd local_anime
# 用本压缩包里的 pubspec.yaml 和 lib/ 覆盖生成的同名文件
rm -f test/widget_test.dart
flutter pub get
flutter run                                   # 真机调试
flutter build apk --release --split-per-abi   # 打包，产物在 build/app/outputs/flutter-apk/
```
改应用名：编辑 `android/app/src/main/AndroidManifest.xml` 里的 `android:label`。
