# 交接文档（给接手的 Claude）

先读完本文，再读代码。读完先用几句话告诉用户你的理解，**不要改任何代码，等用户明确说“开始”再动手。**

## 1. 项目是什么

「本地番剧库」：Flutter 写的 Android 应用，管理手机里的本地动漫视频，**用途是收藏**。
选一个根文件夹，每个子文件夹是一部番剧；应用自动扫描、截取封面，用外部播放器播放。当前版本见 `pubspec.yaml`（写本文时为 2.6.2+12）。

已有功能：
- 主页网格：搜索、标签筛选、排序（名称 / 添加时间 / 最近观看 / 总时长 / 随机排序），多选批量收藏/删除。
- 设置页最顶部“导入”分区：**导入**（选视频 → 填信息 → 新建番剧文件夹）、**批量导入**（选文件夹，里面每个视频各成一部番剧）。
- 详情页：封面、名称、上映时间（原样显示用户填的内容）、标签、可折叠简介、剧集列表、继续观看按钮。
- 剧集：每集一条，左剧名（默认文件名去扩展名，最多两行）右时长；**长按改名会同时改视频文件名**。
- 编辑页（导入共用）：改名称（=改文件夹名）、简介、上映时间、标签，添加/删除/更换某一集的视频。
- 历史、收藏夹、封面截帧（全局默认秒数 + 单部覆盖）、默认外部播放器、主题/布局/缩放设置。
## 2. 工作规则（必须遵守）

1. **先讨论，后动手。** 用户说“开始”之前不改代码、不出 zip。可以读文件、提问、给方案。方案里要列出有歧义的地方并给出默认建议，用户回“按建议，开始”即可。
2. 用户不一定会选方向；他没选时不要自作主张开工，先给优先级建议再等确认。
3. 交付物是一个完整的 `local_anime.zip`（根目录名 `local_anime/`，结构与现有一致），同时：升 `pubspec.yaml` 的版本号、更新 `README.md`。
4. **本文（HANDOFF.md）只在用户要求时才更新**，用户会说“更新交接文档”。
5. **永远不要加入“已看/未看”相关的任何东西**（标签、打勾、进度条、状态字段、存储）。用户的库全是看过的收藏，任何“没打开过 = 没看过”的推断都会误判，他明确要求过删干净。
6. 回复要短，用户在手机上看（一屏左右）；先给结论。
7. 说清楚哪些是你确认过的，哪些是推测。不能编译就如实说“没编译验证”。
8. **有歧义的地方先列出来问用户，不要自行决定。** 用户明确要求过。可以用“括号里写建议默认”的方式让他一句话确认。
9. **修 bug 要先说原因。** 找不到确凿原因就如实说“找不到”，并向用户要截图/录屏（见第 10 节），不要编一个原因，也不要凭猜测交付没验证的修复。有过教训：简介展开 bug 连改两版都没修好，直到用户发来截图才定位（见第 6 节的 Flutter 坑）。
10. 授权方式：用户说“开始”/“按建议，开始”，或直接给出“请按下面修正……”这类明确指令，都算授权；其余时候只讨论。
## 3. 构建与更新流程（不要改）

- 沙箱里没有 Flutter/Dart，**无法本地编译**。改完只能靠仔细阅读检查语法、类型、import、空安全，并用全局搜索检查残留。
- 用户把 `local_anime.zip` 上传覆盖到 GitHub 仓库，Actions（`Build APK`）自动构建：解压 zip → `flutter create --org com.example --project-name local_anime --platforms=android .` → `flutter pub get` → `flutter build apk --release --target-platform android-arm64`，Flutter 3.50.0 stable，Java 17。
- 因此 `android/` 目录里只有被覆盖的部分文件（MainActivity.kt、FileProvider、AndroidManifest.xml、xml 路径配置），其余由 `flutter create` 生成。**不要依赖其他生成的 Android 文件。**
- 签名没有固定，每次构建的 APK 签名不同，用户每次**卸载再安装**，已知并接受，**不要再提议改**。
- 卸载会清掉应用内数据（SharedPreferences 里的所有设置、封面缓存、索引缓存）；番剧文件夹里的 `.anime.json` 和动漫库根目录的 `.collections.json` 不受影响，重装后选回文件夹即可恢复（封面需重新截取）。所以：
  - 任何需要持久保存的数据都应写进这两个文件，而不是只放应用内部。
  - **设置的默认值很重要**，因为每次重装都会回到默认（例如“显示标签”曾因默认关而让用户以为标签消失了，现已默认开）。用户还没告诉过他平时用的列数、封面比例等值，可以问他，再设成默认。
- 新增依赖要谨慎：之前因 `video_thumbnail`（使用已废弃的 `jcenter()`）导致构建失败，已改用原生 `MediaMetadataRetriever`。加插件前先想想它的 Android 构建脚本在 Flutter 3.50 + Gradle 下会不会出问题。现有依赖：file_picker、path_provider、path、shared_preferences、permission_handler、open_filex。
- Manifest 已声明 `MANAGE_EXTERNAL_STORAGE`（所有文件访问），应用可以直接读写、移动、删除动漫库里的文件。

## 4. 代码结构

```
lib/
  main.dart            入口；透明状态栏/导航栏，主题由设置驱动
  models.dart          Episode / Anime / Collection 及 JSON 序列化
  library.dart         LibraryStore：扫描、缓存、封面、元数据、收藏夹、历史、删除、时长、改名、播放、导入/批量导入/编辑剧集；
                       另有 DraftEp / OpResult / BatchResult 三个小类
  settings.dart        SettingsStore：所有设置，SharedPreferences 持久化
  episode_parser.dart  文件名识别集数 + 自然排序
  selection.dart       多选状态
  pages/               app_shell（底部四栏）home / history / collections / collection_detail /
                       detail / settings / edit_meta / edit_collection / file_browser（内置视频选择器）
  ui/                  anime_card（含 CoverImage、fmtDuration）、card_grid、collection_sheet、
                       delete_flow、selection_bar、progress_dialog（runWithProgress）
android/.../MainActivity.kt   MethodChannel `local_anime/native`：
                       thumbnail / duration / listPlayers / play（FileProvider + ACTION_VIEW）
```

状态管理：`ChangeNotifier` + `ListenableBuilder`，没有第三方状态库。

要点：
- `Episode`：`name` 是文件名，`baseName` 是去扩展名的文件名，`title` 是“第N集”（识别不出集数则等于 baseName）。详情页列表显示 `baseName`；“继续 · xx”按钮和历史页用 `title`。
- `Anime`：`totalMs`（各集已知时长之和）、`hasResume`/`resumeEpisode`（上次打开的那集，没有则第一集）、`addedAt`。
- `LibraryStore.renameEpisode(a, e, newBase)`：真正重命名视频文件（扩展名不变），同步迁移 `durations` 和 `lastEpisode` 的相对路径 key，重排剧集后 `saveMeta`；返回 null 成功，否则返回失败原因（空名、含 `/` `\` 或以 `.` 开头、同名已存在、系统报错）。
- `LibraryStore.loadAllDurations()`：后台把所有番剧每集时长读出来，供“按总时长”排序；`durationsLoading` 驱动主页顶部细进度条。选择该排序方式时触发，扫描结束时若当前就是该排序也会触发。
- `home_page.dart`：排序、随机批次逻辑都在这里；`detail_page.dart` 底部有私有的 `_Synopsis` 组件。
- `Anime.path` 是**可变**的（改文件夹名时更新），所以编辑后详情页持有的还是同一个对象，不会过期。
- 导入/编辑的核心函数都在 `LibraryStore`：`isVideoFile`、`listVideos(folder)`、`importAnime(...)`、`batchImport(videos, copy:)`、`applyEdit(a, ...)`；私有辅助：`_nameError`、`_uniqueDir`、`_uniqueFile`、`_transfer`。`importAnime`/`applyEdit` 返回 `OpResult(done, message)`，`batchImport` 返回 `BatchResult(ok, failed)`：`done` 表示文件已经动过（页面可关闭），`message` 是要提示用户的错误或部分失败说明。

## 5. 数据与持久化

| 数据 | 位置 | 说明 |
|---|---|---|
| 简介、上映时间、标签、时长、最近打开的集和时间、封面秒数、uid、添加时间 | 番剧文件夹 `.anime.json` | 随文件夹走 |
| 收藏夹 | 根目录 `.collections.json` + 应用内 `collections_cache.json` | 收藏夹只存番剧 uid |
| 扫描索引 | 应用内 `index_cache.json` | 仅加速启动，可丢 |
| 封面 | 应用内 `covers/`，文件名 `{fnv(路径)}_{毫秒}.jpg` | 可丢，会重新截取 |
| 显示设置、根路径、默认播放器、排序方式 `sort` 与方向 `sortRev` | SharedPreferences | 卸载即丢 |

关键约定：
- 番剧靠 `uid`（写在 `.anime.json`）关联收藏夹，改文件夹位置不丢；`uid` 为空时扫描会生成并写回。
- `durations` 和 `lastEpisode` 都以**相对于番剧文件夹的路径**做 key；任何改动剧集文件名/位置的操作都必须同步迁移这两处。
- `addedAt`：首次发现这部番剧时写入。新导入的记当前时间；功能上线前就已有 uid 的老番剧，用文件夹修改时间当初值（所以老番剧的添加顺序只是大致参考）。
- 只扫描根目录下一层子文件夹；每部番剧只识别**一层**子文件夹（作为分组，如“第二季”）。
- `.anime.json` 是整个文件覆盖写入的，不再认识的旧字段（如旧版的 `watched`）保存时自然消失。
- 删除番剧会删整个文件夹，`deleteAnimes` 里有“必须是根目录直接子文件夹”的安全检查，不要放宽。
- 以 `.` 开头的文件和文件夹一律忽略。

## 6. 已做出的行为决定（不要无故改动）

**排序**（`sortMode`：0 名称 1 最近观看 2 总时长 3 随机 4 添加时间；菜单顺序为 名称、添加时间、最近观看、总时长、随机排序）
- 再点一次已选中的方式就反向（`sortReverse`），菜单里显示当前方向；默认方向：名称 A→Z，添加时间 新→旧，最近观看 近→远，总时长 长→短。切换方式时方向复位。
- 总时长排序里“还没读到时长（0）”的永远排最后；其他排序不对 0 做任何特殊处理（不能推断“没看过”）。
- 随机排序：主页只展示 6 个，在当前搜索/标签筛选的结果里抽。洗牌轮播：一轮内不重复，抽完才重新洗牌，新一轮刚展示过的排最后。下拉刷新和再点一次“随机排序”都是换一批，此模式下下拉**不重新扫描**。切换页面再回来保持当前这批。

**详情页**
- 简介：标题整行（高度至少 44，含右侧空白）和内容区域都可点；标题文字后紧跟小箭头（展开时朝上，其他朝下）。无简介不显示。
  - 长简介（超过 4 行）：默认 4 行 → 点一下全部展开 → 再点只剩“简介”标题 → 再点全部展开……（之后在“全部展开”和“只剩标题”间来回，**不回到 4 行**）。
  - 短简介（不超过 4 行）：默认全部显示 ↔ 点一下只剩标题。
  - 实现：`_Synopsis`，用 `LayoutBuilder` + `TextPainter(maxLines: 4).didExceedMaxLines` 判断长短，三个状态 clamped / full / hidden。
- 剧集条：左播放图标不动，中间剧名最多两行，右边时长（读到才显示）。长按改名（见上）。

**编辑页**（`EditMetaPage`，两个构造函数：`EditMetaPage(store, anime)` 编辑，`EditMetaPage.importing(store, importSources)` 导入）
- 字段：名称（编辑时=文件夹名；导入时默认取第一个视频的文件名）、上映时间、简介、标签、剧集。
- 剧集区：`DraftEp` 草稿列表（已有视频 / 待放入的外部视频），“添加视频”、每条“更换视频”“删除”，移动/复制切换（默认移动）。**所有改动点保存才执行**；有要永久删除的已有视频时保存前弹确认；至少保留一集。本来就在这部番剧文件夹里的视频不能再被“添加/更换”进来。

**Flutter 的坑（已踩过，不要再犯）**
- `Text` 同时设置 `overflow: TextOverflow.ellipsis` 和不限行数（`maxLines: null`）时，整段会被当成**一行**并加省略号。需要“展开全部”时必须不用省略号（用 `TextOverflow.clip`），只有明确限制行数时才加省略号。

**卡片**：标签用 `·` 连起来，最多两行；“显示标签”开关默认开。多选时卡片右上角的圆圈是选择用的，不是已看标记。

## 7. 导入 / 批量导入 / 编辑剧集（已实现，v2.6.0）

用户反馈该版本可用。行为如下，改动前先看：

**入口**：`pages/settings_page.dart` 最顶部“导入”分区（在“动漫库”之前），`_import`、`_batchImport`；都先经 `_readyToImport`（必须已选动漫库文件夹且有所有文件访问权限）。

**导入**：`FileBrowserPage`（内置视频选择器，多选，点“确定”即确认）→ `EditMetaPage.importing`（名称、上映时间、简介、标签，都可不填；视频列表可再增删/更换）→ `store.importAnime`：新建番剧文件夹（重名自动加 `(2)`）→ 把视频移动/复制进去 → `_scanAnime` → 写入填好的信息 → 加入列表。全部视频都失败则删掉刚建的文件夹。

**批量导入**：`FilePicker.platform.getDirectoryPath()` 选文件夹 → `store.listVideos`（只看**直接下一层**的视频，不进子文件夹，跳过隐藏文件）→ 一个确认弹窗（“将导入 N 个视频”+ 移动/复制，默认移动）→ `runWithProgress` + `store.batchImport`：每个视频新建一个以文件名（不含扩展名）命名的文件夹，放进去，扫描后加入列表；不弹编辑页，失败的汇总提示。

**保存编辑**（`store.applyEdit`），顺序：校验（名称合法、不与其他文件夹重名、至少一集）→ 先把简介/时间/标签写进 `.anime.json`（否则后面重新扫描会被旧内容覆盖）→ 删除被移出的视频 → 移动/复制新视频（重名加 `(2)`）→ 清旧封面 → 改文件夹名（`a.path` 同步更新）→ 用同一个 `Anime` 对象重新扫描 → 清理已不存在的 `durations`/`lastEpisode` key → 写回、保存缓存、通知、重新截封面。

**移动/复制**：`_transfer`——移动先 `rename`（同一存储瞬间完成），抛 `FileSystemException`（跨存储）则复制后删原文件；任何失败都会清掉没拷完的残留目标文件。

**内置文件浏览器**（`pages/file_browser_page.dart`）：直接读真实路径（不会像系统选择器那样先复制到缓存）；起点是 `/storage/emulated/0`，其他 `/storage/*` 存储卡单独列出；只显示文件夹和视频，隐藏以 `.` 开头的；多选、“全选本页”；单选模式（更换视频用）点一下即返回；本次运行内记住上次位置；返回键先上一级，到存储位置列表再退出。

已知局限：
- 把视频从**另一部**番剧的文件夹里移走时，那部番剧的卡片要等下次扫描才更新，它没视频后会消失，空文件夹留在原地。
- 改剧集文件名后，集数按新文件名重新识别，位置可能变化。
- 批量导入用的是系统的选文件夹，返回的路径是否在所有设备上都是真实路径未逐一验证（用户的设备上可用）。
## 8. 其他待办（做完一项划掉一项，优先级由用户决定）

- [ ] 扫描是串行的，且每次启动全量重扫，番剧多时会慢 → 并行/增量刷新
- [ ] 只支持一层子文件夹，更深的目录扫不到
- [ ] 每次播放都调用 `requestMediaPermissions`，部分系统会反复弹窗
- [ ] `.anime.json` 写入失败是静默的，没权限时记录只存在应用缓存里，卸载即丢 → 至少给出提示
- [ ] 封面只取第一集，用 `OPTION_CLOSEST_SYNC`，实际帧可能偏离目标时间；`changeRoot` 不会清空 `_coverFailed`
- [ ] 缺：列表视图、详情页搜索集数
- [ ] 待用户决定：三处使用“打开记录”（点开某一集时记下的时间和集数，不是已看标记）的地方是否保留——历史页、“按最近观看”排序、详情页“继续 · 某集 / 开始观看 · 第一集”按钮
- 想法清单（用户尚未选）：封面支持 `poster.jpg`/`cover.jpg` 优先和手动换封面；按占用空间/上映时间排序；批量编辑标签；统计页；设置页改分组卡片、历史页左滑删除、OLED 纯黑、动态取色（见下）；从 Bangumi 联网匹配简介/评分/封面（工作量最大，要加网络权限）。

> 多数来自代码通读，并非用户报告的问题。
## 9. 界面风格：模仿 Kazumi

用户希望风格向 Kazumi（Flutter 番剧应用）靠拢。下面是**从 Kazumi 源码读出的事实**（版本 2.4.4，源码在用户上传的 `Kazumi-main.zip`），只借鉴视觉与交互，**不要照搬它的架构**（它用 flutter_modular、mobx、hive，本项目不用）。**没看过截图，视觉层面的判断请让用户发截图核对。** 用户的 Kazumi APK 对工作没用，不必再要。

**主题**
- Material 3，`colorSchemeSeed`；默认种子色 `Colors.green`；预设色：绿(默认)、青、蓝、靛蓝、紫罗兰 `0xff6750a4`、粉、黄、橙、深橙。
- 支持跟随系统/浅色/深色，另有“OLED 增强”（深色时背景纯黑）和“动态取色”（`dynamic_color`）。
- 进度条、滑块启用新版 Material 外观（`year2023: false`，滑块拖动时显示数值）。
- Android 页面转场使用 Cupertino 滑动样式。

**封面卡片**（`BangumiCardV`）
- `Card(elevation: 0, clipBehavior: antiAlias, margin: zero)`，封面在上、标题在下，整张卡片是一个 `InkWell`。
- 封面比例 0.65；标题字重 w500、字距 0.3，行数按剩余高度动态算（1~3 行），字体缩放上限 1.1。
- 网格：窄屏 3 列，更宽 5 列、再宽 6 列；列间距 8，行间距 6，外边距 8；每格高度 = 列宽 / 0.65 + 文字缩放后的 32。
- 间距常量：`cardSpace = 8`、`safeSpace = 12`。

**分组列表与设置页**
- `TonalCard`：`surfaceContainerLow` 底色，圆角 16。
- 设置按“分区”组织：分区标题用 `titleSmall`、主题色、w600；每组条目是分段卡片——组的首尾圆角 16，中间相邻条目圆角 4，条目间隔 2；分区外边距 16。
- 条目类型有普通、开关、单选三种。

**页面结构**
- 底部 `NavigationBar` 四项：推荐 / 时间表 / 追番 / 我的（宽屏换成左侧 `NavigationRail`）。图标选中为实心、未选中为描边。
- 首页顶部是可折叠 `SliverAppBar`（展开高度 120，标题字号 28→20、字重 w700→w500，底色用 `surface`），带“回到顶部”浮动按钮（`arrow_upward`）。
- 详情页用 `SliverAppBar.medium` + `TabBar` 分页签。
- 追番页按状态分页签，下面是海报网格。
- 历史条目：`surfaceContainerLow` 底色的圆角行，**左滑删除**（红色 `errorContainer` 背景 + 垃圾桶图标），显示“看到 mm:ss”。

**本项目与 Kazumi 的主要差异（均为可选的靠拢方向，不是已决定的改动）**
- 默认种子色是靛蓝，Kazumi 是绿色。
- 卡片是裸 `InkWell + Column`，没有 `Card` 容器；封面比例由用户设置，而不是固定 0.65。
- 主页是普通 `AppBar`，不是可折叠大标题。
- 设置页是平铺的 `ListTile`/滑块，没有分段分组卡片。
- 历史页没有左滑删除；没有 OLED 增强、动态取色、页面转场样式。
- 底部导航已是 `NavigationBar`，四项为 主页/历史/收藏/设置。

## 10. 用户与环境

- 沟通语言：中文。
- 使用方式：手机上的 Claude 应用，只能上传/下载文件，不会本地编译；每次把新 zip 上传到 GitHub，卸载重装。
- 库的性质：**全部是看过的收藏**。
- 手机型号 / Android 版本 / 常用外部播放器：**待用户补充**（影响权限与播放问题）。
- 动漫库的真实目录结构和规模：**待用户补充**（影响扫描优化）。
- 平时使用的显示设置（列数、封面比例等）：**待用户补充**（用来设成默认值）。
- 用户会发**截图和录屏**来说明问题。截图可以直接看；录屏是 mp4，沙箱里有 `ffmpeg`，可用 `ffmpeg -i x.mp4 -vf fps=2 frames/f_%03d.jpg` 拆成图片再看。遇到“表现不对”的问题，优先让用户给每个状态的截图。
## 11. 变更记录

- v2.3.0+7：基线。
- v2.4.0+8：彻底移除“已看/未看”相关的全部内容；主页新增“按总时长”“随机排序”，再点一次已选中的排序可反向；卡片标签最多两行；“继续”按钮改为上次打开的那集。
- v2.5.0+9：新增“按添加时间”排序（`addedAt`）；“显示标签”默认开启；详情页：上映时间原样显示、简介可折叠、剧集条改为左剧名右时长、长按改名同时改视频文件名。
- v2.6.0+10：设置页顶部新增“导入”分区（导入 / 批量导入）；新增内置文件浏览器和进度弹窗；编辑页重做（可改名称=文件夹名、添加/删除/更换剧集、移动/复制）。
- v2.6.1+11：简介交互改为长简介“4 行 → 展开 → 只剩标题 → 展开”，标题整行可点。
- v2.6.2+12：修复简介展开后只显示一行（展开状态不再用省略号）。
