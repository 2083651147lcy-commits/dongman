# 交接文档（给接手的 Claude）

先读完本文，再读代码。读完先用几句话告诉用户你的理解，**不要改任何代码，等用户明确说“开始”再动手。**

## 1. 项目是什么

「本地番剧库」：Flutter 写的 Android 应用，管理手机里的本地动漫视频。
选一个根文件夹，每个子文件夹是一部番剧；应用自动扫描、截取封面、记录观看，用外部播放器播放。当前版本见 `pubspec.yaml`（写本文时为 2.3.0+7）。

已有功能：主页网格（搜索、标签筛选、按名称/最近观看排序）、详情页（剧集、已看标记、时长、继续观看）、历史、收藏夹、多选批量收藏/删除、封面截帧（全局默认秒数 + 单部覆盖）、默认外部播放器选择、主题/布局/缩放设置。

## 2. 工作规则（必须遵守）

1. **先讨论，后动手。** 用户说“开始”之前不改代码、不出 zip。可以读文件、提问、给方案。
2. 用户不一定会选方向；他没选时不要自作主张开工，先给优先级建议再等确认。
3. 交付物是一个完整的 `local_anime.zip`（根目录名 `local_anime/`，结构与现有一致），同时：升 `pubspec.yaml` 的版本号、更新 `README.md`、把本文的“待办”和“变更记录”同步。
4. 回复要短，用户在手机上看（一屏左右）；先给结论。
5. 说清楚哪些是你确认过的，哪些是推测。不能编译就如实说“没编译验证”。

## 3. 构建与更新流程（不要改）

- 沙箱里没有 Flutter/Dart，**无法本地编译**。改完只能靠仔细阅读检查语法、类型、import、空安全。
- 用户把 `local_anime.zip` 上传覆盖到 GitHub 仓库，Actions（`Build APK`）自动构建：解压 zip → `flutter create --org com.example --project-name local_anime --platforms=android .` → `flutter pub get` → `flutter build apk --release --target-platform android-arm64`，Flutter 3.50.0 stable，Java 17。
- 因此 `android/` 目录里只有被覆盖的部分文件（MainActivity.kt、FileProvider、AndroidManifest.xml、xml 路径配置），其余由 `flutter create` 生成。**不要依赖其他生成的 Android 文件。**
- 签名没有固定，每次构建的 APK 签名不同，用户每次**卸载再安装**，已知并接受，不要再提议改。
- 卸载会清掉应用内数据（SharedPreferences、封面缓存、索引缓存）；番剧文件夹里的 `.anime.json` 和动漫库根目录的 `.collections.json` 不受影响，重装后选回文件夹即可恢复（封面需重新截取）。**所以任何需要持久保存的数据都应写进这两个文件，而不是只放应用内部。**
- 新增依赖要谨慎：之前因 `video_thumbnail`（使用已废弃的 `jcenter()`）导致构建失败，已改用原生 `MediaMetadataRetriever`。加插件前先想想它的 Android 构建脚本在 Flutter 3.50 + Gradle 下会不会出问题。

## 4. 代码结构

```
lib/
  main.dart            入口；透明状态栏/导航栏，主题由设置驱动
  models.dart          Episode / Anime / Collection 及 JSON 序列化
  library.dart         LibraryStore：扫描、缓存、封面、元数据、收藏夹、历史、删除、时长、播放
  settings.dart        SettingsStore：所有设置，SharedPreferences 持久化
  episode_parser.dart  文件名识别集数 + 自然排序
  selection.dart       多选状态
  pages/               app_shell（底部四栏）home / history / collections / collection_detail /
                       detail / settings / edit_meta / edit_collection
  ui/                  anime_card（含 CoverImage、fmtDuration）、card_grid、collection_sheet、
                       delete_flow、selection_bar
android/.../MainActivity.kt   MethodChannel `local_anime/native`：
                       thumbnail / duration / listPlayers / play（FileProvider + ACTION_VIEW）
```

状态管理：`ChangeNotifier` + `ListenableBuilder`，没有第三方状态库。

## 5. 数据与持久化

| 数据 | 位置 | 说明 |
|---|---|---|
| 简介、上映时间、标签、已看、时长、最近观看、封面秒数、uid | 番剧文件夹 `.anime.json` | 随文件夹走 |
| 收藏夹 | 根目录 `.collections.json` + 应用内 `collections_cache.json` | 收藏夹只存番剧 uid |
| 扫描索引 | 应用内 `index_cache.json` | 仅加速启动，可丢 |
| 封面 | 应用内 `covers/`，文件名 `{fnv(路径)}_{毫秒}.jpg` | 可丢，会重新截取 |
| 显示设置、根路径、默认播放器 | SharedPreferences | 卸载即丢 |

关键约定：
- 番剧靠 `uid`（写在 `.anime.json`）关联收藏夹，改文件夹位置不丢；`uid` 为空时扫描会生成并写回。
- 集数的“已看”用**相对于番剧文件夹的路径**做 key。
- 只扫描根目录下一层子文件夹，每部番剧只识别**一层**子文件夹（作为分组，如“第二季”）。
- 删除番剧会删整个文件夹，`deleteAnimes` 里有“必须是根目录直接子文件夹”的安全检查，不要放宽。
- 以 `.` 开头的文件和文件夹一律忽略。

## 6. 已知问题与待办（做完一项划掉一项）

- [ ] 扫描是串行的，且每次启动全量重扫，番剧多时会慢 → 并行/增量刷新
- [ ] 只支持一层子文件夹，更深的目录扫不到
- [ ] 点开播放就标“已看”，不是看完才标（外部播放器无法回传进度）；详情页缺“标记到此集为止都已看”
- [ ] 每次播放都调用 `requestMediaPermissions`，部分系统会反复弹窗
- [ ] `.anime.json` 写入失败是静默的，没权限时记录只存在应用缓存里，卸载即丢
- [ ] 封面只取第一集，用 `OPTION_CLOSEST_SYNC`，实际帧可能偏离目标时间；`changeRoot` 不会清空 `_coverFailed`
- [ ] 缺：主页“未看/在追/看完”筛选、列表视图、详情页搜索集数
- [ ] `README.md` 里还写着“收藏（下一版）”，已过期

> 以上来自一次完整的代码通读，并非用户报告的问题。优先级由用户决定。

## 7. 界面风格：模仿 Kazumi

用户希望风格向 Kazumi（Flutter 番剧应用）靠拢。下面是**从 Kazumi 源码读出的事实**（版本 2.4.4，源码在用户上传的 `Kazumi-main.zip`），只借鉴视觉与交互，**不要照搬它的架构**（它用 flutter_modular、mobx、hive，本项目不用）。**我没看过截图，视觉层面的判断请让用户发截图核对。**

**主题**
- Material 3，`colorSchemeSeed`；默认种子色 `Colors.green`；预设色：绿(默认)、青、蓝、靛蓝、紫罗兰 `0xff6750a4`、粉、黄、橙、深橙。
- 支持跟随系统/浅色/深色，另有“OLED 增强”（深色时背景纯黑）和“动态取色”（`dynamic_color`）。
- 进度条、滑块启用新版 Material 外观（`year2023: false`，滑块拖动时显示数值）。
- Android 页面转场使用 Cupertino 滑动样式。

**封面卡片**（`BangumiCardV`）
- `Card(elevation: 0, clipBehavior: antiAlias, margin: zero)`，封面在上、标题在下，整张卡片是一个 `InkWell`。
- 封面比例 0.65；标题字重 w500、字距 0.3，行数按剩余高度动态算（1~3 行），字体缩放上限 1.1。
- 网格：窄屏 3 列，更宽 5 列、再宽 6 列；列间距 8，行间距 6，外边距 8；每格高度 = 列宽 / 0.65 + 文字缩放后的 32。
- 间距常量：`cardSpace = 8`、`safeSpace = 12`。

**分组列表与设置页**
- `TonalCard`：`surfaceContainerLow` 底色，圆角 16。
- 设置按“分区”组织：分区标题用 `titleSmall`、主题色、w600；每组条目是分段卡片——组的首尾圆角 16，中间相邻条目圆角 4，条目间隔 2；分区外边距 16。
- 条目类型有普通、开关、单选三种。

**页面结构**
- 底部 `NavigationBar` 四项：推荐 / 时间表 / 追番 / 我的（宽屏换成左侧 `NavigationRail`）。图标选中为实心、未选中为描边。
- 首页顶部是可折叠 `SliverAppBar`（展开高度 120，标题字号 28→20、字重 w700→w500，底色用 `surface`），带“回到顶部”浮动按钮（`arrow_upward`）。
- 详情页用 `SliverAppBar.medium` + `TabBar` 分页签。
- 追番页按状态分页签，下面是海报网格。
- 历史条目：`surfaceContainerLow` 底色的圆角行，**左滑删除**（红色 `errorContainer` 背景 + 垃圾桶图标），显示“看到 mm:ss”。

**本项目与 Kazumi 的主要差异（均为可选的靠拢方向，不是已决定的改动）**
- 默认种子色是靛蓝，Kazumi 是绿色。
- 卡片是裸 `InkWell + Column`，没有 `Card` 容器；封面比例由用户设置，而不是固定 0.65。
- 主页是普通 `AppBar`，不是可折叠大标题。
- 设置页是平铺的 `ListTile`/滑块，没有分段分组卡片。
- 历史页没有左滑删除；没有 OLED 增强、动态取色、页面转场样式。
- 底部导航已是 `NavigationBar`，四项为 主页/历史/收藏/设置。

## 8. 用户与环境

- 沟通语言：中文。
- 使用方式：手机上的 Claude 应用，只能上传/下载文件，不会本地编译。
- 手机型号 / Android 版本 / 常用外部播放器：**待用户补充**（影响权限与播放问题）。
- 动漫库的真实目录结构和规模：**待用户补充**（影响扫描优化）。

## 9. 变更记录

- v2.3.0+7：当前基线（本文写入时的状态）。
