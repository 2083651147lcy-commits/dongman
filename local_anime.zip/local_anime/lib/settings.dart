import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 显示在设置页底部，每次出新版本要和 pubspec.yaml 的 version 一起改
const appVersion = '2.15.0+29';

class SettingsStore extends ChangeNotifier {
  late SharedPreferences _sp;

  String? rootPath;
  int portraitCols = 3;
  int landscapeCols = 5;
  int ratioIndex = 0;
  int spacingIndex = 1;
  double coverRadius = 8;
  double titleFont = 14;
  int get titleLines => 2; // 固定 2 行（已移除设置项）
  double uiScale = 1.0;
  bool showEpCount = true;
  bool showTags = true;
  bool get navHaptic => true; // 底部导航栏点按震动，一直开启
  int themeIndex = 0; // 0 跟随系统 1 浅色 2 深色
  int seedIndex = 0;
  int coverSecond = 60;
  int sortMode = 4; // 默认按添加时间；0 名称 1 最近观看 2 总时长 3 随机 4 添加时间
  bool sortReverse = false; // 是否与该排序方式的默认方向相反
  int historyLimit = 10; // 历史记录显示条数
  int autoShotCount = 8; // 自动生成画面截图的数量
  bool autoShot = true; // 进详情页后自动生成画面截图
  String? playerPackage; // 默认外部播放器的包名，null = 每次询问
  String? playerLabel;

  static const ratios = [2 / 3, 3 / 4, 1.0, 16 / 9];
  static const ratioLabels = ['2:3', '3:4', '1:1', '16:9'];
  static const spacings = [6.0, 12.0, 18.0];
  static const spacingLabels = ['紧凑', '标准', '宽松'];
  static const seeds = [
    Colors.indigo,
    Colors.teal,
    Colors.pink,
    Colors.orange,
    Colors.green,
    Colors.deepPurple,
  ];

  double get ratio => ratios[ratioIndex];
  double get gap => spacings[spacingIndex];
  Color get seed => seeds[seedIndex];
  ThemeMode get themeMode =>
      const [ThemeMode.system, ThemeMode.light, ThemeMode.dark][themeIndex];

  Future<void> load() async {
    _sp = await SharedPreferences.getInstance();
    rootPath = _sp.getString('root');
    portraitCols = (_sp.getInt('pc') ?? 3).clamp(1, 6);
    landscapeCols = (_sp.getInt('lc') ?? 5).clamp(1, 10);
    ratioIndex = (_sp.getInt('ratio') ?? 0).clamp(0, ratios.length - 1);
    spacingIndex = (_sp.getInt('spacing') ?? 1).clamp(0, spacings.length - 1);
    coverRadius = _sp.getDouble('radius') ?? 8;
    titleFont = _sp.getDouble('tfont') ?? 14;
    uiScale = _sp.getDouble('scale') ?? 1.0;
    showEpCount = _sp.getBool('showEp') ?? true;
    showTags = _sp.getBool('showTags') ?? true;
    themeIndex = (_sp.getInt('theme') ?? 0).clamp(0, 2);
    seedIndex = (_sp.getInt('seed') ?? 0).clamp(0, seeds.length - 1);
    coverSecond = _sp.getInt('coverSec') ?? 60;
    sortMode = (_sp.getInt('sort') ?? 4).clamp(0, 4);
    sortReverse = _sp.getBool('sortRev') ?? false;
    historyLimit = (_sp.getInt('histN') ?? 10).clamp(5, 50);
    autoShotCount = (_sp.getInt('shotN') ?? 8).clamp(4, 20);
    autoShot = _sp.getBool('autoShot') ?? true;
    playerPackage = _sp.getString('playerPkg');
    playerLabel = _sp.getString('playerLabel');
  }

  Future<void> update(void Function() change) async {
    change();
    notifyListeners();
    await _persist();
  }

  Future<void> resetDisplay() => update(() {
        portraitCols = 3;
        landscapeCols = 5;
        ratioIndex = 0;
        spacingIndex = 1;
        coverRadius = 8;
        titleFont = 14;
        uiScale = 1.0;
        showEpCount = true;
        showTags = true;
      });

  Future<void> _persist() async {
    if (rootPath == null) {
      await _sp.remove('root');
    } else {
      await _sp.setString('root', rootPath!);
    }
    await _sp.setInt('pc', portraitCols);
    await _sp.setInt('lc', landscapeCols);
    await _sp.setInt('ratio', ratioIndex);
    await _sp.setInt('spacing', spacingIndex);
    await _sp.setDouble('radius', coverRadius);
    await _sp.setDouble('tfont', titleFont);
    await _sp.setDouble('scale', uiScale);
    await _sp.setBool('showEp', showEpCount);
    await _sp.setBool('showTags', showTags);
    await _sp.setInt('theme', themeIndex);
    await _sp.setInt('seed', seedIndex);
    await _sp.setInt('coverSec', coverSecond);
    await _sp.setInt('sort', sortMode);
    await _sp.setBool('sortRev', sortReverse);
    await _sp.setInt('histN', historyLimit);
    await _sp.setInt('shotN', autoShotCount);
    await _sp.setBool('autoShot', autoShot);
    if (playerPackage == null) {
      await _sp.remove('playerPkg');
      await _sp.remove('playerLabel');
    } else {
      await _sp.setString('playerPkg', playerPackage!);
      await _sp.setString('playerLabel', playerLabel ?? playerPackage!);
    }
  }
}
