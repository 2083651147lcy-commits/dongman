import 'package:path/path.dart' as p;

class Episode {
  final String path;
  final String name; // 文件名
  final String group; // 子文件夹名（第二季、OVA…），顶层为空
  final int? number;

  const Episode({
    required this.path,
    required this.name,
    required this.group,
    this.number,
  });

  String get title =>
      number != null ? '第$number集' : p.basenameWithoutExtension(name);

  Map<String, dynamic> toJson() =>
      {'path': path, 'name': name, 'group': group, 'number': number};

  factory Episode.fromJson(Map<String, dynamic> j) => Episode(
        path: j['path'] as String,
        name: j['name'] as String,
        group: (j['group'] ?? '') as String,
        number: j['number'] as int?,
      );
}

class Anime {
  final String path; // 文件夹路径，同时是唯一标识
  String name;
  String synopsis;
  List<String> tags;
  List<Episode> episodes;
  String? coverPath; // 当前使用的封面文件
  String? folderCover; // 文件夹里找到的图片
  Set<String> watched; // 已看集（相对路径）
  Map<String, int> durations; // 每集时长（毫秒），key 为相对路径
  String? lastEpisode; // 最近打开的一集（相对路径）
  int lastOpenedAt;
  int coverMs; // 0 = 自动（优先文件夹图片），>0 = 强制截取该毫秒

  Anime({
    required this.path,
    required this.name,
    this.synopsis = '',
    List<String>? tags,
    List<Episode>? episodes,
    this.coverPath,
    this.folderCover,
    Set<String>? watched,
    Map<String, int>? durations,
    this.lastEpisode,
    this.lastOpenedAt = 0,
    this.coverMs = 0,
  })  : tags = tags ?? [],
        episodes = episodes ?? [],
        watched = watched ?? {},
        durations = durations ?? {};

  String relOf(Episode e) => p.relative(e.path, from: path);
  bool isWatched(Episode e) => watched.contains(relOf(e));
  int get watchedCount => episodes.where(isWatched).length;

  /// 下一集该看哪一集：从最近打开的那集往后找第一个没看的。
  Episode? get nextToWatch {
    if (episodes.isEmpty) return null;
    var start = 0;
    if (lastEpisode != null) {
      final i = episodes.indexWhere((e) => relOf(e) == lastEpisode);
      if (i >= 0) start = i;
    }
    for (var k = 0; k < episodes.length; k++) {
      final e = episodes[(start + k) % episodes.length];
      if (!isWatched(e)) return e;
    }
    return episodes[start];
  }

  /// 写进番剧文件夹 .anime.json 的内容
  Map<String, dynamic> metaJson() => {
        'version': 1,
        'synopsis': synopsis,
        'tags': tags,
        'watched': watched.toList(),
        'durations': durations,
        'lastEpisode': lastEpisode,
        'lastOpenedAt': lastOpenedAt,
        'coverMs': coverMs,
      };

  void applyMeta(Map<String, dynamic> j) {
    synopsis = (j['synopsis'] ?? '') as String;
    tags = ((j['tags'] ?? []) as List).map((e) => e.toString()).toList();
    watched = ((j['watched'] ?? []) as List).map((e) => e.toString()).toSet();
    durations = ((j['durations'] ?? {}) as Map)
        .map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
    lastEpisode = j['lastEpisode'] as String?;
    lastOpenedAt = (j['lastOpenedAt'] ?? 0) as int;
    coverMs = (j['coverMs'] ?? 0) as int;
  }

  Map<String, dynamic> cacheJson() => {
        'path': path,
        'name': name,
        'coverPath': coverPath,
        'folderCover': folderCover,
        'episodes': episodes.map((e) => e.toJson()).toList(),
        ...metaJson(),
      };

  factory Anime.fromCache(Map<String, dynamic> j) {
    final a = Anime(
      path: j['path'] as String,
      name: (j['name'] ?? '') as String,
      coverPath: j['coverPath'] as String?,
      folderCover: j['folderCover'] as String?,
      episodes: ((j['episodes'] ?? []) as List)
          .map((e) => Episode.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
    a.applyMeta(j);
    return a;
  }
}
