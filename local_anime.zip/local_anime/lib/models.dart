class Episode {
  String title;
  String path;
  int positionMs;
  int durationMs;

  Episode({
    required this.title,
    required this.path,
    this.positionMs = 0,
    this.durationMs = 0,
  });

  bool get finished => durationMs > 0 && positionMs >= durationMs - 5000;

  double get progress =>
      durationMs <= 0 ? 0 : (positionMs / durationMs).clamp(0.0, 1.0);

  Map<String, dynamic> toJson() => {
        'title': title,
        'path': path,
        'positionMs': positionMs,
        'durationMs': durationMs,
      };

  factory Episode.fromJson(Map<String, dynamic> j) => Episode(
        title: (j['title'] ?? '') as String,
        path: (j['path'] ?? '') as String,
        positionMs: (j['positionMs'] ?? 0) as int,
        durationMs: (j['durationMs'] ?? 0) as int,
      );
}

class Anime {
  final String id;
  String title;
  String synopsis;
  List<String> tags;
  String? coverPath;
  List<Episode> episodes;
  int updatedAt;
  int lastEpisode;

  Anime({
    required this.id,
    required this.title,
    this.synopsis = '',
    List<String>? tags,
    this.coverPath,
    List<Episode>? episodes,
    int? updatedAt,
    this.lastEpisode = 0,
  })  : tags = tags ?? [],
        episodes = episodes ?? [],
        updatedAt = updatedAt ?? DateTime.now().millisecondsSinceEpoch;

  /// 点“继续播放”时应该播放的集数下标
  int get continueIndex {
    if (episodes.isEmpty) return 0;
    var i = lastEpisode.clamp(0, episodes.length - 1);
    if (episodes[i].finished && i + 1 < episodes.length) i += 1;
    return i;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'synopsis': synopsis,
        'tags': tags,
        'coverPath': coverPath,
        'episodes': episodes.map((e) => e.toJson()).toList(),
        'updatedAt': updatedAt,
        'lastEpisode': lastEpisode,
      };

  factory Anime.fromJson(Map<String, dynamic> j) => Anime(
        id: j['id'] as String,
        title: (j['title'] ?? '') as String,
        synopsis: (j['synopsis'] ?? '') as String,
        tags: ((j['tags'] ?? []) as List).map((e) => e.toString()).toList(),
        coverPath: j['coverPath'] as String?,
        episodes: ((j['episodes'] ?? []) as List)
            .map((e) => Episode.fromJson(e as Map<String, dynamic>))
            .toList(),
        updatedAt: (j['updatedAt'] ?? 0) as int,
        lastEpisode: (j['lastEpisode'] ?? 0) as int,
      );
}
