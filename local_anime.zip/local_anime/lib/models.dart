import 'package:path/path.dart' as p;

class Episode {
  final String path;
  final String name; // 文件名
  final String group; // 子文件夹名（第二季、OVA…），顶层为空
  final int? number;

  const Episode({
    required this.path,
    required this.name,
    required this.group,
    this.number,
  });

  /// 文件名（不含扩展名）
  String get baseName => p.basenameWithoutExtension(name);

  String get title => number != null ? '第$number集' : baseName;

  Map<String, dynamic> toJson() =>
      {'path': path, 'name': name, 'group': group, 'number': number};

  factory Episode.fromJson(Map<String, dynamic> j) => Episode(
        path: j['path'] as String,
        name: j['name'] as String,
        group: (j['group'] ?? '') as String,
        number: j['number'] as int?,
      );
}

class Anime {
  String path; // 文件夹路径
  String uid; // 固定编号，写在 .anime.json 里，收藏夹靠它关联
  String name;
  String synopsis;
  String releaseDate; // 自由填写，留空则不显示
  List<String> tags;
  List<Episode> episodes;
  String? coverPath; // 当前使用的封面文件
  Map<String, int> durations; // 每集时长（毫秒），key 为相对路径
  String? lastEpisode; // 最近打开的一集（相对路径）
  int lastOpenedAt;
  int coverMs; // 0 = 用设置里的默认秒数，>0 = 这部番剧单独截取该毫秒
  String? coverEpisode; // 截取封面用哪一集（相对路径）；null = 第一集
  String? coverStill; // 用哪张剧照当封面（相对路径）；null = 不用，和截取封面互斥
  int addedAt; // 加入番剧库的时间（毫秒时间戳），按添加时间排序用
  int stillCount = 0; // 番剧文件夹最外层的图片数（扫描得到，不写进 .anime.json）
  String? firstStill; // 按文件名自然排序的第一张图片；没有视频的番剧拿它当封面

  Anime({
    required this.path,
    required this.name,
    this.uid = '',
    this.synopsis = '',
    this.releaseDate = '',
    List<String>? tags,
    List<Episode>? episodes,
    this.coverPath,
    Map<String, int>? durations,
    this.lastEpisode,
    this.lastOpenedAt = 0,
    this.coverMs = 0,
    this.addedAt = 0,
  })  : tags = tags ?? [],
        episodes = episodes ?? [],
        durations = durations ?? {};

  String relOf(Episode e) => p.relative(e.path, from: path);

  /// 截取封面用的那一集：指定的还在就用它，否则第一集；没有视频返回 null
  Episode? get coverEpisodeOrFirst {
    if (episodes.isEmpty) return null;
    final rel = coverEpisode;
    if (rel != null) {
      for (final e in episodes) {
        if (relOf(e) == rel) return e;
      }
    }
    return episodes.first;
  }

  /// 这部番剧所有已知集数的时长之和（毫秒），还没读到时长的集按 0 算
  int get totalMs =>
      episodes.fold<int>(0, (sum, e) => sum + (durations[relOf(e)] ?? 0));

  /// 上次打开的那一集是否还在
  bool get hasResume =>
      lastEpisode != null && episodes.any((e) => relOf(e) == lastEpisode);

  /// 继续观看的那一集：上次打开的那集；没有记录就是第一集
  Episode? get resumeEpisode {
    if (episodes.isEmpty) return null;
    if (hasResume) return episodes.firstWhere((e) => relOf(e) == lastEpisode);
    return episodes.first;
  }

  /// 写进番剧文件夹 .anime.json 的内容
  Map<String, dynamic> metaJson() => {
        'version': 1,
        'uid': uid,
        'synopsis': synopsis,
        'releaseDate': releaseDate,
        'tags': tags,
        'durations': durations,
        'lastEpisode': lastEpisode,
        'lastOpenedAt': lastOpenedAt,
        'coverMs': coverMs,
        'coverEpisode': coverEpisode,
        'coverStill': coverStill,
        'addedAt': addedAt,
      };

  void applyMeta(Map<String, dynamic> j) {
    final u = j['uid'];
    if (u is String && u.isNotEmpty) uid = u;
    synopsis = (j['synopsis'] ?? '') as String;
    releaseDate = (j['releaseDate'] ?? '') as String;
    tags = ((j['tags'] ?? []) as List).map((e) => e.toString()).toList();
    durations = ((j['durations'] ?? {}) as Map)
        .map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
    lastEpisode = j['lastEpisode'] as String?;
    lastOpenedAt = (j['lastOpenedAt'] ?? 0) as int;
    coverMs = (j['coverMs'] ?? 0) as int;
    coverEpisode = j['coverEpisode'] as String?;
    coverStill = j['coverStill'] as String?;
    addedAt = (j['addedAt'] ?? 0) as int;
  }

  Map<String, dynamic> cacheJson() => {
        'path': path,
        'name': name,
        'coverPath': coverPath,
        'stillCount': stillCount,
        'firstStill': firstStill,
        'episodes': episodes.map((e) => e.toJson()).toList(),
        ...metaJson(),
      };

  factory Anime.fromCache(Map<String, dynamic> j) {
    final a = Anime(
      path: j['path'] as String,
      name: (j['name'] ?? '') as String,
      coverPath: j['coverPath'] as String?,
      episodes: ((j['episodes'] ?? []) as List)
          .map((e) => Episode.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
    a.stillCount = (j['stillCount'] ?? 0) as int;
    a.firstStill = j['firstStill'] as String?;
    a.applyMeta(j);
    return a;
  }
}

/// 收藏夹：只记录番剧编号，不复制、不移动任何视频
class Collection {
  final String id;
  String name;
  String synopsis;
  List<String> items; // 番剧 uid，按加入顺序
  String? coverUid; // 自定义封面：取自哪部番剧的第一集
  int coverMs; // >0 表示自定义截取该毫秒；0 = 自动（用第一部番剧的封面）
  int createdAt;
  int sortMode; // 本收藏夹自己的排序方式，默认 0 按名称（编号同主页）
  bool sortReverse;

  Collection({
    required this.id,
    required this.name,
    this.synopsis = '',
    List<String>? items,
    this.coverUid,
    this.coverMs = 0,
    int? createdAt,
    this.sortMode = 0,
    this.sortReverse = false,
  })  : items = items ?? [],
        createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  bool contains(String uid) => items.contains(uid);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'synopsis': synopsis,
        'items': items,
        'coverUid': coverUid,
        'coverMs': coverMs,
        'createdAt': createdAt,
        'sortMode': sortMode,
        'sortReverse': sortReverse,
      };

  factory Collection.fromJson(Map<String, dynamic> j) => Collection(
        id: j['id'] as String,
        name: (j['name'] ?? '') as String,
        synopsis: (j['synopsis'] ?? '') as String,
        items: ((j['items'] ?? []) as List).map((e) => e.toString()).toList(),
        coverUid: j['coverUid'] as String?,
        coverMs: (j['coverMs'] ?? 0) as int,
        createdAt: (j['createdAt'] ?? 0) as int,
        sortMode: ((j['sortMode'] ?? 0) as int).clamp(0, 4),
        sortReverse: (j['sortReverse'] ?? false) as bool,
      );
}

/// 例如 2026年9月13日（月、日不补零）
String fmtDateCn(DateTime d) => '${d.year}年${d.month}月${d.day}日';
