import 'package:path/path.dart' as p;

class Episode {
  final String path;
  final String name; // 文件名
  final String group; // 子文件夹名（第二季、OVA…），顶层为空
  final int? number;

  const Episode({
    required this.path,
    required this.name,
    required this.group,
    this.number,
  });

  String get title =>
      number != null ? '第$number集' : p.basenameWithoutExtension(name);

  Map<String, dynamic> toJson() =>
      {'path': path, 'name': name, 'group': group, 'number': number};

  factory Episode.fromJson(Map<String, dynamic> j) => Episode(
        path: j['path'] as String,
        name: j['name'] as String,
        group: (j['group'] ?? '') as String,
        number: j['number'] as int?,
      );
}

class Anime {
  final String path; // 文件夹路径
  String uid; // 固定编号，写在 .anime.json 里，收藏夹靠它关联
  String name;
  String synopsis;
  String releaseDate; // 自由填写，留空则不显示
  List<String> tags;
  List<Episode> episodes;
  String? coverPath; // 当前使用的封面文件
  Set<String> watched; // 已看集（相对路径）
  Map<String, int> durations; // 每集时长（毫秒），key 为相对路径
  String? lastEpisode; // 最近打开的一集（相对路径）
  int lastOpenedAt;
  int coverMs; // 0 = 用设置里的默认秒数，>0 = 这部番剧单独截取该毫秒

  Anime({
    required this.path,
    required this.name,
    this.uid = '',
    this.synopsis = '',
    this.releaseDate = '',
    List<String>? tags,
    List<Episode>? episodes,
    this.coverPath,
    Set<String>? watched,
    Map<String, int>? durations,
    this.lastEpisode,
    this.lastOpenedAt = 0,
    this.coverMs = 0,
  })  : tags = tags ?? [],
        episodes = episodes ?? [],
        watched = watched ?? {},
        durations = durations ?? {};

  String relOf(Episode e) => p.relative(e.path, from: path);
  bool isWatched(Episode e) => watched.contains(relOf(e));
  int get watchedCount => episodes.where(isWatched).length;

  /// 下一集该看哪一集：从最近打开的那集往后找第一个没看的。
  Episode? get nextToWatch {
    if (episodes.isEmpty) return null;
    var start = 0;
    if (lastEpisode != null) {
      final i = episodes.indexWhere((e) => relOf(e) == lastEpisode);
      if (i >= 0) start = i;
    }
    for (var k = 0; k < episodes.length; k++) {
      final e = episodes[(start + k) % episodes.length];
      if (!isWatched(e)) return e;
    }
    return episodes[start];
  }

  /// 写进番剧文件夹 .anime.json 的内容
  Map<String, dynamic> metaJson() => {
        'version': 1,
        'uid': uid,
        'synopsis': synopsis,
        'releaseDate': releaseDate,
        'tags': tags,
        'watched': watched.toList(),
        'durations': durations,
        'lastEpisode': lastEpisode,
        'lastOpenedAt': lastOpenedAt,
        'coverMs': coverMs,
      };

  void applyMeta(Map<String, dynamic> j) {
    final u = j['uid'];
    if (u is String && u.isNotEmpty) uid = u;
    synopsis = (j['synopsis'] ?? '') as String;
    releaseDate = (j['releaseDate'] ?? '') as String;
    tags = ((j['tags'] ?? []) as List).map((e) => e.toString()).toList();
    watched = ((j['watched'] ?? []) as List).map((e) => e.toString()).toSet();
    durations = ((j['durations'] ?? {}) as Map)
        .map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
    lastEpisode = j['lastEpisode'] as String?;
    lastOpenedAt = (j['lastOpenedAt'] ?? 0) as int;
    coverMs = (j['coverMs'] ?? 0) as int;
  }

  Map<String, dynamic> cacheJson() => {
        'path': path,
        'name': name,
        'coverPath': coverPath,
        'episodes': episodes.map((e) => e.toJson()).toList(),
        ...metaJson(),
      };

  factory Anime.fromCache(Map<String, dynamic> j) {
    final a = Anime(
      path: j['path'] as String,
      name: (j['name'] ?? '') as String,
      coverPath: j['coverPath'] as String?,
      episodes: ((j['episodes'] ?? []) as List)
          .map((e) => Episode.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
    a.applyMeta(j);
    return a;
  }
}

/// 收藏夹：只记录番剧编号，不复制、不移动任何视频
class Collection {
  final String id;
  String name;
  String synopsis;
  List<String> items; // 番剧 uid，按加入顺序
  String? coverUid; // 自定义封面：取自哪部番剧的第一集
  int coverMs; // >0 表示自定义截取该毫秒；0 = 自动（用第一部番剧的封面）
  int createdAt;

  Collection({
    required this.id,
    required this.name,
    this.synopsis = '',
    List<String>? items,
    this.coverUid,
    this.coverMs = 0,
    int? createdAt,
  })  : items = items ?? [],
        createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  bool contains(String uid) => items.contains(uid);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'synopsis': synopsis,
        'items': items,
        'coverUid': coverUid,
        'coverMs': coverMs,
        'createdAt': createdAt,
      };

  factory Collection.fromJson(Map<String, dynamic> j) => Collection(
        id: j['id'] as String,
        name: (j['name'] ?? '') as String,
        synopsis: (j['synopsis'] ?? '') as String,
        items: ((j['items'] ?? []) as List).map((e) => e.toString()).toList(),
        coverUid: j['coverUid'] as String?,
        coverMs: (j['coverMs'] ?? 0) as int,
        createdAt: (j['createdAt'] ?? 0) as int,
      );
}
