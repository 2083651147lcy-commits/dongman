import 'package:flutter/foundation.dart';

/// 多选状态：首页（以及以后的收藏夹）共用
class SelectionController extends ChangeNotifier {
  final Set<String> selected = {};

  bool get active => selected.isNotEmpty;
  bool isSelected(String path) => selected.contains(path);

  void toggle(String path) {
    if (!selected.remove(path)) selected.add(path);
    notifyListeners();
  }

  void addAll(Iterable<String> paths) {
    selected.addAll(paths);
    notifyListeners();
  }

  void clear() {
    if (selected.isEmpty) return;
    selected.clear();
    notifyListeners();
  }
}
