import 'dart:io';

import 'package:flutter/material.dart';

class CoverImage extends StatelessWidget {
  final String? path;
  final BoxFit fit;
  const CoverImage({super.key, this.path, this.fit = BoxFit.cover});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final placeholder = Container(
      color: cs.surfaceContainerHighest,
      alignment: Alignment.center,
      child: Icon(Icons.movie_outlined, size: 40, color: cs.outline),
    );
    final pth = path;
    if (pth == null || !File(pth).existsSync()) return placeholder;
    return Image.file(
      File(pth),
      fit: fit,
      errorBuilder: (_, __, ___) => placeholder,
    );
  }
}

String fmtDuration(int ms) {
  final s = ms ~/ 1000;
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  final sec = s % 60;
  String two(int n) => n.toString().padLeft(2, '0');
  return h > 0 ? '$h:${two(m)}:${two(sec)}' : '${two(m)}:${two(sec)}';
}
