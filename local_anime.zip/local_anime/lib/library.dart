import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import 'episode_parser.dart';
import 'models.dart';
import 'settings.dart';

const _videoExts = {
  '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.ts',
  '.m4v', '.rmvb', '.mpg', '.mpeg', '.m2ts', '.3gp',
};

String _fnv(String s) {
  var h = 0x811c9dc5;
  for (final c in s.codeUnits) {
    h ^= c;
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h.toRadixString(16);
}

String _mime(String path) {
  switch (p.extension(path).toLowerCase()) {
    case '.mp4':
    case '.m4v':
      return 'video/mp4';
    case '.mkv':
      return 'video/x-matroska';
    case '.avi':
      return 'video/x-msvideo';
    case '.webm':
      return 'video/webm';
    case '.mov':
      return 'video/quicktime';
    default:
      return 'video/*';
  }
}

int _compareEpisodes(Episode a, Episode b) {
  if (a.group != b.group) {
    if (a.group.isEmpty) return -1;
    if (b.group.isEmpty) return 1;
    return naturalCompare(a.group, b.group);
  }
  final na = a.number ?? (1 << 30);
  final nb = b.number ?? (1 << 30);
  if (na != nb) return na.compareTo(nb);
  return naturalCompare(a.name, b.name);
}

/// 编辑页里的一条剧集：要么是番剧文件夹里已有的视频，要么是待放进来的外部视频
class DraftEp {
  final Episode? existing;
  final String? source;
  DraftEp.existing(Episode e)
      : existing = e,
        source = null;
  DraftEp.source(String path)
      : existing = null,
        source = path;
  String get name => existing?.name ?? p.basename(source!);
  String get baseName => p.basenameWithoutExtension(name);
}

/// 导入 / 保存编辑的结果。done = 已经动过文件（页面可以关闭）；message = 要告诉用户的错误或提醒
class OpResult {
  final bool done;
  final String? message;
  const OpResult(this.done, [this.message]);
}

class BatchResult {
  final int ok;
  final List<String> failed;
  const BatchResult(this.ok, this.failed);
}

class LibraryStore extends ChangeNotifier {
  LibraryStore(this.settings);

  /// 截取画面、读取时长、列出播放器、启动播放：由 MainActivity.kt 里的原生代码实现
  static const _native = MethodChannel('local_anime/native');

  final SettingsStore settings;
  List<Anime> items = [];
  List<Collection> collections = [];
  bool scanning = false;
  bool needPermission = false;
  String? error;

  late Directory _support;
  bool _ready = false;
  bool _coverRunning = false;
  final Set<String> _coverFailed = {};


  List<String> get allTags {
    final set = <String>{};
    for (final a in items) {
      set.addAll(a.tags);
    }
    return set.toList()..sort(naturalCompare);
  }

  Anime? byPath(String path) {
    for (final a in items) {
      if (a.path == path) return a;
    }
    return null;
  }

  // ---------- 初始化与缓存 ----------
  Future<void> init() async {
    _support = await getApplicationSupportDirectory();
    await Directory(p.join(_support.path, 'covers')).create(recursive: true);
    _ready = true;
    await _loadCache();
    await _loadCollections();
    notifyListeners();
    await refresh();
  }

  Future<void> _loadCache() async {
    try {
      final f = File(p.join(_support.path, 'index_cache.json'));
      if (!await f.exists()) return;
      final j = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      if (j['root'] != settings.rootPath) return;
      items = (j['items'] as List)
          .map((e) => Anime.fromCache(e as Map<String, dynamic>))
          .toList();
    } catch (_) {}
  }

  Future<void> _saveCache() async {
    if (!_ready) return;
    try {
      final f = File(p.join(_support.path, 'index_cache.json'));
      await f.writeAsString(jsonEncode({
        'root': settings.rootPath,
        'items': items.map((a) => a.cacheJson()).toList(),
      }));
    } catch (_) {}
  }

  // ---------- 权限 ----------
  Future<bool> ensurePermission({bool request = false}) async {
    if (!Platform.isAndroid) return true;
    if (await Permission.manageExternalStorage.isGranted) return true;
    if (await Permission.storage.isGranted) return true;
    if (request) {
      final r = await Permission.manageExternalStorage.request();
      if (r.isGranted) return true;
      final s = await Permission.storage.request();
      if (s.isGranted) return true;
    }
    // 兜底：能直接读到目录就算有权限
    final root = settings.rootPath;
    if (root != null) {
      try {
        await Directory(root).list().isEmpty;
        return true;
      } catch (_) {}
    }
    return false;
  }

  /// 播放前顺便申请媒体读取权限（部分系统的外部播放器调用需要）
  Future<void> requestMediaPermissions() async {
    if (!Platform.isAndroid) return;
    try {
      await Permission.videos.request();
    } catch (_) {}
  }

  Future<void> changeRoot(String? path) async {
    await settings.update(() => settings.rootPath = path);
    items = [];
    error = null;
    needPermission = false;
    await _loadCollections();
    notifyListeners();
    await _saveCache();
    await refresh(requestPermission: true);
  }

  // ---------- 扫描 ----------
  Future<void> refresh({bool requestPermission = false}) async {
    if (!_ready) return;
    final root = settings.rootPath;
    if (root == null) {
      items = [];
      notifyListeners();
      return;
    }
    if (scanning) return;
    scanning = true;
    error = null;
    notifyListeners();
    var ok = false;
    try {
      ok = await ensurePermission(request: requestPermission);
      needPermission = !ok;
      if (ok) {
        final old = {for (final a in items) a.path: a};
        items = await _scanRoot(root, old);
        await _saveCache();
      }
    } catch (e) {
      error = '$e';
    } finally {
      scanning = false;
      notifyListeners();
    }
    if (ok && error == null) {
      unawaited(generateCovers());
      if (settings.sortMode == 2) unawaited(loadAllDurations());
    }
  }

  Future<List<Anime>> _scanRoot(String root, Map<String, Anime> old) async {
    final dir = Directory(root);
    if (!await dir.exists()) throw '文件夹不存在：$root';
    final subs = <Directory>[];
    await for (final e in dir.list(followLinks: false)) {
      if (e is Directory && !p.basename(e.path).startsWith('.')) subs.add(e);
    }
    final result = <Anime>[];
    for (final d in subs) {
      final a = await _scanAnime(d, old[d.path]);
      if (a != null) result.add(a);
    }
    return result;
  }

  Future<Anime?> _scanAnime(Directory dir, Anime? prev) async {
    final eps = <Episode>[];

    await for (final e in dir.list(followLinks: false)) {
      final base = p.basename(e.path);
      if (base.startsWith('.')) continue;
      if (e is File) {
        final ext = p.extension(base).toLowerCase();
        if (_videoExts.contains(ext)) {
          eps.add(Episode(
            path: e.path,
            name: base,
            group: '',
            number: parseEpisodeNumber(base),
          ));
        }
      } else if (e is Directory) {
        await for (final f in e.list(followLinks: false)) {
          if (f is! File) continue;
          final fb = p.basename(f.path);
          if (fb.startsWith('.')) continue;
          if (_videoExts.contains(p.extension(fb).toLowerCase())) {
            eps.add(Episode(
              path: f.path,
              name: fb,
              group: base,
              number: parseEpisodeNumber(fb),
            ));
          }
        }
      }
    }
    if (eps.isEmpty) return null;
    eps.sort(_compareEpisodes);

    final a = prev ?? Anime(path: dir.path, name: p.basename(dir.path));
    a.name = p.basename(dir.path);
    a.episodes = eps;

    final metaFile = File(p.join(dir.path, '.anime.json'));
    if (await metaFile.exists()) {
      try {
        a.applyMeta(
            jsonDecode(await metaFile.readAsString()) as Map<String, dynamic>);
      } catch (_) {}
    }
    var dirty = false;
    final hadUid = a.uid.isNotEmpty;
    if (!hadUid) {
      a.uid = _newId();
      dirty = true;
    }
    if (a.addedAt <= 0) {
      // 新导入的番剧记当前时间；已经在库里的老番剧用文件夹修改时间当初值
      a.addedAt = hadUid
          ? (await dir.stat()).modified.millisecondsSinceEpoch
          : DateTime.now().millisecondsSinceEpoch;
      dirty = true;
    }
    if (dirty) await _writeMetaFile(a);

    final expected = _expectedCover(a);
    if (await File(expected).exists()) {
      a.coverPath = expected;
    } else {
      a.coverPath = null;
    }
    return a;
  }

  // ---------- 封面 ----------
  String _genCoverPath(Anime a) {
    final ms = a.coverMs > 0 ? a.coverMs : settings.coverSecond * 1000;
    return p.join(_support.path, 'covers', '${_fnv(a.path)}_$ms.jpg');
  }

  /// 这部番剧的封面文件（还没生成时也会返回目标路径）
  String _expectedCover(Anime a) => _genCoverPath(a);

  Future<void> generateCovers() async {
    if (_coverRunning) return;
    _coverRunning = true;
    try {
      for (final a in List.of(items)) {
        if (a.episodes.isEmpty) continue;
        final expected = _expectedCover(a);
        if (a.coverPath == expected && File(expected).existsSync()) continue;
        if (File(expected).existsSync()) {
          a.coverPath = expected;
          notifyListeners();
          continue;
        }
        if (_coverFailed.contains(expected)) continue;
        final out = await _captureCover(a, expected);
        if (out != null) {
          a.coverPath = out;
          notifyListeners();
        } else {
          _coverFailed.add(expected);
        }
      }
      await _saveCache();
      unawaited(generateCollectionCovers());
    } finally {
      _coverRunning = false;
    }
  }

  Future<String?> _captureCover(Anime a, String target) {
    final want = a.coverMs > 0 ? a.coverMs : settings.coverSecond * 1000;
    return _captureFrame(
      video: a.episodes.first.path,
      target: target,
      ms: want,
      prefix: '${_fnv(a.path)}_',
    );
  }

  /// 截取视频画面保存到 target；成功后清掉同前缀的旧封面。
  Future<String?> _captureFrame({
    required String video,
    required String target,
    required int ms,
    required String prefix,
  }) async {
    final tmp = p.join(_support.path, 'covers', '.tmp_${_fnv(target)}.jpg');
    for (final t in {ms, 1000, 0}) {
      try {
        final ok = await _native.invokeMethod<bool>('thumbnail', {
          'video': video,
          'out': tmp,
          'timeMs': t,
          'maxWidth': 480,
        });
        if (ok == true && await File(tmp).exists()) {
          await _cleanPrefix(prefix, keep: target);
          await File(tmp).rename(target);
          return target;
        }
      } catch (_) {}
    }
    return null;
  }

  Future<void> _cleanPrefix(String prefix, {required String keep}) async {
    try {
      final dir = Directory(p.join(_support.path, 'covers'));
      await for (final f in dir.list()) {
        final b = p.basename(f.path);
        if (b.startsWith(prefix) && f.path != keep) {
          await f.delete();
        }
      }
    } catch (_) {}
  }

  Future<void> _cleanOldCovers(Anime a, {required String keep}) =>
      _cleanPrefix('${_fnv(a.path)}_', keep: keep);

  /// 指定截取第几秒作封面
  Future<void> setCoverSecond(Anime a, int seconds) async {
    a.coverMs = (seconds < 1 ? 1 : seconds) * 1000;
    a.coverPath = null;
    _coverFailed.clear();
    await saveMeta(a);
    unawaited(generateCovers());
  }

  /// 恢复默认：用设置里的默认秒数截取
  Future<void> useAutoCover(Anime a) async {
    a.coverMs = 0;
    a.coverPath = null;
    _coverFailed.clear();
    await saveMeta(a);
    unawaited(generateCovers());
  }

  /// 全局默认截取秒数变了，重新生成自动封面
  void onDefaultCoverSecondChanged() {
    _coverFailed.clear();
    unawaited(generateCovers());
  }

  // ---------- 元数据 ----------
  Future<void> _writeMetaFile(Anime a) async {
    try {
      await File(p.join(a.path, '.anime.json'))
          .writeAsString(jsonEncode(a.metaJson()));
    } catch (_) {
      // 没有写入权限时，只保存在应用内部缓存里
    }
  }

  Future<void> saveMeta(Anime a) async {
    await _writeMetaFile(a);
    await _saveCache();
    notifyListeners();
  }

  // ---------- 收藏夹 ----------
  String _newId() =>
      '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${Random().nextInt(1 << 20).toRadixString(36)}';

  Collection? collectionById(String id) {
    for (final c in collections) {
      if (c.id == id) return c;
    }
    return null;
  }

  Anime? byUid(String uid) {
    if (uid.isEmpty) return null;
    for (final a in items) {
      if (a.uid == uid) return a;
    }
    return null;
  }

  /// 收藏夹里现在还存在的番剧（按加入顺序）。文件夹被移走的会被忽略。
  List<Anime> animesOf(Collection c) {
    final map = {for (final a in items) a.uid: a};
    return [
      for (final u in c.items)
        if (map[u] != null) map[u]!,
    ];
  }

  int countOf(Collection c) => animesOf(c).length;

  String _colCoverPath(Collection c, Anime src, int ms) => p.join(
      _support.path, 'covers', 'c_${_fnv(c.id)}_${_fnv(src.uid)}_$ms.jpg');

  /// 收藏夹封面：自定义截取优先，否则用里面第一部番剧的封面
  String? coverOf(Collection c) {
    if (!_ready) return null;
    if (c.coverUid != null && c.coverMs > 0) {
      final src = byUid(c.coverUid!);
      if (src != null) {
        final f = _colCoverPath(c, src, c.coverMs);
        if (File(f).existsSync()) return f;
      }
    }
    for (final a in animesOf(c)) {
      if (a.coverPath != null) return a.coverPath;
    }
    return null;
  }

  bool _colCoverRunning = false;

  Future<void> generateCollectionCovers() async {
    if (!_ready || _colCoverRunning) return;
    _colCoverRunning = true;
    try {
      for (final c in List.of(collections)) {
        if (c.coverUid == null || c.coverMs <= 0) continue;
        final src = byUid(c.coverUid!);
        if (src == null || src.episodes.isEmpty) continue;
        final target = _colCoverPath(c, src, c.coverMs);
        if (File(target).existsSync() || _coverFailed.contains(target)) continue;
        final out = await _captureFrame(
          video: src.episodes.first.path,
          target: target,
          ms: c.coverMs,
          prefix: 'c_${_fnv(c.id)}_',
        );
        if (out == null) _coverFailed.add(target);
        notifyListeners();
      }
    } finally {
      _colCoverRunning = false;
    }
  }

  List<Collection> _parseCollections(dynamic j) {
    final list = (j is Map ? j['collections'] : null) as List?;
    if (list == null) return [];
    return list
        .map((e) => Collection.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> _loadCollections() async {
    collections = [];
    final root = settings.rootPath;
    try {
      if (root != null) {
        final f = File(p.join(root, '.collections.json'));
        if (await f.exists()) {
          collections = _parseCollections(jsonDecode(await f.readAsString()));
          return;
        }
      }
    } catch (_) {}
    try {
      final f = File(p.join(_support.path, 'collections_cache.json'));
      if (await f.exists()) {
        final j = jsonDecode(await f.readAsString());
        if (j is Map && j['root'] == root) collections = _parseCollections(j);
      }
    } catch (_) {}
  }

  /// 收藏夹数据写两份：动漫库根目录的隐藏文件（随库走）+ 应用内部缓存
  Future<void> saveCollections() async {
    final data = jsonEncode({
      'version': 1,
      'root': settings.rootPath,
      'collections': collections.map((c) => c.toJson()).toList(),
    });
    final root = settings.rootPath;
    if (root != null) {
      try {
        await File(p.join(root, '.collections.json')).writeAsString(data);
      } catch (_) {}
    }
    if (_ready) {
      try {
        await File(p.join(_support.path, 'collections_cache.json'))
            .writeAsString(data);
      } catch (_) {}
    }
  }

  Future<Collection> createCollection(String name, String synopsis) async {
    final c = Collection(id: _newId(), name: name, synopsis: synopsis);
    collections.add(c);
    await saveCollections();
    notifyListeners();
    return c;
  }

  Future<void> updateCollection(Collection c) async {
    await saveCollections();
    notifyListeners();
    unawaited(generateCollectionCovers());
  }

  Future<void> deleteCollection(Collection c) async {
    collections.removeWhere((x) => x.id == c.id);
    if (_ready) await _cleanPrefix('c_${_fnv(c.id)}_', keep: '');
    await saveCollections();
    notifyListeners();
  }

  /// changes：收藏夹 id → true（把这些番剧都加进去）/ false（都移出来）
  Future<void> applyMembership(
      List<Anime> animes, Map<String, bool> changes) async {
    for (final e in changes.entries) {
      final c = collectionById(e.key);
      if (c == null) continue;
      for (final a in animes) {
        if (a.uid.isEmpty) continue;
        if (e.value) {
          if (!c.items.contains(a.uid)) c.items.add(a.uid);
        } else {
          c.items.remove(a.uid);
        }
      }
    }
    await saveCollections();
    notifyListeners();
  }

  Future<void> removeFromCollection(Collection c, List<Anime> list) async {
    final uids = list.map((a) => a.uid).toSet();
    c.items.removeWhere(uids.contains);
    await saveCollections();
    notifyListeners();
  }

  Future<void> _purgeFromCollections(Set<String> uids) async {
    for (final c in collections) {
      c.items.removeWhere(uids.contains);
    }
    await saveCollections();
  }

  // ---------- 历史记录 ----------
  /// 最近打开过的 n 部番剧
  List<Anime> recent(int n) {
    final l = items.where((a) => a.lastOpenedAt > 0).toList()
      ..sort((a, b) => b.lastOpenedAt.compareTo(a.lastOpenedAt));
    return l.take(n).toList();
  }

  /// 只是从历史里去掉，视频不受影响
  Future<void> removeFromHistory(Anime a) async {
    a.lastOpenedAt = 0;
    await saveMeta(a);
  }

  Future<void> clearHistory() async {
    for (final a in items) {
      if (a.lastOpenedAt > 0) {
        a.lastOpenedAt = 0;
        await _writeMetaFile(a);
      }
    }
    await _saveCache();
    notifyListeners();
  }

  // ---------- 删除 ----------
  /// 这些番剧文件夹占用的总字节数
  Future<int> totalSize(List<Anime> list) async {
    var total = 0;
    for (final a in list) {
      try {
        await for (final e
            in Directory(a.path).list(recursive: true, followLinks: false)) {
          if (e is File) {
            try {
              total += await e.length();
            } catch (_) {}
          }
        }
      } catch (_) {}
    }
    return total;
  }

  /// 删除番剧文件夹（连同里面的视频）。返回删除失败的番剧名。
  Future<List<String>> deleteAnimes(List<Anime> list) async {
    final root = settings.rootPath;
    final failed = <String>[];
    final deletedUids = <String>{};
    for (final a in list) {
      try {
        // 安全检查：只允许删除动漫库根目录下的直接子文件夹
        if (root == null || !p.equals(p.dirname(a.path), root)) {
          failed.add(a.name);
          continue;
        }
        final d = Directory(a.path);
        if (await d.exists()) await d.delete(recursive: true);
        await _cleanOldCovers(a, keep: '');
        items.removeWhere((x) => x.path == a.path);
        if (a.uid.isNotEmpty) deletedUids.add(a.uid);
      } catch (_) {
        failed.add(a.name);
      }
    }
    if (deletedUids.isNotEmpty) await _purgeFromCollections(deletedUids);
    await _saveCache();
    notifyListeners();
    return failed;
  }

  // ---------- 导入 / 编辑剧集 ----------
  static bool isVideoFile(String path) =>
      _videoExts.contains(p.extension(path).toLowerCase());

  /// 文件夹里直接下一层的视频（不进子文件夹），按文件名自然排序
  Future<List<String>> listVideos(String folder) async {
    final out = <String>[];
    await for (final e in Directory(folder).list(followLinks: false)) {
      if (e is File &&
          !p.basename(e.path).startsWith('.') &&
          isVideoFile(e.path)) {
        out.add(e.path);
      }
    }
    out.sort((a, b) => naturalCompare(p.basename(a), p.basename(b)));
    return out;
  }

  String? _nameError(String name) {
    if (name.isEmpty) return '名称不能为空';
    if (name.contains('/') || name.contains('\\') || name.startsWith('.')) {
      return '名称里不能有 / 或 \\，也不能以 . 开头';
    }
    return null;
  }

  bool _exists(String path) =>
      FileSystemEntity.typeSync(path) != FileSystemEntityType.notFound;

  /// 同名文件夹已存在时自动加“ (2)”“ (3)”
  String _uniqueDir(String parent, String name) {
    var c = p.join(parent, name);
    for (var i = 2; _exists(c); i++) {
      c = p.join(parent, '$name ($i)');
    }
    return c;
  }

  String _uniqueFile(String dir, String fileName) {
    final base = p.basenameWithoutExtension(fileName);
    final ext = p.extension(fileName);
    var c = p.join(dir, fileName);
    for (var i = 2; _exists(c); i++) {
      c = p.join(dir, '$base ($i)$ext');
    }
    return c;
  }

  /// 把视频放进目标位置。移动：同一个存储里是瞬间完成；
  /// 跨存储（比如 SD 卡到手机）没法直接移动，会先复制再删原文件。
  Future<void> _transfer(String src, String dest, bool copy) async {
    final f = File(src);
    try {
      if (copy) {
        await f.copy(dest);
      } else {
        try {
          await f.rename(dest);
        } on FileSystemException {
          await f.copy(dest);
          await f.delete();
        }
      }
    } catch (_) {
      // 失败了就清掉没拷完的残留
      try {
        final d = File(dest);
        if (await d.exists() && !p.equals(src, dest)) await d.delete();
      } catch (_) {}
      rethrow;
    }
  }

  /// 导入：新建番剧文件夹，把视频放进去，再写入填好的信息
  Future<OpResult> importAnime({
    required String name,
    required String synopsis,
    required String release,
    required List<String> tags,
    required List<String> sources,
    required bool copy,
    void Function(String)? progress,
  }) async {
    final root = settings.rootPath;
    if (root == null) return const OpResult(false, '还没有选择动漫库文件夹');
    final n = name.trim();
    final err = _nameError(n);
    if (err != null) return OpResult(false, err);
    if (sources.isEmpty) return const OpResult(false, '至少要有一个视频');

    final dirPath = _uniqueDir(root, n);
    final dir = Directory(dirPath);
    await dir.create();
    final verb = copy ? '复制' : '移动';
    final problems = <String>[];
    var okCount = 0;
    var i = 0;
    for (final s in sources) {
      i++;
      progress?.call('$verb $i/${sources.length}：${p.basename(s)}');
      try {
        await _transfer(s, _uniqueFile(dirPath, p.basename(s)), copy);
        okCount++;
      } catch (_) {
        problems.add('$verb失败：${p.basename(s)}');
      }
    }
    if (okCount == 0) {
      try {
        await dir.delete(recursive: true);
      } catch (_) {}
      return OpResult(false, problems.join('\n'));
    }
    progress?.call('正在整理…');
    final a = await _scanAnime(dir, null);
    if (a == null) return const OpResult(true, '没有找到可用的视频');
    a.synopsis = synopsis.trim();
    a.releaseDate = release.trim();
    a.tags = List.of(tags);
    await _writeMetaFile(a);
    items.add(a);
    await _saveCache();
    notifyListeners();
    unawaited(generateCovers());
    return OpResult(true, problems.isEmpty ? null : problems.join('\n'));
  }

  /// 批量导入：每个视频各成一部番剧（名称取文件名），不需要填信息
  Future<BatchResult> batchImport(
    List<String> videos, {
    required bool copy,
    void Function(String)? progress,
  }) async {
    final root = settings.rootPath;
    if (root == null) return const BatchResult(0, ['还没有选择动漫库文件夹']);
    var ok = 0;
    final failed = <String>[];
    var i = 0;
    for (final v in videos) {
      i++;
      final base = p.basenameWithoutExtension(v);
      progress?.call('$i/${videos.length}：$base');
      if (_nameError(base) != null) {
        failed.add(base);
        continue;
      }
      Directory? dir;
      try {
        final dp = _uniqueDir(root, base);
        dir = Directory(dp);
        await dir.create();
        await _transfer(v, p.join(dp, p.basename(v)), copy);
        final a = await _scanAnime(dir, null);
        if (a != null) {
          a.releaseDate = fmtDateCn(DateTime.now());
          await _writeMetaFile(a);
          items.add(a);
          ok++;
        } else {
          failed.add(base);
        }
      } catch (_) {
        failed.add(base);
        try {
          if (dir != null && await dir.exists() && await dir.list().isEmpty) {
            await dir.delete();
          }
        } catch (_) {}
      }
    }
    await _saveCache();
    notifyListeners();
    unawaited(generateCovers());
    return BatchResult(ok, failed);
  }

  /// 保存编辑：信息、名称（= 文件夹名）、剧集的增删和更换。
  /// 不再出现在 eps 里的已有视频会被永久删除；外部视频会移动/复制进番剧文件夹。
  Future<OpResult> applyEdit(
    Anime a, {
    required String name,
    required String synopsis,
    required String release,
    required List<String> tags,
    required List<DraftEp> eps,
    required bool copy,
    void Function(String)? progress,
  }) async {
    final root = settings.rootPath;
    if (root == null) return const OpResult(false, '还没有选择动漫库文件夹');
    final newName = name.trim();
    final err = _nameError(newName);
    if (err != null) return OpResult(false, err);
    if (eps.isEmpty) {
      return const OpResult(false, '至少要保留一集；想整部删除请在主页删除这部番剧');
    }
    final rename = newName != a.name;
    if (rename && _exists(p.join(root, newName))) {
      return const OpResult(false, '已经有同名的文件夹了');
    }

    final keep = {
      for (final d in eps)
        if (d.existing != null) d.existing!.path
    };
    final removed = a.episodes.where((e) => !keep.contains(e.path)).toList();
    final adds = [
      for (final d in eps)
        if (d.source != null) d.source!
    ].where((s) => !p.isWithin(a.path, s)).toList();

    // 先把信息写进文件夹，后面重新扫描时才不会被旧内容覆盖
    a.synopsis = synopsis.trim();
    a.releaseDate = release.trim();
    a.tags = List.of(tags);
    await _writeMetaFile(a);

    final problems = <String>[];
    for (final e in removed) {
      progress?.call('正在删除：${e.name}');
      try {
        await File(e.path).delete();
      } catch (_) {
        problems.add('删除失败：${e.name}');
      }
    }
    final verb = copy ? '复制' : '移动';
    var i = 0;
    for (final s in adds) {
      i++;
      progress?.call('$verb $i/${adds.length}：${p.basename(s)}');
      try {
        await _transfer(s, _uniqueFile(a.path, p.basename(s)), copy);
      } catch (_) {
        problems.add('$verb失败：${p.basename(s)}');
      }
    }

    if (removed.isNotEmpty || adds.isNotEmpty || rename) {
      // 封面文件名跟文件夹路径有关，剧集变了封面也该重新截
      await _cleanOldCovers(a, keep: '');
      a.coverPath = null;
    }
    if (rename) {
      progress?.call('正在改文件夹名…');
      try {
        final np = p.join(root, newName);
        await Directory(a.path).rename(np);
        a.path = np;
        a.name = newName;
      } catch (_) {
        problems.add('文件夹改名失败');
      }
    }

    progress?.call('正在整理…');
    final fresh = await _scanAnime(Directory(a.path), a);
    if (fresh != null) {
      final rels = {for (final e in a.episodes) a.relOf(e)};
      a.durations.removeWhere((k, _) => !rels.contains(k));
      if (a.lastEpisode != null && !rels.contains(a.lastEpisode)) {
        a.lastEpisode = null;
      }
      await _writeMetaFile(a);
    }
    await _saveCache();
    notifyListeners();
    unawaited(generateCovers());
    return OpResult(true, problems.isEmpty ? null : problems.join('\n'));
  }

  // ---------- 时长 ----------
  final Set<String> _durBusy = {};
  bool durationsLoading = false;

  /// 把一集的视频文件改名（扩展名不变）。成功返回 null，失败返回原因。
  Future<String?> renameEpisode(Anime a, Episode e, String newBase) async {
    final base = newBase.trim();
    if (base.isEmpty) return '名字不能为空';
    if (base.contains('/') || base.contains('\\') || base.startsWith('.')) {
      return '名字里不能有 / 或 \\，也不能以 . 开头';
    }
    final newName = '$base${p.extension(e.name)}';
    if (newName == e.name) return null;
    final newPath = p.join(p.dirname(e.path), newName);
    if (await File(newPath).exists()) return '已经有同名文件了';
    final oldRel = a.relOf(e);
    try {
      await File(e.path).rename(newPath);
    } catch (err) {
      return '改名失败：$err';
    }
    final newEp = Episode(
      path: newPath,
      name: newName,
      group: e.group,
      number: parseEpisodeNumber(newName),
    );
    final newRel = a.relOf(newEp);
    // 时长、最近打开的集数都是按相对路径记的，要跟着改
    final d = a.durations.remove(oldRel);
    if (d != null) a.durations[newRel] = d;
    if (a.lastEpisode == oldRel) a.lastEpisode = newRel;
    final eps = [...a.episodes.where((x) => x.path != e.path), newEp];
    eps.sort(_compareEpisodes);
    a.episodes = eps;
    await saveMeta(a);
    return null;
  }

  /// 按总时长排序用：后台把所有番剧每一集的时长读出来（只读还没有记录的）
  Future<void> loadAllDurations() async {
    if (durationsLoading) return;
    durationsLoading = true;
    notifyListeners();
    try {
      for (final a in List.of(items)) {
        await loadDurations(a);
      }
    } finally {
      durationsLoading = false;
      notifyListeners();
    }
  }

  /// 后台读取这部番剧每一集的时长（只读还没有记录的），结果存进 .anime.json
  Future<void> loadDurations(Anime a) async {
    if (!_durBusy.add(a.path)) return;
    var changed = false;
    var pending = 0;
    try {
      for (final e in List.of(a.episodes)) {
        final key = a.relOf(e);
        if ((a.durations[key] ?? 0) > 0) continue;
        try {
          final ms = await _native.invokeMethod<int>('duration', {'path': e.path});
          if (ms != null && ms > 0) {
            a.durations[key] = ms;
            changed = true;
            if (++pending >= 3) {
              pending = 0;
              notifyListeners();
            }
          }
        } on MissingPluginException {
          break;
        } catch (_) {}
      }
      if (changed) await saveMeta(a);
    } finally {
      _durBusy.remove(a.path);
    }
  }

  // ---------- 外部播放器 ----------
  /// 手机上能播放视频的应用
  Future<List<({String label, String package})>> listPlayers() async {
    final r = await _native.invokeMethod<List<dynamic>>('listPlayers');
    final list = (r ?? []).map((e) {
      final m = Map<String, dynamic>.from(e as Map);
      return (label: m['label'] as String, package: m['package'] as String);
    }).toList();
    list.sort((a, b) => a.label.compareTo(b.label));
    return list;
  }

  /// 返回 'ok' / 'noapp' / 错误信息
  Future<String> _launch(String path, String? pkg) async {
    try {
      final r = await _native.invokeMethod<String>('play', {
        'path': path,
        'mime': _mime(path),
        'package': pkg,
      });
      return r ?? 'error';
    } on MissingPluginException {
      // 原生部分缺失时，退回到通用的打开方式
      final r = await OpenFilex.open(path, type: _mime(path));
      if (r.type == ResultType.done) return 'ok';
      if (r.type == ResultType.noAppToOpen) return 'noapp';
      return r.message.isEmpty ? '打开失败' : r.message;
    } on PlatformException catch (e) {
      return e.message ?? '打开失败';
    }
  }

  // ---------- 播放 ----------
  /// 用外部播放器打开。成功返回 null；失败或需要提示时返回一句话。
  Future<String?> play(Anime a, Episode e) async {
    await requestMediaPermissions();
    String? notice;
    var res = await _launch(e.path, settings.playerPackage);
    if (res == 'noapp' && settings.playerPackage != null) {
      await settings.update(() {
        settings.playerPackage = null;
        settings.playerLabel = null;
      });
      notice = '默认播放器已无法使用，已改回每次询问';
      res = await _launch(e.path, null);
    }
    if (res == 'noapp') return '手机上没有可以播放这个视频的应用';
    if (res != 'ok') return res;
    a.lastEpisode = a.relOf(e);
    a.lastOpenedAt = DateTime.now().millisecondsSinceEpoch;
    await saveMeta(a);
    return notice;
  }
}
