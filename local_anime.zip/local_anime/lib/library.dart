import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

import 'episode_parser.dart';
import 'models.dart';
import 'settings.dart';

const _videoExts = {
  '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.ts',
  '.m4v', '.rmvb', '.mpg', '.mpeg', '.m2ts', '.3gp',
};
const _imageExts = {'.jpg', '.jpeg', '.png', '.webp'};
const _coverNames = {'cover', 'folder', 'poster', 'thumb', 'front'};

String _fnv(String s) {
  var h = 0x811c9dc5;
  for (final c in s.codeUnits) {
    h ^= c;
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h.toRadixString(16);
}

String _mime(String path) {
  switch (p.extension(path).toLowerCase()) {
    case '.mp4':
    case '.m4v':
      return 'video/mp4';
    case '.mkv':
      return 'video/x-matroska';
    case '.avi':
      return 'video/x-msvideo';
    case '.webm':
      return 'video/webm';
    case '.mov':
      return 'video/quicktime';
    default:
      return 'video/*';
  }
}

int _compareEpisodes(Episode a, Episode b) {
  if (a.group != b.group) {
    if (a.group.isEmpty) return -1;
    if (b.group.isEmpty) return 1;
    return naturalCompare(a.group, b.group);
  }
  final na = a.number ?? (1 << 30);
  final nb = b.number ?? (1 << 30);
  if (na != nb) return na.compareTo(nb);
  return naturalCompare(a.name, b.name);
}

class LibraryStore extends ChangeNotifier {
  LibraryStore(this.settings);

  final SettingsStore settings;
  List<Anime> items = [];
  bool scanning = false;
  bool needPermission = false;
  String? error;

  late Directory _support;
  bool _ready = false;
  bool _coverRunning = false;
  final Set<String> _coverFailed = {};

  List<Anime> get visible => items.where((a) => !a.hidden).toList();
  List<Anime> get hiddenItems => items.where((a) => a.hidden).toList();

  List<String> get allTags {
    final set = <String>{};
    for (final a in items) {
      if (!a.hidden) set.addAll(a.tags);
    }
    return set.toList()..sort(naturalCompare);
  }

  Anime? byPath(String path) {
    for (final a in items) {
      if (a.path == path) return a;
    }
    return null;
  }

  // ---------- 初始化与缓存 ----------
  Future<void> init() async {
    _support = await getApplicationSupportDirectory();
    await Directory(p.join(_support.path, 'covers')).create(recursive: true);
    _ready = true;
    await _loadCache();
    notifyListeners();
    await refresh();
  }

  Future<void> _loadCache() async {
    try {
      final f = File(p.join(_support.path, 'index_cache.json'));
      if (!await f.exists()) return;
      final j = jsonDecode(await f.readAsString()) as Map<String, dynamic>;
      if (j['root'] != settings.rootPath) return;
      items = (j['items'] as List)
          .map((e) => Anime.fromCache(e as Map<String, dynamic>))
          .toList();
    } catch (_) {}
  }

  Future<void> _saveCache() async {
    if (!_ready) return;
    try {
      final f = File(p.join(_support.path, 'index_cache.json'));
      await f.writeAsString(jsonEncode({
        'root': settings.rootPath,
        'items': items.map((a) => a.cacheJson()).toList(),
      }));
    } catch (_) {}
  }

  // ---------- 权限 ----------
  Future<bool> ensurePermission({bool request = false}) async {
    if (!Platform.isAndroid) return true;
    if (await Permission.manageExternalStorage.isGranted) return true;
    if (await Permission.storage.isGranted) return true;
    if (request) {
      final r = await Permission.manageExternalStorage.request();
      if (r.isGranted) return true;
      final s = await Permission.storage.request();
      if (s.isGranted) return true;
    }
    // 兜底：能直接读到目录就算有权限
    final root = settings.rootPath;
    if (root != null) {
      try {
        await Directory(root).list().isEmpty;
        return true;
      } catch (_) {}
    }
    return false;
  }

  /// 播放前顺便申请媒体读取权限（部分系统的外部播放器调用需要）
  Future<void> requestMediaPermissions() async {
    if (!Platform.isAndroid) return;
    try {
      await Permission.videos.request();
    } catch (_) {}
  }

  Future<void> changeRoot(String? path) async {
    await settings.update(() => settings.rootPath = path);
    items = [];
    error = null;
    needPermission = false;
    notifyListeners();
    await _saveCache();
    await refresh(requestPermission: true);
  }

  // ---------- 扫描 ----------
  Future<void> refresh({bool requestPermission = false}) async {
    if (!_ready) return;
    final root = settings.rootPath;
    if (root == null) {
      items = [];
      notifyListeners();
      return;
    }
    if (scanning) return;
    scanning = true;
    error = null;
    notifyListeners();
    var ok = false;
    try {
      ok = await ensurePermission(request: requestPermission);
      needPermission = !ok;
      if (ok) {
        final old = {for (final a in items) a.path: a};
        items = await _scanRoot(root, old);
        await _saveCache();
      }
    } catch (e) {
      error = '$e';
    } finally {
      scanning = false;
      notifyListeners();
    }
    if (ok && error == null) unawaited(generateCovers());
  }

  Future<List<Anime>> _scanRoot(String root, Map<String, Anime> old) async {
    final dir = Directory(root);
    if (!await dir.exists()) throw '文件夹不存在：$root';
    final subs = <Directory>[];
    await for (final e in dir.list(followLinks: false)) {
      if (e is Directory && !p.basename(e.path).startsWith('.')) subs.add(e);
    }
    final result = <Anime>[];
    for (final d in subs) {
      final a = await _scanAnime(d, old[d.path]);
      if (a != null) result.add(a);
    }
    return result;
  }

  Future<Anime?> _scanAnime(Directory dir, Anime? prev) async {
    final eps = <Episode>[];
    String? namedCover;
    String? anyImage;

    await for (final e in dir.list(followLinks: false)) {
      final base = p.basename(e.path);
      if (base.startsWith('.')) continue;
      if (e is File) {
        final ext = p.extension(base).toLowerCase();
        if (_videoExts.contains(ext)) {
          eps.add(Episode(
            path: e.path,
            name: base,
            group: '',
            number: parseEpisodeNumber(base),
          ));
        } else if (_imageExts.contains(ext)) {
          final stem = p.basenameWithoutExtension(base).toLowerCase();
          if (_coverNames.contains(stem)) namedCover ??= e.path;
          anyImage ??= e.path;
        }
      } else if (e is Directory) {
        await for (final f in e.list(followLinks: false)) {
          if (f is! File) continue;
          final fb = p.basename(f.path);
          if (fb.startsWith('.')) continue;
          if (_videoExts.contains(p.extension(fb).toLowerCase())) {
            eps.add(Episode(
              path: f.path,
              name: fb,
              group: base,
              number: parseEpisodeNumber(fb),
            ));
          }
        }
      }
    }
    if (eps.isEmpty) return null;
    eps.sort(_compareEpisodes);

    final a = prev ?? Anime(path: dir.path, name: p.basename(dir.path));
    a.name = p.basename(dir.path);
    a.episodes = eps;
    a.folderCover = namedCover ?? anyImage;

    final metaFile = File(p.join(dir.path, '.anime.json'));
    if (await metaFile.exists()) {
      try {
        a.applyMeta(
            jsonDecode(await metaFile.readAsString()) as Map<String, dynamic>);
      } catch (_) {}
    }

    final expected = _expectedCover(a);
    if (expected != null && await File(expected).exists()) {
      a.coverPath = expected;
    } else {
      a.coverPath = null;
    }
    return a;
  }

  // ---------- 封面 ----------
  String _genCoverPath(Anime a) {
    final ms = a.coverMs > 0 ? a.coverMs : settings.coverSecond * 1000;
    return p.join(_support.path, 'covers', '${_fnv(a.path)}_$ms.jpg');
  }

  /// 这部番剧"应该"用哪个封面文件（还没生成时也会返回目标路径）
  String? _expectedCover(Anime a) {
    if (a.coverMs == 0 && a.folderCover != null) return a.folderCover;
    return _genCoverPath(a);
  }

  Future<void> generateCovers() async {
    if (_coverRunning) return;
    _coverRunning = true;
    try {
      for (final a in List.of(items)) {
        if (a.episodes.isEmpty) continue;
        final expected = _expectedCover(a);
        if (expected == null) continue;
        if (a.coverPath == expected && File(expected).existsSync()) continue;
        if (File(expected).existsSync()) {
          a.coverPath = expected;
          notifyListeners();
          continue;
        }
        if (_coverFailed.contains(expected)) continue;
        final out = await _captureCover(a, expected);
        if (out != null) {
          a.coverPath = out;
          notifyListeners();
        } else {
          _coverFailed.add(expected);
        }
      }
      await _saveCache();
    } finally {
      _coverRunning = false;
    }
  }

  Future<String?> _captureCover(Anime a, String target) async {
    final video = a.episodes.first.path;
    final want = a.coverMs > 0 ? a.coverMs : settings.coverSecond * 1000;
    for (final t in {want, 1000, 0}) {
      try {
        final tmp = await VideoThumbnail.thumbnailFile(
          video: video,
          imageFormat: ImageFormat.JPEG,
          timeMs: t,
          maxWidth: 480,
          quality: 80,
        );
        if (tmp != null && await File(tmp).exists()) {
          await _cleanOldCovers(a, keep: target);
          await File(tmp).copy(target);
          try {
            await File(tmp).delete();
          } catch (_) {}
          return target;
        }
      } catch (_) {}
    }
    return null;
  }

  Future<void> _cleanOldCovers(Anime a, {required String keep}) async {
    try {
      final prefix = '${_fnv(a.path)}_';
      final dir = Directory(p.join(_support.path, 'covers'));
      await for (final f in dir.list()) {
        final b = p.basename(f.path);
        if (b.startsWith(prefix) && f.path != keep) {
          await f.delete();
        }
      }
    } catch (_) {}
  }

  /// 指定截取第几秒作封面
  Future<void> setCoverSecond(Anime a, int seconds) async {
    a.coverMs = seconds * 1000;
    a.coverPath = null;
    _coverFailed.clear();
    await saveMeta(a);
    unawaited(generateCovers());
  }

  /// 改回自动：优先用文件夹里的图片
  Future<void> useAutoCover(Anime a) async {
    a.coverMs = 0;
    a.coverPath = null;
    _coverFailed.clear();
    await saveMeta(a);
    unawaited(generateCovers());
  }

  /// 全局默认截取秒数变了，重新生成自动封面
  void onDefaultCoverSecondChanged() {
    _coverFailed.clear();
    unawaited(generateCovers());
  }

  // ---------- 元数据 ----------
  Future<void> saveMeta(Anime a) async {
    try {
      await File(p.join(a.path, '.anime.json'))
          .writeAsString(jsonEncode(a.metaJson()));
    } catch (_) {
      // 没有写入权限时，只保存在应用内部缓存里
    }
    await _saveCache();
    notifyListeners();
  }

  Future<void> toggleWatched(Anime a, Episode e) async {
    final key = a.relOf(e);
    if (!a.watched.remove(key)) a.watched.add(key);
    await saveMeta(a);
  }

  Future<void> markAll(Anime a, bool watched) async {
    if (watched) {
      a.watched = a.episodes.map(a.relOf).toSet();
    } else {
      a.watched = {};
    }
    await saveMeta(a);
  }

  Future<void> setHidden(Anime a, bool hidden) async {
    a.hidden = hidden;
    await saveMeta(a);
  }

  // ---------- 播放 ----------
  /// 用外部播放器打开。成功返回 null，失败返回原因。
  Future<String?> play(Anime a, Episode e) async {
    await requestMediaPermissions();
    final r = await OpenFilex.open(e.path, type: _mime(e.path));
    if (r.type != ResultType.done) {
      return r.type == ResultType.noAppToOpen
          ? '手机上没有可以播放这个视频的应用'
          : (r.message.isEmpty ? '打开失败' : r.message);
    }
    a.lastEpisode = a.relOf(e);
    a.lastOpenedAt = DateTime.now().millisecondsSinceEpoch;
    if (settings.autoMarkWatched) a.watched.add(a.relOf(e));
    await saveMeta(a);
    return null;
  }
}
