import 'package:flutter/material.dart';

import '../settings.dart';

/// 主页、收藏页、收藏夹详情页共用的卡片网格：
/// 列数、间距都读设置，所以设置里一改，几处一起变。
class CardGrid extends StatelessWidget {
  final SettingsStore settings;
  final int itemCount;
  final Widget Function(BuildContext context, int index) itemBuilder;
  final Widget? header;
  final ScrollController? controller;

  const CardGrid({
    super.key,
    required this.settings,
    required this.itemCount,
    required this.itemBuilder,
    this.header,
    this.controller,
  });

  @override
  Widget build(BuildContext context) {
    final landscape =
        MediaQuery.of(context).orientation == Orientation.landscape;
    final cols = landscape ? settings.landscapeCols : settings.portraitCols;
    final gap = settings.gap;
    final rows = (itemCount / cols).ceil();
    final hasHeader = header != null;

    return ListView.builder(
      controller: controller,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: EdgeInsets.only(
          top: 8, bottom: 24 + MediaQuery.of(context).padding.bottom),
      itemCount: rows + (hasHeader ? 1 : 0),
      itemBuilder: (context, i) {
        if (hasHeader && i == 0) return header!;
        final r = i - (hasHeader ? 1 : 0);
        final children = <Widget>[];
        for (var c = 0; c < cols; c++) {
          final idx = r * cols + c;
          if (c > 0) children.add(SizedBox(width: gap));
          children.add(Expanded(
            child: idx < itemCount ? itemBuilder(context, idx) : const SizedBox(),
          ));
        }
        return Padding(
          padding: EdgeInsets.fromLTRB(12, 0, 12, gap + 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: children,
          ),
        );
      },
    );
  }
}
