import 'dart:ui' show FontFeature;
import 'dart:io';

import 'package:flutter/material.dart';

import '../settings.dart';

class CoverImage extends StatelessWidget {
  final String? path;
  const CoverImage({super.key, this.path});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final placeholder = Container(
      color: cs.surfaceContainerHighest,
      alignment: Alignment.center,
      child: Icon(Icons.movie_outlined, size: 36, color: cs.outline),
    );
    final pth = path;
    if (pth == null) return placeholder;
    return Image.file(
      File(pth),
      fit: BoxFit.cover,
      cacheWidth: 480,
      gaplessPlayback: true,
      errorBuilder: (_, __, ___) => placeholder,
    );
  }
}

/// 图片右下角的半透明小标签（时长、时间点）
class TimeTag extends StatelessWidget {
  final String text;
  final bool small;
  const TimeTag(this.text, {super.key, this.small = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: small ? 4 : 6, vertical: 1.5),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: Colors.white,
          fontSize: small ? 10 : 12,
          fontWeight: FontWeight.w500,
          fontFeatures: const [FontFeature.tabularFigures()],
        ),
      ),
    );
  }
}

class AnimeCard extends StatelessWidget {
  final String title;
  final String? subtitle;
  final int epCount;
  final int picCount; // 没有视频、只有图片的番剧显示“N 张”
  final int totalMs; // 总时长，>0 时显示在封面右下角
  final List<String> tags;
  final String? coverPath;
  final SettingsStore settings;
  final bool compact;
  final bool selectionMode;
  final bool selected;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const AnimeCard({
    super.key,
    required this.title,
    required this.settings,
    this.subtitle,
    this.epCount = 0,
    this.picCount = 0,
    this.totalMs = 0,
    this.tags = const [],
    this.coverPath,
    this.compact = false,
    this.selectionMode = false,
    this.selected = false,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final s = settings;
    final theme = Theme.of(context);
    final radius = BorderRadius.circular(s.coverRadius);
    final titleSize = compact ? 12.0 : s.titleFont;
    final lines = compact ? 1 : s.titleLines;

    String? sub = subtitle;
    if (sub == null && s.showEpCount) {
      if (epCount > 0) {
        sub = '$epCount 集';
      } else if (picCount > 0) {
        sub = '$picCount 张';
      }
    }

    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      borderRadius: radius,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: radius,
            child: AspectRatio(
              aspectRatio: s.ratio,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  CoverImage(path: coverPath),
                  if (totalMs > 0)
                    Positioned(
                      right: 6,
                      bottom: 6,
                      child: TimeTag(fmtDuration(totalMs), small: compact),
                    ),
                  if (selectionMode)
                    Container(color: selected ? Colors.black45 : Colors.transparent),
                  if (selectionMode)
                    Positioned(
                      top: 6,
                      right: 6,
                      child: Icon(
                        selected ? Icons.check_circle : Icons.radio_button_unchecked,
                        color: selected ? theme.colorScheme.primary : Colors.white,
                        shadows: const [Shadow(blurRadius: 4, color: Colors.black54)],
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            title,
            maxLines: lines,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: titleSize, fontWeight: FontWeight.w600),
          ),
          if (sub != null)
            Text(
              sub,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall,
            ),
          if (!compact && s.showTags && tags.isNotEmpty)
            Text(
              tags.join(' · '),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.primary),
            ),
        ],
      ),
    );
  }
}

/// 毫秒 → 24:10 或 1:02:03
String fmtDuration(int ms) {
  final total = ms ~/ 1000;
  final h = total ~/ 3600;
  final m = (total % 3600) ~/ 60;
  final sec = total % 60;
  String two(int n) => n.toString().padLeft(2, '0');
  return h > 0 ? '$h:${two(m)}:${two(sec)}' : '${two(m)}:${two(sec)}';
}
