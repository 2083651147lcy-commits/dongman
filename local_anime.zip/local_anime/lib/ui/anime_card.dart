import 'dart:io';

import 'package:flutter/material.dart';

import '../settings.dart';

class CoverImage extends StatelessWidget {
  final String? path;
  const CoverImage({super.key, this.path});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final placeholder = Container(
      color: cs.surfaceContainerHighest,
      alignment: Alignment.center,
      child: Icon(Icons.movie_outlined, size: 36, color: cs.outline),
    );
    final pth = path;
    if (pth == null) return placeholder;
    return Image.file(
      File(pth),
      fit: BoxFit.cover,
      cacheWidth: 480,
      gaplessPlayback: true,
      errorBuilder: (_, __, ___) => placeholder,
    );
  }
}

class AnimeCard extends StatelessWidget {
  final String title;
  final String? subtitle;
  final int epCount;
  final int watched;
  final List<String> tags;
  final String? coverPath;
  final SettingsStore settings;
  final bool compact;
  final bool selectionMode;
  final bool selected;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const AnimeCard({
    super.key,
    required this.title,
    required this.settings,
    this.subtitle,
    this.epCount = 0,
    this.watched = 0,
    this.tags = const [],
    this.coverPath,
    this.compact = false,
    this.selectionMode = false,
    this.selected = false,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final s = settings;
    final theme = Theme.of(context);
    final radius = BorderRadius.circular(s.coverRadius);
    final titleSize = compact ? 12.0 : s.titleFont;
    final lines = compact ? 1 : s.titleLines;

    String? sub = subtitle;
    if (sub == null && s.showEpCount && epCount > 0) {
      sub = watched > 0 ? '$epCount 集 · 已看 $watched' : '$epCount 集';
    }

    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      borderRadius: radius,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: radius,
            child: AspectRatio(
              aspectRatio: s.ratio,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  CoverImage(path: coverPath),
                  if (selectionMode)
                    Container(color: selected ? Colors.black45 : Colors.transparent),
                  if (selectionMode)
                    Positioned(
                      top: 6,
                      right: 6,
                      child: Icon(
                        selected ? Icons.check_circle : Icons.radio_button_unchecked,
                        color: selected ? theme.colorScheme.primary : Colors.white,
                        shadows: const [Shadow(blurRadius: 4, color: Colors.black54)],
                      ),
                    ),
                  if (s.showProgress && epCount > 0 && !compact)
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: LinearProgressIndicator(
                        value: (watched / epCount).clamp(0.0, 1.0),
                        minHeight: 3,
                        backgroundColor: Colors.black26,
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            title,
            maxLines: lines,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: titleSize, fontWeight: FontWeight.w600),
          ),
          if (sub != null)
            Text(
              sub,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall,
            ),
          if (!compact && s.showTags && tags.isNotEmpty)
            Text(
              tags.take(3).join(' · '),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.primary),
            ),
        ],
      ),
    );
  }
}

/// 毫秒 → 24:10 或 1:02:03
String fmtDuration(int ms) {
  final total = ms ~/ 1000;
  final h = total ~/ 3600;
  final m = (total % 3600) ~/ 60;
  final sec = total % 60;
  String two(int n) => n.toString().padLeft(2, '0');
  return h > 0 ? '$h:${two(m)}:${two(sec)}' : '${two(m)}:${two(sec)}';
}
