import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// 滚轮选“几分几秒”，不拉起键盘。onChanged 给出总秒数。
class MinSecWheel extends StatefulWidget {
  final int initialSeconds;
  final ValueChanged<int> onChanged;
  final bool haptic; // 滚到一个新数字就震动一下（和导航栏同款）
  const MinSecWheel({
    super.key,
    required this.initialSeconds,
    required this.onChanged,
    this.haptic = false,
  });

  @override
  State<MinSecWheel> createState() => _MinSecWheelState();
}

class _MinSecWheelState extends State<MinSecWheel> {
  static const _maxMin = 60; // 分钟 0~60，循环滚动
  late int _min;
  late int _sec;
  late final FixedExtentScrollController _minCtl;
  late final FixedExtentScrollController _secCtl;

  @override
  void initState() {
    super.initState();
    final total = widget.initialSeconds < 0 ? 0 : widget.initialSeconds;
    _min = (total ~/ 60).clamp(0, _maxMin);
    _sec = total % 60;
    _minCtl = FixedExtentScrollController(initialItem: _min);
    _secCtl = FixedExtentScrollController(initialItem: _sec);
  }

  @override
  void dispose() {
    _minCtl.dispose();
    _secCtl.dispose();
    super.dispose();
  }

  static const _native = MethodChannel('local_anime/native');

  void _tick() {
    if (widget.haptic) _native.invokeMethod<void>('haptic').catchError((_) {});
  }

  void _emit() => widget.onChanged(_min * 60 + _sec);

  Widget _wheel(FixedExtentScrollController ctl, int count, String unit,
      ValueChanged<int> onSel) {
    final style = Theme.of(context).textTheme.titleLarge;
    return Expanded(
      child: CupertinoPicker(
        scrollController: ctl,
        itemExtent: 40,
        magnification: 1.1,
        useMagnifier: true,
        looping: true,
        // 循环滚动时给出的序号可能超出范围，取模还原
        onSelectedItemChanged: (i) => onSel(i % count),
        children: [
          for (var i = 0; i < count; i++)
            Center(child: Text('$i $unit', style: style)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _wheel(_minCtl, _maxMin + 1, '分', (i) {
          _min = i;
          _tick();
          _emit();
        }),
        _wheel(_secCtl, 60, '秒', (i) {
          _sec = i;
          _tick();
          _emit();
        }),
      ],
    );
  }
}

/// 秒数 → 简短文字：150 → 2分30秒，120 → 2分，30 → 30秒，0 → 0秒
String fmtMinSec(int totalSeconds) {
  final t = totalSeconds < 0 ? 0 : totalSeconds;
  final m = t ~/ 60, s = t % 60;
  if (m == 0) return '$s秒';
  if (s == 0) return '$m分';
  return '$m分$s秒';
}

/// 弹出“截取第几秒作封面”，返回总秒数；取消返回 null
Future<int?> showCoverSecondPicker(BuildContext context, int initialSeconds,
    {bool haptic = false}) {
  var cur = initialSeconds < 0 ? 0 : initialSeconds;
  return showDialog<int>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('截取第几秒作封面'),
      // 固定宽高：滚轮控件不支持 AlertDialog 的自适应尺寸计算
      content: SizedBox(
        width: 260,
        height: 160,
        child: MinSecWheel(
          initialSeconds: cur,
          haptic: haptic,
          onChanged: (v) => cur = v,
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, cur),
          child: const Text('截取'),
        ),
      ],
    ),
  );
}
