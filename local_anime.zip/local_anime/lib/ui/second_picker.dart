import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';

/// 滚轮选“几分几秒”，不拉起键盘。onChanged 给出总秒数。
class MinSecWheel extends StatefulWidget {
  final int initialSeconds;
  final ValueChanged<int> onChanged;
  final bool haptic; // 滚到一个新数字就震动一下（和导航栏同款）
  final int maxMinutes; // 分钟最大值（视频有多长就到多少分钟），秒固定 0~59
  const MinSecWheel({
    super.key,
    required this.initialSeconds,
    required this.onChanged,
    this.haptic = false,
    this.maxMinutes = 60,
  });

  @override
  State<MinSecWheel> createState() => _MinSecWheelState();
}

class _MinSecWheelState extends State<MinSecWheel> {
  int get _maxMin => widget.maxMinutes < 0 ? 0 : widget.maxMinutes;
  late int _min;
  late int _sec;
  late final FixedExtentScrollController _minCtl;
  late final FixedExtentScrollController _secCtl;

  @override
  void initState() {
    super.initState();
    final total = widget.initialSeconds < 0 ? 0 : widget.initialSeconds;
    _min = (total ~/ 60).clamp(0, _maxMin);
    _sec = total % 60;
    _minCtl = FixedExtentScrollController(initialItem: _min);
    _secCtl = FixedExtentScrollController(initialItem: _sec);
  }

  @override
  void dispose() {
    _minCtl.dispose();
    _secCtl.dispose();
    super.dispose();
  }

  static const _native = MethodChannel('local_anime/native');

  void _tick() {
    if (widget.haptic) _native.invokeMethod<void>('haptic').catchError((_) {});
  }

  void _emit() => widget.onChanged(_min * 60 + _sec);

  Widget _wheel(FixedExtentScrollController ctl, int count, String unit,
      ValueChanged<int> onSel) {
    final style = Theme.of(context).textTheme.titleLarge;
    return Expanded(
      child: CupertinoPicker(
        scrollController: ctl,
        itemExtent: 40,
        magnification: 1.1,
        useMagnifier: true,
        looping: true,
        // 循环滚动时给出的序号可能超出范围，取模还原
        onSelectedItemChanged: (i) => onSel(i % count),
        children: [
          for (var i = 0; i < count; i++)
            Center(child: Text('$i $unit', style: style)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _wheel(_minCtl, _maxMin + 1, '分', (i) {
          _min = i;
          _tick();
          _emit();
        }),
        _wheel(_secCtl, 60, '秒', (i) {
          _sec = i;
          _tick();
          _emit();
        }),
      ],
    );
  }
}

/// 秒数 → 简短文字：150 → 2分30秒，120 → 2分，30 → 30秒，0 → 0秒
String fmtMinSec(int totalSeconds) {
  final t = totalSeconds < 0 ? 0 : totalSeconds;
  final m = t ~/ 60, s = t % 60;
  if (m == 0) return '$s秒';
  if (s == 0) return '$m分';
  return '$m分$s秒';
}

/// 截取封面的选择结果
class CoverPick {
  final int seconds;
  final String? episodeRel; // 选的是哪一集（相对路径）；只有一集时为 null
  const CoverPick(this.seconds, this.episodeRel);
}

/// 弹出“截取第几秒作封面”：多于一集时可以先选哪一集；分钟的上限是所选视频的分钟数。
/// durations：每集已知时长（毫秒，key 是相对路径），没读到的按 60 分钟上限。
Future<CoverPick?> showCoverPicker(
  BuildContext context, {
  required Anime anime,
  required int initialSeconds,
  bool haptic = false,
}) {
  final eps = anime.episodes;
  var idx = 0;
  final cur = anime.coverEpisodeOrFirst;
  if (cur != null) idx = eps.indexOf(cur).clamp(0, eps.length - 1);
  var seconds = initialSeconds < 0 ? 0 : initialSeconds;

  int durMs(int i) => anime.durations[anime.relOf(eps[i])] ?? 0;

  return showDialog<CoverPick>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) {
        final ms = durMs(idx);
        final maxMin = ms > 0 ? ms ~/ 60000 : 60;
        return AlertDialog(
          title: const Text('截取第几秒作封面'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (eps.length > 1)
                DropdownButton<int>(
                  isExpanded: true,
                  value: idx,
                  items: [
                    for (var i = 0; i < eps.length; i++)
                      DropdownMenuItem(
                        value: i,
                        child: Text(
                          eps[i].group.isEmpty
                              ? eps[i].baseName
                              : '${eps[i].group} · ${eps[i].baseName}',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                  ],
                  onChanged: (v) => setLocal(() => idx = v ?? idx),
                ),
              // 固定宽高：滚轮控件不支持 AlertDialog 的自适应尺寸计算
              SizedBox(
                width: 260,
                height: 160,
                child: MinSecWheel(
                  // 换集后重建滚轮，分钟上限跟着变
                  key: ValueKey('${anime.relOf(eps[idx])}|$maxMin'),
                  initialSeconds: ms > 0 && seconds > ms ~/ 1000
                      ? ms ~/ 1000
                      : seconds,
                  maxMinutes: maxMin,
                  haptic: haptic,
                  onChanged: (v) => seconds = v,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
            FilledButton(
              onPressed: () {
                var sec = seconds;
                // 不超过视频长度
                if (ms > 0 && sec > ms ~/ 1000 - 1) sec = ms ~/ 1000 - 1;
                if (sec < 0) sec = 0;
                Navigator.pop(
                  ctx,
                  CoverPick(sec, eps.length > 1 && idx > 0 ? anime.relOf(eps[idx]) : null),
                );
              },
              child: const Text('截取'),
            ),
          ],
        );
      },
    ),
  );
}
