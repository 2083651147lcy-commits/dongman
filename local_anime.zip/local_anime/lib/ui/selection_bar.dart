import 'package:flutter/material.dart';

class SelectionAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool danger;
  const SelectionAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.danger = false,
  });
}

/// 多选时替代底部导航栏的操作栏
class SelectionBar extends StatelessWidget {
  final List<SelectionAction> actions;
  const SelectionBar({super.key, required this.actions});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      elevation: 3,
      color: cs.surfaceContainer,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: [
              for (final a in actions)
                Expanded(
                  child: InkWell(
                    onTap: a.onTap,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(a.icon, color: a.danger ? cs.error : null),
                        const SizedBox(height: 2),
                        Text(
                          a.label,
                          style: TextStyle(
                            fontSize: 12,
                            color: a.danger ? cs.error : null,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
