import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';

String fmtBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
  if (b < 1024 * 1024 * 1024) {
    return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  }
  return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

/// 确认并删除番剧（连视频和文件夹一起）。用户确认并执行后返回 true。
Future<bool> deleteAnimesFlow(
  BuildContext context,
  LibraryStore store,
  List<Anime> list,
) async {
  if (list.isEmpty) return false;
  final ok = await showDialog<bool>(
    context: context,
    builder: (_) => DeleteDialog(store: store, list: list),
  );
  if (ok != true) return false;
  final failed = await store.deleteAnimes(list);
  if (context.mounted) {
    final done = list.length - failed.length;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(failed.isEmpty
          ? '已删除 $done 部番剧'
          : '已删除 $done 部，${failed.length} 部失败：${failed.join('、')}'),
    ));
  }
  return true;
}

class DeleteDialog extends StatefulWidget {
  final LibraryStore store;
  final List<Anime> list;
  const DeleteDialog({super.key, required this.store, required this.list});

  @override
  State<DeleteDialog> createState() => _DeleteDialogState();
}

class _DeleteDialogState extends State<DeleteDialog> {
  late final Future<int> _size = widget.store.totalSize(widget.list);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final names = widget.list.map((a) => '· ${a.name}').toList();
    return AlertDialog(
      title: Text('删除 ${widget.list.length} 部番剧'),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 160),
              child: SingleChildScrollView(child: Text(names.join('\n'))),
            ),
            const SizedBox(height: 12),
            Text(
              '将永久删除这些番剧的所有视频文件和整个文件夹，无法恢复。',
              style: TextStyle(color: cs.error),
            ),
            const SizedBox(height: 8),
            FutureBuilder<int>(
              future: _size,
              builder: (_, snap) => Text(snap.hasData
                  ? '共释放约 ${fmtBytes(snap.data!)}'
                  : '正在计算大小…'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: cs.error),
          onPressed: () => Navigator.pop(context, true),
          child: const Text('删除'),
        ),
      ],
    );
  }
}
