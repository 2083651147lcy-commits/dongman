import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../episode_parser.dart';
import '../settings.dart';

const _imageExts = {'.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp'};

bool isImageFile(String path) =>
    _imageExts.contains(p.extension(path).toLowerCase());

/// 列出这些文件夹里（只看一层）的图片，忽略 . 开头的隐藏文件，按文件名自然排序
Future<List<File>> listStills(Iterable<String> dirs) async {
  final seen = <String>{};
  final out = <File>[];
  for (final d in dirs) {
    try {
      await for (final e in Directory(d).list(followLinks: false)) {
        if (e is! File) continue;
        final name = p.basename(e.path);
        if (name.startsWith('.')) continue;
        if (!isImageFile(name)) continue;
        if (seen.add(e.path)) out.add(e);
      }
    } catch (_) {}
  }
  out.sort((a, b) => naturalCompare(p.basename(a.path), p.basename(b.path)));
  return out;
}

/// 带圆角的图块：按下时盖一层黑色半透明效果，长按时有系统长按的震动（InkWell 自带）。
/// 效果画在图片上面，所以用 Stack 把 InkWell 叠在 child 之上。
class PressableTile extends StatelessWidget {
  final Widget child;
  final double radius;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  const PressableTile({
    super.key,
    required this.child,
    required this.radius,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Stack(
        children: [
          child,
          Positioned.fill(
            child: Material(
              type: MaterialType.transparency,
              child: InkWell(
                onTap: onTap,
                onLongPress: onLongPress,
                highlightColor: Colors.black38,
                splashColor: Colors.black26,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 详情页“剧照”板块：没有图片时什么都不显示。
/// 卡片的宽度、比例、圆角和主页的番剧卡片一致（读同一份设置）。
/// 长按卡片：设为封面 / 删除 / 取消。
class StillsSection extends StatefulWidget {
  final List<String> dirs;
  final SettingsStore settings;
  final int revision; // 变了就重新列出图片（编辑后刷新用）
  final Future<void> Function(File file) onSetCover;
  final Future<void> Function(File file, int total) onDelete;
  const StillsSection({
    super.key,
    required this.dirs,
    required this.settings,
    required this.onSetCover,
    required this.onDelete,
    this.revision = 0,
  });

  @override
  State<StillsSection> createState() => _StillsSectionState();
}

class _StillsSectionState extends State<StillsSection> {
  List<File> _files = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(StillsSection old) {
    super.didUpdateWidget(old);
    if (old.dirs.join('|') != widget.dirs.join('|') ||
        old.revision != widget.revision) {
      _load();
    }
  }

  Future<void> _load() async {
    final list = await listStills(widget.dirs);
    if (!mounted) return;
    setState(() => _files = list);
  }

  Future<void> _menu(File f) async {
    final act = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.image_outlined),
              title: const Text('设为封面'),
              onTap: () => Navigator.pop(ctx, 'cover'),
            ),
            ListTile(
              leading: Icon(Icons.delete_outline,
                  color: Theme.of(ctx).colorScheme.error),
              title: Text('删除',
                  style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
            ListTile(
              leading: const Icon(Icons.close),
              title: const Text('取消'),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
    if (!mounted || act == null) return;
    if (act == 'cover') {
      await widget.onSetCover(f);
    } else if (act == 'delete') {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('永久删除这张图片？'),
          content: Text('“${p.basename(f.path)}”会从手机上永久删除，无法恢复。'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('删除')),
          ],
        ),
      );
      if (ok == true) await widget.onDelete(f, _files.length);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_files.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final s = widget.settings;
    // 和主页卡片同样的宽度：屏幕宽度减去两侧 12，按列数和间距平分
    final mq = MediaQuery.of(context);
    final landscape = mq.orientation == Orientation.landscape;
    final cols = landscape ? s.landscapeCols : s.portraitCols;
    final cardW = ((mq.size.width - 24 - s.gap * (cols - 1)) / cols)
        .clamp(60.0, 600.0);
    final cardH = cardW / s.ratio;
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('剧照', style: theme.textTheme.titleMedium),
              const Spacer(),
              Text('共 ${_files.length} 张', style: theme.textTheme.bodyMedium),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: cardH,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _files.length,
              separatorBuilder: (_, __) => SizedBox(width: s.gap),
              itemBuilder: (ctx, i) => PressableTile(
                radius: s.coverRadius,
                onTap: () => openStillViewer(ctx, _files, i),
                onLongPress: () => _menu(_files[i]),
                child: SizedBox(
                  width: cardW,
                  height: cardH,
                  child: Image.file(
                    _files[i],
                    fit: BoxFit.cover,
                    cacheWidth: 400, // 缩略图只解码小尺寸，省内存
                    errorBuilder: (_, __, ___) => Container(
                      color: theme.colorScheme.surfaceContainerHighest,
                      alignment: Alignment.center,
                      child: const Icon(Icons.broken_image_outlined),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 全屏查看原图：背景变暗；双指缩放、双击缩放（有过渡动画）；
/// 点屏幕任意位置或按返回键关闭
Future<void> openStillViewer(BuildContext context, List<File> files, int index) {
  return Navigator.of(context).push(PageRouteBuilder<void>(
    opaque: false,
    barrierColor: Colors.black87,
    transitionDuration: const Duration(milliseconds: 160),
    reverseTransitionDuration: const Duration(milliseconds: 120),
    pageBuilder: (_, __, ___) => _StillViewer(files: files, initial: index),
    transitionsBuilder: (_, anim, __, child) =>
        FadeTransition(opacity: anim, child: child),
  ));
}

class _StillViewer extends StatefulWidget {
  final List<File> files;
  final int initial;
  const _StillViewer({required this.files, required this.initial});

  @override
  State<_StillViewer> createState() => _StillViewerState();
}

class _StillViewerState extends State<_StillViewer> {
  late final PageController _pc = PageController(initialPage: widget.initial);
  late int _index = widget.initial;
  bool _zoomed = false;
  int _pointers = 0; // 当前按在屏幕上的手指数
  bool _multi = false; // 两根及以上手指：是在缩放，不能当成翻页

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _setZoomed(bool z) {
    if (z != _zoomed) setState(() => _zoomed = z);
  }

  void _down() {
    _pointers++;
    if (_pointers >= 2 && !_multi) setState(() => _multi = true);
  }

  void _up() {
    if (_pointers > 0) _pointers--;
    if (_pointers < 2 && _multi) setState(() => _multi = false);
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Stack(
        children: [
          Listener(
            onPointerDown: (_) => _down(),
            onPointerUp: (_) => _up(),
            onPointerCancel: (_) => _up(),
            child: PageView.builder(
              controller: _pc,
              // 放大状态、或两指在屏幕上时禁止翻页，避免缩放被当成翻页
              physics: (_zoomed || _multi)
                  ? const NeverScrollableScrollPhysics()
                  : null,
              itemCount: widget.files.length,
              onPageChanged: (i) => setState(() => _index = i),
              itemBuilder: (_, i) => _ZoomPage(
                key: ValueKey(widget.files[i].path),
                file: widget.files[i],
                onZoom: _setZoomed,
                onClose: () => Navigator.of(context).maybePop(),
              ),
            ),
          ),
          if (widget.files.length > 1)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: IgnorePointer(
                    child: Text(
                      '${_index + 1} / ${widget.files.length}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ZoomPage extends StatefulWidget {
  final File file;
  final ValueChanged<bool> onZoom;
  final VoidCallback onClose;
  const _ZoomPage({
    super.key,
    required this.file,
    required this.onZoom,
    required this.onClose,
  });

  @override
  State<_ZoomPage> createState() => _ZoomPageState();
}

class _ZoomPageState extends State<_ZoomPage>
    with SingleTickerProviderStateMixin {
  static const _zoomScale = 2.5;
  final _ctl = TransformationController();
  late final AnimationController _ac = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 200));
  Animation<Matrix4>? _anim;
  Offset _lastDown = Offset.zero;

  @override
  void initState() {
    super.initState();
    _ctl.addListener(() => widget.onZoom(_ctl.value.getMaxScaleOnAxis() > 1.01));
    _ac.addListener(() {
      final v = _anim?.value;
      if (v != null) _ctl.value = v;
    });
  }

  @override
  void dispose() {
    _ac.dispose();
    _ctl.dispose();
    super.dispose();
  }

  /// 双击：带一小段过渡动画地放大/还原
  void _toggleZoom() {
    final Matrix4 target;
    if (_ctl.value.getMaxScaleOnAxis() > 1.01) {
      target = Matrix4.identity();
    } else {
      final pt = _lastDown;
      const s = _zoomScale;
      // 以双击的位置为中心放大：点 pt 放大后仍在原处
      target = Matrix4(
        s, 0, 0, 0, //
        0, s, 0, 0, //
        0, 0, 1, 0, //
        -pt.dx * (s - 1), -pt.dy * (s - 1), 0, 1,
      );
    }
    _anim = Matrix4Tween(begin: _ctl.value, end: target)
        .animate(CurvedAnimation(parent: _ac, curve: Curves.easeOut));
    _ac.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      // 点屏幕任意位置关闭（因为要区分双击，会有约 0.3 秒的等待）
      onTap: widget.onClose,
      onDoubleTapDown: (d) => _lastDown = d.localPosition,
      onDoubleTap: _toggleZoom,
      child: InteractiveViewer(
        transformationController: _ctl,
        minScale: 1,
        maxScale: 5,
        onInteractionStart: (_) => _ac.stop(), // 手指一动就中断动画
        child: SizedBox.expand(
          child: Image.file(
            widget.file,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => const Center(
              child: Icon(Icons.broken_image_outlined,
                  color: Colors.white54, size: 48),
            ),
          ),
        ),
      ),
    );
  }
}
