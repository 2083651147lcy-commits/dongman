import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../episode_parser.dart';
import '../settings.dart';

const _imageExts = {'.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp'};

/// 列出这些文件夹里（只看一层）的图片，忽略 . 开头的隐藏文件，按文件名自然排序
Future<List<File>> listStills(Iterable<String> dirs) async {
  final seen = <String>{};
  final out = <File>[];
  for (final d in dirs) {
    try {
      await for (final e in Directory(d).list(followLinks: false)) {
        if (e is! File) continue;
        final name = p.basename(e.path);
        if (name.startsWith('.')) continue;
        if (!_imageExts.contains(p.extension(name).toLowerCase())) continue;
        if (seen.add(e.path)) out.add(e);
      }
    } catch (_) {}
  }
  out.sort((a, b) => naturalCompare(p.basename(a.path), p.basename(b.path)));
  return out;
}

/// 详情页“剧照”板块：没有图片时什么都不显示
class StillsSection extends StatefulWidget {
  final List<String> dirs;
  final SettingsStore settings;
  const StillsSection({super.key, required this.dirs, required this.settings});

  @override
  State<StillsSection> createState() => _StillsSectionState();
}

class _StillsSectionState extends State<StillsSection> {
  List<File> _files = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(StillsSection old) {
    super.didUpdateWidget(old);
    if (old.dirs.join('|') != widget.dirs.join('|')) _load();
  }

  Future<void> _load() async {
    final list = await listStills(widget.dirs);
    if (!mounted) return;
    setState(() => _files = list);
  }

  @override
  Widget build(BuildContext context) {
    if (_files.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('剧照', style: theme.textTheme.titleMedium),
              const Spacer(),
              Text('共 ${_files.length} 张', style: theme.textTheme.bodyMedium),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 110,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _files.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (ctx, i) => GestureDetector(
                onTap: () => openStillViewer(ctx, _files, i),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(widget.settings.coverRadius),
                  child: SizedBox(
                    width: 195,
                    height: 110,
                    child: Image.file(
                      _files[i],
                      fit: BoxFit.cover,
                      cacheWidth: 400, // 缩略图只解码小尺寸，省内存
                      errorBuilder: (_, __, ___) => Container(
                        color: theme.colorScheme.surfaceContainerHighest,
                        alignment: Alignment.center,
                        child: const Icon(Icons.broken_image_outlined),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 全屏查看原图：背景变暗；双指缩放、双击缩放；点暗处或返回键关闭
Future<void> openStillViewer(BuildContext context, List<File> files, int index) {
  return Navigator.of(context).push(PageRouteBuilder<void>(
    opaque: false,
    barrierColor: Colors.black87,
    transitionDuration: const Duration(milliseconds: 160),
    reverseTransitionDuration: const Duration(milliseconds: 120),
    pageBuilder: (_, __, ___) => _StillViewer(files: files, initial: index),
    transitionsBuilder: (_, anim, __, child) =>
        FadeTransition(opacity: anim, child: child),
  ));
}

class _StillViewer extends StatefulWidget {
  final List<File> files;
  final int initial;
  const _StillViewer({required this.files, required this.initial});

  @override
  State<_StillViewer> createState() => _StillViewerState();
}

class _StillViewerState extends State<_StillViewer> {
  late final PageController _pc = PageController(initialPage: widget.initial);
  late int _index = widget.initial;
  bool _zoomed = false;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  void _setZoomed(bool z) {
    if (z != _zoomed) setState(() => _zoomed = z);
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Stack(
        children: [
          PageView.builder(
            controller: _pc,
            // 放大状态下禁止翻页，避免和拖动图片冲突
            physics: _zoomed ? const NeverScrollableScrollPhysics() : null,
            itemCount: widget.files.length,
            onPageChanged: (i) => setState(() => _index = i),
            itemBuilder: (_, i) => _ZoomPage(
              key: ValueKey(widget.files[i].path),
              file: widget.files[i],
              onZoom: _setZoomed,
              onClose: () => Navigator.of(context).maybePop(),
            ),
          ),
          if (widget.files.length > 1)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: IgnorePointer(
                    child: Text(
                      '${_index + 1} / ${widget.files.length}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ZoomPage extends StatefulWidget {
  final File file;
  final ValueChanged<bool> onZoom;
  final VoidCallback onClose;
  const _ZoomPage({
    super.key,
    required this.file,
    required this.onZoom,
    required this.onClose,
  });

  @override
  State<_ZoomPage> createState() => _ZoomPageState();
}

class _ZoomPageState extends State<_ZoomPage> {
  static const _zoomScale = 2.5;
  final _ctl = TransformationController();
  Size? _imgSize;
  Offset _lastDown = Offset.zero;
  ImageStream? _stream;
  ImageStreamListener? _listener;

  @override
  void initState() {
    super.initState();
    _ctl.addListener(() => widget.onZoom(_ctl.value.getMaxScaleOnAxis() > 1.01));
    // 读出图片原始尺寸，用来判断点的是图片还是周围的暗处
    final stream = FileImage(widget.file).resolve(ImageConfiguration.empty);
    final l = ImageStreamListener((info, _) {
      if (!mounted) return;
      setState(() => _imgSize =
          Size(info.image.width.toDouble(), info.image.height.toDouble()));
    }, onError: (_, __) {});
    stream.addListener(l);
    _stream = stream;
    _listener = l;
  }

  @override
  void dispose() {
    if (_stream != null && _listener != null) _stream!.removeListener(_listener!);
    _ctl.dispose();
    super.dispose();
  }

  /// 点击位置（屏幕坐标）是否落在图片上
  bool _hitsImage(Offset viewportPoint, Size viewport) {
    final img = _imgSize;
    if (img == null) return true; // 还没读到尺寸，不当作点暗处
    final fitted = applyBoxFit(BoxFit.contain, img, viewport).destination;
    final rect = Alignment.center.inscribe(fitted, Offset.zero & viewport);
    return rect.contains(_ctl.toScene(viewportPoint));
  }

  void _toggleZoom() {
    if (_ctl.value.getMaxScaleOnAxis() > 1.01) {
      _ctl.value = Matrix4.identity();
    } else {
      final pt = _lastDown;
      const s = _zoomScale;
      // 以双击的位置为中心放大：点 p 放大后仍在原处
      _ctl.value = Matrix4(
        s, 0, 0, 0, //
        0, s, 0, 0, //
        0, 0, 1, 0, //
        -pt.dx * (s - 1), -pt.dy * (s - 1), 0, 1,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final viewport = Size(c.maxWidth, c.maxHeight);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          if (!_hitsImage(d.localPosition, viewport)) widget.onClose();
        },
        onDoubleTapDown: (d) => _lastDown = d.localPosition,
        onDoubleTap: _toggleZoom,
        child: InteractiveViewer(
          transformationController: _ctl,
          minScale: 1,
          maxScale: 5,
          child: SizedBox.expand(
            child: Image.file(
              widget.file,
              fit: BoxFit.contain,
              errorBuilder: (_, __, ___) => const Center(
                child: Icon(Icons.broken_image_outlined,
                    color: Colors.white54, size: 48),
              ),
            ),
          ),
        ),
      );
    });
  }
}
