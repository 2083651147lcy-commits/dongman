import 'dart:io';

import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';
import '../settings.dart';
import 'anime_card.dart' show TimeTag, fmtDuration;
import 'stills.dart';

/// 详情页“截图”板块：从视频里自动截取的画面（不是文件夹里自带的剧照）。
/// 只存在应用缓存里；设置里“自动截图”开着时进详情页自动生成，也可手动生成。
class ShotsSection extends StatefulWidget {
  final LibraryStore store;
  final Anime anime;
  final SettingsStore settings;
  const ShotsSection({
    super.key,
    required this.store,
    required this.anime,
    required this.settings,
  });

  @override
  State<ShotsSection> createState() => _ShotsSectionState();
}

class _ShotsSectionState extends State<ShotsSection> {
  int _ep = 0;
  List<AutoShot> _shots = const [];
  bool _busy = false;
  String _msg = '';
  bool _portrait = false; // 截图是竖屏（以第一张为准）

  Anime get _a => widget.anime;

  Episode? get _episode {
    if (_a.episodes.isEmpty) return null;
    return _a.episodes[_ep.clamp(0, _a.episodes.length - 1)];
  }

  @override
  void initState() {
    super.initState();
    _load(auto: true);
  }

  @override
  void didUpdateWidget(ShotsSection old) {
    super.didUpdateWidget(old);
    if (old.anime.path != widget.anime.path) {
      _ep = 0;
      _load(auto: true);
    }
  }

  Future<void> _load({bool auto = false}) async {
    final e = _episode;
    if (e == null) return;
    final list = await widget.store.listShots(e);
    var portrait = false;
    if (list.isNotEmpty) {
      try {
        final img = await decodeImageFromList(await list.first.file.readAsBytes());
        portrait = img.height > img.width;
        img.dispose();
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _shots = list;
      _portrait = portrait;
    });
    if (auto && list.isEmpty && widget.settings.autoShot) {
      _generate(auto: true);
    }
  }

  Future<void> _generate({bool auto = false}) async {
    final e = _episode;
    if (e == null || _busy) return;
    final n = widget.settings.autoShotCount;
    setState(() {
      _busy = true;
      _msg = '正在截取 0/$n';
    });
    final err = await widget.store.generateShots(_a, e, n, onProgress: (d, t) {
      if (mounted) setState(() => _msg = '正在截取 $d/$t');
    });
    if (!mounted) return;
    setState(() => _busy = false);
    if (err != null && !auto) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
    await _load();
  }

  Future<void> _deleteAll() async {
    if (_busy || _shots.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除全部截图？'),
        content: const Text('只删除这一集的截图（缓存文件），不影响视频；之后可以重新生成。'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('删除')),
        ],
      ),
    );
    if (ok != true) return;
    for (final x in _shots) {
      try {
        await x.file.delete();
      } catch (_) {}
    }
    await _load();
  }

  Future<void> _menu(AutoShot s) async {
    final act = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.image_outlined),
              title: Text('设为封面（${fmtDuration(s.ms)}）'),
              onTap: () => Navigator.pop(ctx, 'cover'),
            ),
            ListTile(
              leading: Icon(Icons.delete_outline,
                  color: Theme.of(ctx).colorScheme.error),
              title: Text('删除',
                  style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
            ListTile(
              leading: const Icon(Icons.close),
              title: const Text('取消'),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
    if (!mounted || act == null) return;
    if (act == 'delete') {
      try {
        await s.file.delete();
      } catch (_) {}
      await _load();
      return;
    }
    if (act != 'cover') return;
    final e = _episode;
    if (e == null) return;
    // 等于把封面设成“这一集的这个时间点”（第一集记为 null，和封面截取一致）
    await widget.store.setCoverSecond(
      _a,
      (s.ms ~/ 1000) < 1 ? 1 : s.ms ~/ 1000,
      episodeRel: _ep > 0 ? _a.relOf(e) : null,
    );
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('已设为封面')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_a.episodes.isEmpty) return const SizedBox.shrink();
    final theme = Theme.of(context);
    final s = widget.settings;
    final eps = _a.episodes;
    double h = 120.0;
    double w = h * 16 / 9;
    if (_portrait) {
      // 竖屏视频：和剧照同样大小（和主页卡片一致）
      final mq = MediaQuery.of(context);
      final cols = mq.orientation == Orientation.landscape
          ? s.landscapeCols
          : s.portraitCols;
      w = ((mq.size.width - 24 - s.gap * (cols - 1)) / cols).clamp(60.0, 600.0);
      h = w / s.ratio;
    }

    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('截图', style: theme.textTheme.titleMedium),
              const Spacer(),
              if (_shots.isNotEmpty)
                Text('共 ${_shots.length} 张', style: theme.textTheme.bodyMedium),
              TextButton(
                onPressed: _busy ? null : _generate,
                // 长按“重新生成”：删除这一集的全部截图
                onLongPress: (_busy || _shots.isEmpty) ? null : _deleteAll,
                child: Text(_shots.isEmpty ? '生成截图' : '重新生成'),
              ),
            ],
          ),
          if (eps.length > 1)
            DropdownButton<int>(
              isExpanded: true,
              value: _ep.clamp(0, eps.length - 1),
              items: [
                for (var i = 0; i < eps.length; i++)
                  DropdownMenuItem(
                    value: i,
                    child: Text(
                      eps[i].group.isEmpty
                          ? eps[i].baseName
                          : '${eps[i].group} · ${eps[i].baseName}',
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
              ],
              onChanged: _busy
                  ? null
                  : (v) {
                      setState(() {
                        _ep = v ?? _ep;
                        _shots = const [];
                      });
                      _load(auto: true);
                    },
            ),
          const SizedBox(height: 6),
          if (_busy)
            Row(
              children: [
                const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2.5)),
                const SizedBox(width: 10),
                Text(_msg),
              ],
            )
          else if (_shots.isEmpty)
            const SizedBox.shrink()
          else
            SizedBox(
              height: h,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: _shots.length,
                separatorBuilder: (_, __) => SizedBox(width: s.gap),
                itemBuilder: (ctx, i) => PressableTile(
                  radius: s.coverRadius,
                  onTap: () => openStillViewer(
                      ctx, [for (final x in _shots) x.file], i),
                  onLongPress: () => _menu(_shots[i]),
                  child: SizedBox(
                    width: w,
                    height: h,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Image.file(
                          _shots[i].file,
                          fit: BoxFit.cover,
                          cacheWidth: 480,
                          errorBuilder: (_, __, ___) => Container(
                            color: theme.colorScheme.surfaceContainerHighest,
                            alignment: Alignment.center,
                            child: const Icon(Icons.broken_image_outlined),
                          ),
                        ),
                        Positioned(
                          right: 6,
                          bottom: 6,
                          child: TimeTag(fmtDuration(_shots[i].ms), faint: true),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
