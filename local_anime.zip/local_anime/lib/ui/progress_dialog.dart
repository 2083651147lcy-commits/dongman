import 'package:flutter/material.dart';

/// 弹出一个不能手动关闭的“处理中”对话框，任务结束后自动关掉并返回任务结果。
/// task 里可以调用 report('正在移动 2/5…') 更新对话框上的文字。
Future<T> runWithProgress<T>(
  BuildContext context,
  String title,
  Future<T> Function(void Function(String) report) task,
) async {
  final msg = ValueNotifier<String>('');
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text(title),
        content: ValueListenableBuilder<String>(
          valueListenable: msg,
          builder: (_, v, __) => Row(
            children: [
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 3),
              ),
              const SizedBox(width: 16),
              Expanded(child: Text(v.isEmpty ? '请稍候…' : v)),
            ],
          ),
        ),
      ),
    ),
  );
  try {
    return await task((s) => msg.value = s);
  } finally {
    if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  }
}
