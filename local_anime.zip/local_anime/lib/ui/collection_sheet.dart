import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';

/// 新建收藏夹的小对话框，创建成功返回新的收藏夹
Future<Collection?> showCreateCollectionDialog(
  BuildContext context,
  LibraryStore store,
) async {
  final name = TextEditingController();
  final syn = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('新建收藏夹'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: name,
            autofocus: true,
            decoration: const InputDecoration(
              labelText: '名称 *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: syn,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: '简介（可不填）',
              alignLabelWithHint: true,
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消')),
        FilledButton(
          onPressed: () {
            if (name.text.trim().isEmpty) return;
            Navigator.pop(ctx, true);
          },
          child: const Text('创建'),
        ),
      ],
    ),
  );
  final n = name.text.trim();
  final s = syn.text.trim();
  if (ok != true || n.isEmpty) return null;
  return store.createCollection(n, s);
}

/// 从下往上弹出“选择收藏夹”面板。有改动并确认返回 true。
Future<bool?> showCollectionSheet(
  BuildContext context,
  LibraryStore store,
  List<Anime> animes,
) {
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _CollectionSheet(store: store, animes: animes),
  );
}

class _CollectionSheet extends StatefulWidget {
  final LibraryStore store;
  final List<Anime> animes;
  const _CollectionSheet({required this.store, required this.animes});

  @override
  State<_CollectionSheet> createState() => _CollectionSheetState();
}

class _CollectionSheetState extends State<_CollectionSheet> {
  // true = 选中的番剧都在里面；null = 只有部分在里面；false = 都不在
  final Map<String, bool?> _initial = {};
  final Map<String, bool?> _state = {};

  @override
  void initState() {
    super.initState();
    for (final c in widget.store.collections) {
      final v = _calc(c);
      _initial[c.id] = v;
      _state[c.id] = v;
    }
  }

  bool? _calc(Collection c) {
    final n = widget.animes.where((a) => c.contains(a.uid)).length;
    if (n == 0) return false;
    if (n == widget.animes.length) return true;
    return null;
  }

  void _toggle(Collection c) {
    setState(() => _state[c.id] = _state[c.id] == true ? false : true);
  }

  Future<void> _create() async {
    final c = await showCreateCollectionDialog(context, widget.store);
    if (c != null && mounted) {
      setState(() {
        _initial[c.id] = false;
        _state[c.id] = true; // 刚建的，默认把选中的番剧放进去
      });
    }
  }

  Future<void> _done() async {
    final changes = <String, bool>{};
    _state.forEach((id, v) {
      if (v != null && v != _initial[id]) changes[id] = v;
    });
    if (changes.isNotEmpty) {
      await widget.store.applyMembership(widget.animes, changes);
    }
    if (mounted) Navigator.pop(context, changes.isNotEmpty);
  }

  Widget _circle(bool? v, ColorScheme cs) {
    if (v == false) {
      return Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: cs.outline, width: 1.5),
        ),
      );
    }
    return CircleAvatar(
      radius: 13,
      backgroundColor: cs.primary,
      child: Icon(v == true ? Icons.check : Icons.remove,
          size: 18, color: cs.onPrimary),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cols = widget.store.collections;
    final cs = Theme.of(context).colorScheme;
    final theme = Theme.of(context);
    final maxH = MediaQuery.of(context).size.height * 0.7;

    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: maxH),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 12, 8),
              child: Row(
                children: [
                  Text('选择收藏夹',
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.bold)),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: _create,
                    icon: const Icon(Icons.add),
                    label: const Text('新建收藏夹'),
                  ),
                ],
              ),
            ),
            Flexible(
              child: cols.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(child: Text('还没有收藏夹，点右上角“新建收藏夹”')),
                    )
                  : ListView.separated(
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: cols.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final c = cols[i];
                        return InkWell(
                          onTap: () => _toggle(c),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        c.name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600),
                                      ),
                                      const SizedBox(height: 4),
                                      Text('${widget.store.countOf(c)}个内容',
                                          style: theme.textTheme.bodySmall),
                                    ],
                                  ),
                                ),
                                _circle(
                                    _state.containsKey(c.id) ? _state[c.id] : false,
                                    cs),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: _done, child: const Text('完成')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
