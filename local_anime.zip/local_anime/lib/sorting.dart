import 'dart:math';

import 'episode_parser.dart';
import 'models.dart';

/// 排序方式编号：0 名称 1 最近观看 2 总时长 3 随机 4 添加时间
const sortNames = ['按名称', '按最近观看', '按总时长', '随机排序', '按添加时间'];

/// 菜单里的显示顺序
const sortMenuOrder = [0, 4, 1, 2, 3];

/// 菜单项文字；当前选中的方式会带上方向
String sortLabel(int m, int current, bool rev) {
  if (m != current) return sortNames[m];
  switch (m) {
    case 0:
      return '按名称（${rev ? 'Z→A' : 'A→Z'}）';
    case 1:
      return '按最近观看（${rev ? '远→近' : '近→远'}）';
    case 2:
      return '按总时长（${rev ? '短→长' : '长→短'}）';
    case 4:
      return '按添加时间（${rev ? '旧→新' : '新→旧'}）';
    default:
      return '随机排序';
  }
}

/// 数值越大越靠前（反向则越小越靠前）。
/// unknownLast：还没读到数据（0）的永远排最后，只用于总时长。
int _byMetric(Anime a, Anime b, int x, int y, bool rev,
    {bool unknownLast = false}) {
  if (unknownLast) {
    final ux = x <= 0, uy = y <= 0;
    if (ux != uy) return ux ? 1 : -1;
  }
  if (x != y) return rev ? x.compareTo(y) : y.compareTo(x);
  return naturalCompare(a.name, b.name);
}

/// 按 mode 原地排序 list（随机 3 不在这里处理，用 RandomPicker）
void sortAnimes(List<Anime> list, int mode, bool rev) {
  switch (mode) {
    case 1:
      list.sort((a, b) => _byMetric(a, b, a.lastOpenedAt, b.lastOpenedAt, rev));
      break;
    case 2:
      list.sort((a, b) =>
          _byMetric(a, b, a.totalMs, b.totalMs, rev, unknownLast: true));
      break;
    case 4:
      list.sort((a, b) => _byMetric(a, b, a.addedAt, b.addedAt, rev));
      break;
    case 3:
      break;
    default:
      list.sort((a, b) {
        final c = naturalCompare(a.name, b.name);
        return rev ? -c : c;
      });
  }
}

/// 随机展示：洗牌轮播。一轮内每部番剧只出现一次，抽完才重新洗牌，
/// 新一轮里刚展示过的排在最后，所以相邻两批基本不重复。
class RandomPicker {
  static const count = 6;
  final _rng = Random();
  List<String> _batch = [];
  final List<String> _queue = []; // 这一轮还没展示过的
  String _sig = '';

  /// 置 true 表示下次取用时换一批
  bool dirty = true;

  /// pool：当前筛选后的结果；sig：筛选条件的标记，变了就换一批
  List<Anime> pick(List<Anime> pool, String sig) {
    final byPath = {for (final a in pool) a.path: a};
    if (dirty ||
        sig != _sig ||
        (_batch.isEmpty && byPath.isNotEmpty) ||
        _batch.any((p) => !byPath.containsKey(p))) {
      dirty = false;
      _sig = sig;
      _draw(byPath.keys.toSet());
    }
    return [for (final p in _batch) byPath[p]!];
  }

  void _draw(Set<String> valid) {
    _queue.removeWhere((p) => !valid.contains(p));
    final want = min(count, valid.length);
    final batch = <String>[];
    while (batch.length < want) {
      if (_queue.isEmpty) {
        final fresh = valid.where((p) => !batch.contains(p)).toList()
          ..shuffle(_rng);
        final seen = fresh.where(_batch.contains).toList();
        fresh.removeWhere(_batch.contains);
        _queue.addAll([...fresh, ...seen]);
      }
      batch.add(_queue.removeAt(0));
    }
    _batch = batch;
  }
}
