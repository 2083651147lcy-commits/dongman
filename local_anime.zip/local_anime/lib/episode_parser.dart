import 'package:path/path.dart' as p;

final RegExp _reSxxEyy = RegExp(r'[Ss]\d{1,2}[Ee](\d{1,3})');
final RegExp _reDi = RegExp(r'第\s*(\d{1,3})\s*[话話集回]');
final RegExp _reEp = RegExp(r'(?:^|[^A-Za-z])[Ee][Pp]?\.?\s*(\d{1,3})(?!\d)');
// 没有“第N集 / EP N / SxxEyy”这类明确标记时，只认被空格或括号单独隔开的数字，
// 比如 “某番 - 03 [1080p]”、“[03]”。连字符、下划线连着的数字（时间戳、编号）不算。
final RegExp _reLoose =
    RegExp(r'(?:^|[\s\[\(【])(\d{1,3})(?:v\d)?(?=$|[\s\]\)】])');

// 像 2026-03-12、20260312 这样的日期：文件名里有日期就不猜集数（录屏、相机文件常见）
final RegExp _reDateLike =
    RegExp(r'(?:19|20)\d{2}[-_.年]?\d{1,2}[-_.月]?\d{1,2}');

/// 从文件名里识别集数，识别不了返回 null。
int? parseEpisodeNumber(String fileName) {
  final name = p.basenameWithoutExtension(fileName);
  for (final re in [_reSxxEyy, _reDi, _reEp]) {
    final m = re.firstMatch(name);
    if (m != null) return int.tryParse(m.group(1)!);
  }
  if (_reDateLike.hasMatch(name)) return null;
  final all = _reLoose.allMatches(name).toList();
  if (all.isNotEmpty) return int.tryParse(all.last.group(1)!);
  return null;
}

/// 自然排序：第2集排在第10集前面。
int naturalCompare(String a, String b) {
  final re = RegExp(r'\d+|\D+');
  final ma = re.allMatches(a.toLowerCase()).map((m) => m.group(0)!).toList();
  final mb = re.allMatches(b.toLowerCase()).map((m) => m.group(0)!).toList();
  for (var i = 0; i < ma.length && i < mb.length; i++) {
    final x = ma[i], y = mb[i];
    final nx = int.tryParse(x), ny = int.tryParse(y);
    final c = (nx != null && ny != null) ? nx.compareTo(ny) : x.compareTo(y);
    if (c != 0) return c;
  }
  return ma.length.compareTo(mb.length);
}
