import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'models.dart';

/// 本地番剧库：数据保存为 JSON，视频/封面复制到应用私有目录。
class LibraryStore extends ChangeNotifier {
  final List<Anime> items = [];
  late Directory _root;

  List<String> get allTags {
    final set = <String>{};
    for (final a in items) {
      set.addAll(a.tags);
    }
    final list = set.toList()..sort();
    return list;
  }

  Anime? byId(String id) {
    for (final a in items) {
      if (a.id == id) return a;
    }
    return null;
  }

  Future<void> load() async {
    final docs = await getApplicationDocumentsDirectory();
    _root = Directory(p.join(docs.path, 'library'));
    await _root.create(recursive: true);
    final f = File(p.join(_root.path, 'library.json'));
    if (await f.exists()) {
      try {
        final list = jsonDecode(await f.readAsString()) as List;
        items
          ..clear()
          ..addAll(list.map((e) => Anime.fromJson(e as Map<String, dynamic>)));
      } catch (_) {
        // 数据损坏时保留备份，避免被覆盖
        try {
          await f.copy(p.join(_root.path, 'library.json.bak'));
        } catch (_) {}
      }
    }
    notifyListeners();
  }

  Future<void> save() async {
    final f = File(p.join(_root.path, 'library.json'));
    final tmp = File('${f.path}.tmp');
    await tmp.writeAsString(jsonEncode(items.map((a) => a.toJson()).toList()));
    await tmp.rename(f.path);
  }

  void touch() => notifyListeners();

  String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  Future<void> upsert(Anime anime) async {
    anime.updatedAt = DateTime.now().millisecondsSinceEpoch;
    final i = items.indexWhere((a) => a.id == anime.id);
    if (i >= 0) {
      items[i] = anime;
    } else {
      items.insert(0, anime);
    }
    await save();
    notifyListeners();
  }

  Future<void> remove(Anime anime) async {
    items.removeWhere((a) => a.id == anime.id);
    try {
      final dir = Directory(p.join(_root.path, anime.id));
      if (await dir.exists()) await dir.delete(recursive: true);
    } catch (_) {}
    await save();
    notifyListeners();
  }

  /// 把选好的文件放进应用目录，返回新路径。
  Future<String> importFile(String src, String animeId) async {
    final dir = Directory(p.join(_root.path, animeId));
    await dir.create(recursive: true);
    final base = p.basenameWithoutExtension(src);
    final ext = p.extension(src);
    var dest = p.join(dir.path, '$base$ext');
    var n = 1;
    while (await File(dest).exists()) {
      dest = p.join(dir.path, '${base}_$n$ext');
      n++;
    }
    final tmp = (await getTemporaryDirectory()).path;
    if (p.isWithin(tmp, src)) {
      // 来自选择器缓存：直接移动，速度快
      try {
        await File(src).rename(dest);
        return dest;
      } catch (_) {}
      await File(src).copy(dest);
      try {
        await File(src).delete();
      } catch (_) {}
    } else {
      await File(src).copy(dest);
    }
    return dest;
  }
}

int naturalCompare(String a, String b) {
  final re = RegExp(r'\d+|\D+');
  final ma = re.allMatches(a.toLowerCase()).map((m) => m.group(0)!).toList();
  final mb = re.allMatches(b.toLowerCase()).map((m) => m.group(0)!).toList();
  for (var i = 0; i < ma.length && i < mb.length; i++) {
    final x = ma[i], y = mb[i];
    final nx = int.tryParse(x), ny = int.tryParse(y);
    final c = (nx != null && ny != null) ? nx.compareTo(ny) : x.compareTo(y);
    if (c != 0) return c;
  }
  return ma.length.compareTo(mb.length);
}
