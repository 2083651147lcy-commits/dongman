import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'library.dart';
import 'pages/app_shell.dart';
import 'settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  final settings = SettingsStore();
  await settings.load();
  final store = LibraryStore(settings);
  runApp(App(settings: settings, store: store));
  unawaited(store.init());
}

class App extends StatelessWidget {
  final SettingsStore settings;
  final LibraryStore store;
  const App({super.key, required this.settings, required this.store});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: settings,
      builder: (context, _) {
        return MaterialApp(
          title: '本地番剧库',
          debugShowCheckedModeBanner: false,
          themeMode: settings.themeMode,
          theme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: settings.seed,
            brightness: Brightness.light,
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: settings.seed,
            brightness: Brightness.dark,
          ),
          builder: (context, child) {
            final mq = MediaQuery.of(context);
            final system = mq.textScaler.scale(14) / 14;
            final dark = Theme.of(context).brightness == Brightness.dark;
            final icons = dark ? Brightness.light : Brightness.dark;
            // 状态栏、导航栏都透明，图标颜色跟随深浅色主题
            final overlay = SystemUiOverlayStyle(
              statusBarColor: Colors.transparent,
              statusBarIconBrightness: icons,
              systemNavigationBarColor: Colors.transparent,
              systemNavigationBarDividerColor: Colors.transparent,
              systemNavigationBarIconBrightness: icons,
              systemNavigationBarContrastEnforced: false,
            );
            return AnnotatedRegion<SystemUiOverlayStyle>(
              value: overlay,
              child: MediaQuery(
                data: mq.copyWith(
                  textScaler: TextScaler.linear(system * settings.uiScale),
                ),
                child: child!,
              ),
            );
          },
          home: AppShell(store: store, settings: settings),
        );
      },
    );
  }
}
