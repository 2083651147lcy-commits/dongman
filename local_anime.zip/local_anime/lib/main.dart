import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';

import 'pages/home_page.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  final store = LibraryStore();
  await store.load();
  runApp(App(store: store));
}

class App extends StatelessWidget {
  final LibraryStore store;
  const App({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '本地番剧库',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
      ),
      home: HomePage(store: store),
    );
  }
}
