import 'package:flutter/material.dart';

import '../store.dart';
import '../widgets.dart';
import 'edit_page.dart';
import 'player_page.dart';

class DetailPage extends StatelessWidget {
  final LibraryStore store;
  final String animeId;
  const DetailPage({super.key, required this.store, required this.animeId});

  Future<void> _play(BuildContext context, int index) async {
    final anime = store.byId(animeId);
    if (anime == null || anime.episodes.isEmpty) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PlayerPage(store: store, anime: anime, index: index),
      ),
    );
    store.touch();
  }

  Future<void> _delete(BuildContext context) async {
    final anime = store.byId(animeId);
    if (anime == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除番剧'),
        content: Text('将删除「${anime.title}」及已导入的视频文件，无法恢复。'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('删除')),
        ],
      ),
    );
    if (ok == true) {
      await store.remove(anime);
      if (context.mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final anime = store.byId(animeId);
        if (anime == null) {
          return const Scaffold(body: Center(child: Text('已删除')));
        }
        final theme = Theme.of(context);
        return Scaffold(
          appBar: AppBar(
            title: Text(anime.title, overflow: TextOverflow.ellipsis),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => EditPage(store: store, anime: anime),
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _delete(context),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: SizedBox(
                      width: 120,
                      height: 170,
                      child: CoverImage(path: anime.coverPath),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(anime.title, style: theme.textTheme.titleLarge),
                        const SizedBox(height: 8),
                        Text('共 ${anime.episodes.length} 集',
                            style: theme.textTheme.bodyMedium),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            for (final t in anime.tags)
                              Chip(
                                label: Text(t),
                                visualDensity: VisualDensity.compact,
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: anime.episodes.isEmpty
                    ? null
                    : () => _play(context, anime.continueIndex),
                icon: const Icon(Icons.play_arrow),
                label: Text(anime.episodes.isEmpty
                    ? '还没有视频'
                    : '继续播放 · ${anime.episodes[anime.continueIndex].title}'),
              ),
              if (anime.synopsis.trim().isNotEmpty) ...[
                const SizedBox(height: 20),
                Text('简介', style: theme.textTheme.titleMedium),
                const SizedBox(height: 6),
                Text(anime.synopsis),
              ],
              const SizedBox(height: 20),
              Text('剧集', style: theme.textTheme.titleMedium),
              const SizedBox(height: 6),
              for (var i = 0; i < anime.episodes.length; i++)
                _EpisodeTile(
                  title: anime.episodes[i].title,
                  progress: anime.episodes[i].progress,
                  finished: anime.episodes[i].finished,
                  positionMs: anime.episodes[i].positionMs,
                  durationMs: anime.episodes[i].durationMs,
                  current: i == anime.lastEpisode,
                  onTap: () => _play(context, i),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _EpisodeTile extends StatelessWidget {
  final String title;
  final double progress;
  final bool finished;
  final bool current;
  final int positionMs;
  final int durationMs;
  final VoidCallback onTap;

  const _EpisodeTile({
    required this.title,
    required this.progress,
    required this.finished,
    required this.current,
    required this.positionMs,
    required this.durationMs,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    String sub;
    if (finished) {
      sub = '已看完';
    } else if (positionMs > 0 && durationMs > 0) {
      sub = '${fmtDuration(positionMs)} / ${fmtDuration(durationMs)}';
    } else {
      sub = '未观看';
    }
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        onTap: onTap,
        leading: Icon(
          finished ? Icons.check_circle : Icons.play_circle_outline,
          color: current ? cs.primary : null,
        ),
        title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(sub),
            if (!finished && progress > 0)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: LinearProgressIndicator(value: progress),
              ),
          ],
        ),
      ),
    );
  }
}
