import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../library.dart';
import '../models.dart';
import '../settings.dart';
import '../ui/anime_card.dart';
import '../ui/second_picker.dart';
import '../ui/stills.dart';
import 'edit_meta_page.dart';

class DetailPage extends StatefulWidget {
  final LibraryStore store;
  final SettingsStore settings;
  final String animePath;
  const DetailPage({
    super.key,
    required this.store,
    required this.settings,
    required this.animePath,
  });

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  @override
  void initState() {
    super.initState();
    // 打开详情页后，在后台读取每一集的时长
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final a = widget.store.byPath(widget.animePath);
      if (a != null) widget.store.loadDurations(a);
    });
  }

  @override
  Widget build(BuildContext context) => _DetailBody(
        store: widget.store,
        settings: widget.settings,
        animePath: widget.animePath,
      );
}

class _DetailBody extends StatelessWidget {
  final LibraryStore store;
  final SettingsStore settings;
  final String animePath;
  const _DetailBody({
    super.key,
    required this.store,
    required this.settings,
    required this.animePath,
  });

  Future<void> _play(BuildContext context, Anime a, Episode e) async {
    final err = await store.play(a, e);
    if (err != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  /// 只有图片的番剧：全屏查看第一张（可左右翻页）。不记进历史。
  Future<void> _viewStills(BuildContext context, Anime a) async {
    final dirs = <String>{a.path, for (final e in a.episodes) p.dirname(e.path)};
    final files = await listStills(dirs);
    if (files.isEmpty || !context.mounted) return;
    await openStillViewer(context, files, 0);
  }

  Future<void> _askCoverSecond(BuildContext context, Anime a) async {
    final cur =
        (a.coverMs > 0 ? a.coverMs : settings.coverSecond * 1000) ~/ 1000;
    final v = await showCoverSecondPicker(context, cur,
        haptic: settings.navHaptic);
    if (v != null && v >= 0) await store.setCoverSecond(a, v);
  }

  /// 长按一集：同时改视频文件名和这里显示的名字（扩展名不变）
  Future<void> _renameEpisode(BuildContext context, Anime a, Episode e) async {
    final ctl = TextEditingController(text: e.baseName);
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('修改剧名'),
        content: TextField(
          controller: ctl,
          autofocus: true,
          maxLines: null,
          decoration: InputDecoration(
            suffixText: p.extension(e.name),
            helperText: '会同时修改视频文件名',
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctl.text),
            child: const Text('确定'),
          ),
        ],
      ),
    );
    ctl.dispose();
    if (v == null) return;
    final err = await store.renameEpisode(a, e, v);
    if (err != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([store, settings]),
      builder: (context, _) {
        final a = store.byPath(animePath);
        if (a == null) {
          return Scaffold(
            appBar: AppBar(),
            body: const Center(child: Text('这部番剧已不存在')),
          );
        }
        final theme = Theme.of(context);
        final next = a.resumeEpisode;

        final children = <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(settings.coverRadius),
                child: SizedBox(
                  width: 120,
                  height: 120 / settings.ratio,
                  child: CoverImage(path: a.coverPath),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(a.name, style: theme.textTheme.titleLarge),
                    if (a.releaseDate.trim().isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(a.releaseDate.trim(),
                          style: theme.textTheme.bodyMedium),
                    ],
                    const SizedBox(height: 6),
                    Text(
                        a.episodes.isEmpty
                            ? '共 ${a.stillCount} 张'
                            : '共 ${a.episodes.length} 集',
                        style: theme.textTheme.bodyMedium),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        for (final t in a.tags)
                          Chip(
                              label: Text(t),
                              visualDensity: VisualDensity.compact),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (next != null)
            FilledButton.icon(
              onPressed: () => _play(context, a, next),
              icon: const Icon(Icons.play_arrow),
              label: Text(
                a.hasResume
                    ? '继续 · ${next.title}'
                    : '开始观看 · ${next.title}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          if (next == null && a.stillCount > 0)
            // 没有视频、只有图片：按钮改为全屏查看第一张剧照
            FilledButton.icon(
              onPressed: () => _viewStills(context, a),
              icon: const Icon(Icons.photo_outlined),
              label: const Text('查看剧照'),
            ),
          if (a.synopsis.trim().isNotEmpty) ...[
            const SizedBox(height: 20),
            _Synopsis(text: a.synopsis.trim()),
          ],
          if (a.episodes.isNotEmpty) ...[
            const SizedBox(height: 20),
            Text('剧集', style: theme.textTheme.titleMedium),
            const SizedBox(height: 6),
          ],
        ];

        String? lastGroup;
        for (final e in a.episodes) {
          if (e.group != lastGroup) {
            if (e.group.isNotEmpty) {
              children.add(Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 4),
                child: Text(e.group,
                    style: theme.textTheme.titleSmall
                        ?.copyWith(color: theme.colorScheme.primary)),
              ));
            }
            lastGroup = e.group;
          }
          final isLast = a.relOf(e) == a.lastEpisode;
          final dur = a.durations[a.relOf(e)] ?? 0;
          children.add(Card(
            margin: const EdgeInsets.symmetric(vertical: 3),
            child: ListTile(
              onTap: () => _play(context, a, e),
              onLongPress: () => _renameEpisode(context, a, e),
              leading: Icon(
                isLast ? Icons.play_circle : Icons.play_circle_outline,
                color: isLast ? theme.colorScheme.primary : null,
              ),
              title: Text(e.baseName,
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              trailing: dur > 0
                  ? Text(fmtDuration(dur), style: theme.textTheme.bodyMedium)
                  : null,
            ),
          ));
        }
        // 剧照：番剧文件夹和视频所在文件夹里的图片（各只看一层）
        final stillDirs = <String>{a.path, for (final e in a.episodes) p.dirname(e.path)}
            .toList();
        children.add(StillsSection(
          key: ValueKey('${a.path}|${a.episodes.length}'),
          dirs: stillDirs,
          settings: settings,
          revision: store.stillsRev,
        ));
        children.add(Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Text('文件夹：${a.path}', style: theme.textTheme.bodySmall),
        ));

        return Scaffold(
          appBar: AppBar(
            title: Text(a.name, overflow: TextOverflow.ellipsis),
            actions: [
              PopupMenuButton<String>(
                onSelected: (v) async {
                  switch (v) {
                    case 'edit':
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => EditMetaPage(store: store, anime: a),
                        ),
                      );
                      break;
                    case 'cover':
                      // 点击一律是选择截取几分几秒；长按菜单项恢复默认
                      await _askCoverSecond(context, a);
                      break;
                  }
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(value: 'edit', child: Text('编辑')),
                  if (a.episodes.isNotEmpty)
                    PopupMenuItem(
                    value: 'cover',
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      // 长按：关掉菜单，封面恢复为默认截取时间
                      onLongPress: () {
                        Navigator.pop(context);
                        if (a.coverMs > 0) store.useAutoCover(a);
                      },
                      child: SizedBox(
                        width: double.infinity,
                        child: Text(a.coverMs > 0
                            ? '封面：${fmtMinSec(a.coverMs ~/ 1000)}'
                            : '截取封面'),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          body: ListView(
            padding: EdgeInsets.fromLTRB(
                16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
            children: children,
          ),
        );
      },
    );
  }
}

/// 打开番剧详情页（首页、历史、收藏夹共用）
void openAnimeDetail(
  BuildContext context,
  LibraryStore store,
  SettingsStore settings,
  Anime a,
) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) =>
          DetailPage(store: store, settings: settings, animePath: a.path),
    ),
  );
}

/// 简介：标题整行和内容区域都能点。
/// 长简介（超过 4 行）：默认显示 4 行 → 点一下全部展开 → 再点只剩“简介”标题 → 再点全部展开……
/// 短简介（不超过 4 行）：默认全部显示 ↔ 点一下只剩“简介”标题。
enum _SynopsisState { clamped, full, hidden }

class _Synopsis extends StatefulWidget {
  final String text;
  const _Synopsis({required this.text});

  @override
  State<_Synopsis> createState() => _SynopsisStateWidget();
}

class _SynopsisStateWidget extends State<_Synopsis> {
  _SynopsisState? _state; // null = 还没点过，用默认状态

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final style = theme.textTheme.bodyMedium;
    return LayoutBuilder(builder: (context, c) {
      final tp = TextPainter(
        text: TextSpan(text: widget.text, style: style),
        textDirection: TextDirection.ltr,
        textScaler: MediaQuery.textScalerOf(context),
        maxLines: 4,
      )..layout(maxWidth: c.maxWidth);
      final isLong = tp.didExceedMaxLines;
      tp.dispose();

      final state =
          _state ?? (isLong ? _SynopsisState.clamped : _SynopsisState.full);
      void toggle() => setState(() {
            _state = state == _SynopsisState.full
                ? _SynopsisState.hidden
                : _SynopsisState.full;
          });

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: toggle,
            child: Container(
              width: double.infinity,
              constraints: const BoxConstraints(minHeight: 44),
              alignment: Alignment.centerLeft,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('简介', style: theme.textTheme.titleMedium),
                  Icon(state == _SynopsisState.full
                      ? Icons.expand_less
                      : Icons.expand_more),
                ],
              ),
            ),
          ),
          if (state != _SynopsisState.hidden)
            InkWell(
              onTap: toggle,
              child: SizedBox(
                width: double.infinity,
                child: Text(
                  widget.text,
                  style: style,
                  // 只有限制 4 行时才用省略号；不限行数时再加省略号，
                  // Flutter 会把整段当成一行，展开后就只剩一行了
                  maxLines: state == _SynopsisState.clamped ? 4 : null,
                  overflow: state == _SynopsisState.clamped
                      ? TextOverflow.ellipsis
                      : TextOverflow.clip,
                ),
              ),
            ),
        ],
      );
    });
  }
}
