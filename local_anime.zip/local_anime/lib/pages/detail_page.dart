import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';
import '../settings.dart';
import '../ui/anime_card.dart';
import 'edit_meta_page.dart';

class DetailPage extends StatelessWidget {
  final LibraryStore store;
  final SettingsStore settings;
  final String animePath;
  const DetailPage({
    super.key,
    required this.store,
    required this.settings,
    required this.animePath,
  });

  Future<void> _play(BuildContext context, Anime a, Episode e) async {
    final err = await store.play(a, e);
    if (err != null && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  Future<void> _askCoverSecond(BuildContext context, Anime a) async {
    final ctl = TextEditingController(
      text: '${(a.coverMs > 0 ? a.coverMs : settings.coverSecond * 1000) ~/ 1000}',
    );
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('截取第几秒作封面'),
        content: TextField(
          controller: ctl,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: const InputDecoration(suffixText: '秒'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, int.tryParse(ctl.text.trim())),
            child: const Text('截取'),
          ),
        ],
      ),
    );
    ctl.dispose();
    if (v != null && v >= 0) await store.setCoverSecond(a, v);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([store, settings]),
      builder: (context, _) {
        final a = store.byPath(animePath);
        if (a == null) {
          return Scaffold(
            appBar: AppBar(),
            body: const Center(child: Text('这部番剧已不存在')),
          );
        }
        final theme = Theme.of(context);
        final next = a.nextToWatch;

        final children = <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(settings.coverRadius),
                child: SizedBox(
                  width: 120,
                  height: 120 / settings.ratio,
                  child: CoverImage(path: a.coverPath),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(a.name, style: theme.textTheme.titleLarge),
                    const SizedBox(height: 6),
                    Text('共 ${a.episodes.length} 集 · 已看 ${a.watchedCount}',
                        style: theme.textTheme.bodyMedium),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        for (final t in a.tags)
                          Chip(
                              label: Text(t),
                              visualDensity: VisualDensity.compact),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (next != null)
            FilledButton.icon(
              onPressed: () => _play(context, a, next),
              icon: const Icon(Icons.play_arrow),
              label: Text(
                a.watchedCount == 0
                    ? '开始观看 · ${next.title}'
                    : '继续 · ${next.title}',
              ),
            ),
          if (a.synopsis.trim().isNotEmpty) ...[
            const SizedBox(height: 20),
            Text('简介', style: theme.textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(a.synopsis),
          ],
          const SizedBox(height: 20),
          Text('剧集', style: theme.textTheme.titleMedium),
          const SizedBox(height: 6),
        ];

        String? lastGroup;
        for (final e in a.episodes) {
          if (e.group != lastGroup) {
            if (e.group.isNotEmpty) {
              children.add(Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 4),
                child: Text(e.group,
                    style: theme.textTheme.titleSmall
                        ?.copyWith(color: theme.colorScheme.primary)),
              ));
            }
            lastGroup = e.group;
          }
          final watched = a.isWatched(e);
          final isLast = a.relOf(e) == a.lastEpisode;
          children.add(Card(
            margin: const EdgeInsets.symmetric(vertical: 3),
            child: ListTile(
              onTap: () => _play(context, a, e),
              leading: Icon(
                isLast ? Icons.play_circle : Icons.play_circle_outline,
                color: isLast ? theme.colorScheme.primary : null,
              ),
              title: Text(e.title, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              trailing: IconButton(
                tooltip: watched ? '标为未看' : '标为已看',
                icon: Icon(
                  watched ? Icons.check_circle : Icons.radio_button_unchecked,
                  color: watched ? theme.colorScheme.primary : null,
                ),
                onPressed: () => store.toggleWatched(a, e),
              ),
            ),
          ));
        }
        children.add(Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Text('文件夹：${a.path}', style: theme.textTheme.bodySmall),
        ));

        return Scaffold(
          appBar: AppBar(
            title: Text(a.name, overflow: TextOverflow.ellipsis),
            actions: [
              PopupMenuButton<String>(
                onSelected: (v) async {
                  switch (v) {
                    case 'edit':
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => EditMetaPage(store: store, anime: a),
                        ),
                      );
                      break;
                    case 'cover':
                      await _askCoverSecond(context, a);
                      break;
                    case 'autocover':
                      await store.useAutoCover(a);
                      break;
                    case 'allwatched':
                      await store.markAll(a, true);
                      break;
                    case 'allunwatched':
                      await store.markAll(a, false);
                      break;
                    case 'hide':
                      await store.setHidden(a, true);
                      if (context.mounted) Navigator.pop(context);
                      break;
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('编辑简介和标签')),
                  PopupMenuItem(value: 'cover', child: Text('截取视频画面作封面')),
                  PopupMenuItem(value: 'autocover', child: Text('封面改回自动')),
                  PopupMenuItem(value: 'allwatched', child: Text('全部标为已看')),
                  PopupMenuItem(value: 'allunwatched', child: Text('全部标为未看')),
                  PopupMenuItem(value: 'hide', child: Text('隐藏这部番剧')),
                ],
              ),
            ],
          ),
          body: ListView(
            padding: EdgeInsets.fromLTRB(
                16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
            children: children,
          ),
        );
      },
    );
  }
}
