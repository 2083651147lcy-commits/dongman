import 'package:flutter/material.dart';

import '../library.dart';
import '../settings.dart';
import '../ui/anime_card.dart';
import 'home_page.dart' show pickLibraryFolder;

class SettingsPage extends StatelessWidget {
  final LibraryStore store;
  final SettingsStore settings;
  const SettingsPage({super.key, required this.store, required this.settings});

  Widget _h(BuildContext context, String text) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 6),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleSmall
                ?.copyWith(color: Theme.of(context).colorScheme.primary)),
      );

  Widget _slider({
    required String label,
    required String display,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required ValueChanged<double> onChanged,
    ValueChanged<double>? onEnd,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(label), Text(display)],
        ),
        Slider(
          value: value.clamp(min, max),
          min: min,
          max: max,
          divisions: divisions,
          onChanged: onChanged,
          onChangeEnd: onEnd,
        ),
      ],
    );
  }

  Future<void> _pickPlayer(BuildContext context) async {
    List<({String label, String package})> players;
    try {
      players = await store.listPlayers();
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('读取播放器列表失败')));
      }
      return;
    }
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('选择默认播放器'),
        contentPadding: const EdgeInsets.only(top: 12),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: [
              ListTile(
                title: const Text('每次询问'),
                subtitle: const Text('弹出系统的播放器选择框'),
                trailing: settings.playerPackage == null
                    ? const Icon(Icons.check)
                    : null,
                onTap: () {
                  settings.update(() {
                    settings.playerPackage = null;
                    settings.playerLabel = null;
                  });
                  Navigator.pop(ctx);
                },
              ),
              for (final pl in players)
                ListTile(
                  title: Text(pl.label),
                  subtitle: Text(pl.package,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  trailing: settings.playerPackage == pl.package
                      ? const Icon(Icons.check)
                      : null,
                  onTap: () {
                    settings.update(() {
                      settings.playerPackage = pl.package;
                      settings.playerLabel = pl.label;
                    });
                    Navigator.pop(ctx);
                  },
                ),
              if (players.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('没有找到可以播放视频的应用'),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('关闭')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([settings, store]),
      builder: (context, _) {
        final s = settings;
        final bottom = MediaQuery.of(context).padding.bottom;
        return Scaffold(
          appBar: AppBar(title: const Text('设置')),
          body: ListView(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 24 + bottom),
            children: [
              Card(
                clipBehavior: Clip.antiAlias,
                child: ExpansionTile(
                  initiallyExpanded: false,
                  shape: const Border(),
                  collapsedShape: const Border(),
                  title: Text('卡片预览（竖屏 ${s.portraitCols} 列）'),
                  subtitle: const Text('主页和收藏页的卡片都按这个样式显示'),
                  childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (var i = 0; i < s.portraitCols; i++) ...[
                          if (i > 0) SizedBox(width: s.gap),
                          Expanded(
                            child: AnimeCard(
                              title: '示例番剧 ${i + 1}',
                              epCount: 12,
                              tags: const ['热血', '奇幻'],
                              settings: s,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              _h(context, '动漫库'),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('动漫库文件夹'),
                subtitle: Text(s.rootPath ?? '未选择'),
                trailing: FilledButton.tonal(
                  onPressed: () => pickLibraryFolder(context, store),
                  child: const Text('更换'),
                ),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('重新扫描'),
                subtitle: Text(store.scanning
                    ? '正在扫描…'
                    : '共 ${store.items.length} 部番剧'),
                trailing: const Icon(Icons.refresh),
                onTap: () => store.refresh(),
              ),
              _h(context, '布局'),
              _slider(
                label: '竖屏每行显示',
                display: '${s.portraitCols} 个',
                value: s.portraitCols.toDouble(),
                min: 1,
                max: 6,
                divisions: 5,
                onChanged: (v) => s.update(() => s.portraitCols = v.round()),
              ),
              _slider(
                label: '横屏每行显示',
                display: '${s.landscapeCols} 个',
                value: s.landscapeCols.toDouble(),
                min: 1,
                max: 10,
                divisions: 9,
                onChanged: (v) => s.update(() => s.landscapeCols = v.round()),
              ),
              const Text('封面比例'),
              const SizedBox(height: 6),
              SegmentedButton<int>(
                showSelectedIcon: false,
                segments: [
                  for (var i = 0; i < SettingsStore.ratioLabels.length; i++)
                    ButtonSegment(
                        value: i, label: Text(SettingsStore.ratioLabels[i])),
                ],
                selected: {s.ratioIndex},
                onSelectionChanged: (v) =>
                    s.update(() => s.ratioIndex = v.first),
              ),
              const SizedBox(height: 14),
              const Text('卡片间距'),
              const SizedBox(height: 6),
              SegmentedButton<int>(
                showSelectedIcon: false,
                segments: [
                  for (var i = 0; i < SettingsStore.spacingLabels.length; i++)
                    ButtonSegment(
                        value: i, label: Text(SettingsStore.spacingLabels[i])),
                ],
                selected: {s.spacingIndex},
                onSelectionChanged: (v) =>
                    s.update(() => s.spacingIndex = v.first),
              ),
              const SizedBox(height: 8),
              _slider(
                label: '封面圆角',
                display: s.coverRadius.round().toString(),
                value: s.coverRadius,
                min: 0,
                max: 24,
                divisions: 24,
                onChanged: (v) => s.update(() => s.coverRadius = v),
              ),
              _h(context, '文字与缩放'),
              _slider(
                label: '标题字号',
                display: s.titleFont.round().toString(),
                value: s.titleFont,
                min: 10,
                max: 20,
                divisions: 10,
                onChanged: (v) => s.update(() => s.titleFont = v),
              ),
              const Text('标题显示行数'),
              const SizedBox(height: 6),
              SegmentedButton<int>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 1, label: Text('1 行')),
                  ButtonSegment(value: 2, label: Text('2 行')),
                ],
                selected: {s.titleLines},
                onSelectionChanged: (v) =>
                    s.update(() => s.titleLines = v.first),
              ),
              const SizedBox(height: 8),
              _slider(
                label: '全局界面缩放',
                display: '${s.uiScale.toStringAsFixed(2)}x',
                value: s.uiScale,
                min: 0.8,
                max: 1.3,
                divisions: 10,
                onChanged: (v) => s.update(() => s.uiScale = v),
              ),
              _h(context, '卡片显示内容'),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('显示集数'),
                value: s.showEpCount,
                onChanged: (v) => s.update(() => s.showEpCount = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('显示标签'),
                value: s.showTags,
                onChanged: (v) => s.update(() => s.showTags = v),
              ),
              _h(context, '主题'),
              SegmentedButton<int>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 0, label: Text('跟随系统')),
                  ButtonSegment(value: 1, label: Text('浅色')),
                  ButtonSegment(value: 2, label: Text('深色')),
                ],
                selected: {s.themeIndex},
                onSelectionChanged: (v) =>
                    s.update(() => s.themeIndex = v.first),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (var i = 0; i < SettingsStore.seeds.length; i++)
                    GestureDetector(
                      onTap: () => s.update(() => s.seedIndex = i),
                      child: CircleAvatar(
                        radius: 18,
                        backgroundColor: SettingsStore.seeds[i],
                        child: s.seedIndex == i
                            ? const Icon(Icons.check, color: Colors.white)
                            : null,
                      ),
                    ),
                ],
              ),
              _h(context, '历史记录'),
              _slider(
                label: '历史记录显示条数',
                display: '${s.historyLimit} 条',
                value: s.historyLimit.toDouble(),
                min: 5,
                max: 50,
                divisions: 9,
                onChanged: (v) => s.update(() => s.historyLimit = v.round()),
              ),
              _h(context, '外部播放器'),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('默认播放器'),
                subtitle: Text(s.playerLabel ?? '每次询问'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _pickPlayer(context),
              ),
              _h(context, '封面与播放'),
              _slider(
                label: '封面默认截取第几秒',
                display: '${s.coverSecond} 秒',
                value: s.coverSecond.toDouble(),
                min: 0,
                max: 300,
                divisions: 60,
                onChanged: (v) => s.update(() => s.coverSecond = v.round()),
                onEnd: (_) => store.onDefaultCoverSecondChanged(),
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: () => s.resetDisplay(),
                icon: const Icon(Icons.restore),
                label: const Text('恢复默认显示设置'),
              ),
            ],
          ),
        );
      },
    );
  }
}
