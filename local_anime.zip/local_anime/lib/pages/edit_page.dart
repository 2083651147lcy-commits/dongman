import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../models.dart';
import '../store.dart';
import '../widgets.dart';

class _EpDraft {
  String title;
  String path;
  bool pending; // true = 刚选的文件，保存时才导入
  int positionMs;
  int durationMs;
  _EpDraft({
    required this.title,
    required this.path,
    this.pending = false,
    this.positionMs = 0,
    this.durationMs = 0,
  });
}

class EditPage extends StatefulWidget {
  final LibraryStore store;
  final Anime? anime; // null = 新建
  const EditPage({super.key, required this.store, this.anime});

  @override
  State<EditPage> createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  late final TextEditingController _title;
  late final TextEditingController _synopsis;
  final _tagInput = TextEditingController();
  final List<String> _tags = [];
  final List<_EpDraft> _eps = [];
  final List<String> _removedFiles = [];
  String? _cover;
  bool _coverPending = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final a = widget.anime;
    _title = TextEditingController(text: a?.title ?? '');
    _synopsis = TextEditingController(text: a?.synopsis ?? '');
    if (a != null) {
      _tags.addAll(a.tags);
      _cover = a.coverPath;
      for (final e in a.episodes) {
        _eps.add(_EpDraft(
          title: e.title,
          path: e.path,
          positionMs: e.positionMs,
          durationMs: e.durationMs,
        ));
      }
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _synopsis.dispose();
    _tagInput.dispose();
    super.dispose();
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------- 封面 ----------
  void _dropOldCover() {
    if (_cover != null && !_coverPending) _removedFiles.add(_cover!);
  }

  Future<void> _pickCover() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    final path = r?.files.single.path;
    if (path == null) return;
    setState(() {
      _dropOldCover();
      _cover = path;
      _coverPending = true;
    });
  }

  void _clearCover() {
    setState(() {
      _dropOldCover();
      _cover = null;
      _coverPending = false;
    });
  }

  // ---------- 标签 ----------
  void _addTags(String raw) {
    final parts = raw
        .split(RegExp(r'[,，、;；\n]'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty);
    setState(() {
      for (final t in parts) {
        if (!_tags.contains(t)) _tags.add(t);
      }
      _tagInput.clear();
    });
  }

  // ---------- 剧集 ----------
  Future<void> _pickVideos() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: true,
    );
    if (r == null) return;
    final files = r.files.where((f) => f.path != null).toList()
      ..sort((a, b) => naturalCompare(a.name, b.name));
    setState(() {
      for (final f in files) {
        _eps.add(_EpDraft(
          title: p.basenameWithoutExtension(f.name),
          path: f.path!,
          pending: true,
        ));
      }
    });
  }

  Future<void> _renameEp(int i) async {
    final ctl = TextEditingController(text: _eps[i].title);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('修改集名'),
        content: TextField(controller: ctl, autofocus: true),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctl.text),
              child: const Text('确定')),
        ],
      ),
    );
    ctl.dispose();
    if (name != null && name.trim().isNotEmpty) {
      setState(() => _eps[i].title = name.trim());
    }
  }

  void _removeEp(int i) {
    setState(() {
      final d = _eps.removeAt(i);
      if (!d.pending) {
        _removedFiles.add(d.path);
      } else {
        // 还没导入的缓存文件，顺手清理
        File(d.path).delete().catchError((_) => File(d.path));
      }
    });
  }

  // ---------- 保存 ----------
  Future<void> _save() async {
    final title = _title.text.trim();
    if (title.isEmpty) {
      _toast('请先填写名称');
      return;
    }
    if (_tagInput.text.trim().isNotEmpty) _addTags(_tagInput.text);

    setState(() => _saving = true);
    try {
      final old = widget.anime;
      final id = old?.id ?? widget.store.newId();

      String? cover = _cover;
      if (_coverPending && _cover != null) {
        cover = await widget.store.importFile(_cover!, id);
      }

      final eps = <Episode>[];
      for (final d in _eps) {
        var path = d.path;
        if (d.pending) path = await widget.store.importFile(path, id);
        eps.add(Episode(
          title: d.title.trim().isEmpty
              ? p.basenameWithoutExtension(path)
              : d.title.trim(),
          path: path,
          positionMs: d.positionMs,
          durationMs: d.durationMs,
        ));
      }

      for (final f in _removedFiles) {
        try {
          await File(f).delete();
        } catch (_) {}
      }

      var last = old?.lastEpisode ?? 0;
      if (eps.isEmpty) {
        last = 0;
      } else {
        last = last.clamp(0, eps.length - 1);
      }

      await widget.store.upsert(Anime(
        id: id,
        title: title,
        synopsis: _synopsis.text.trim(),
        tags: List.of(_tags),
        coverPath: cover,
        episodes: eps,
        lastEpisode: last,
      ));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        _toast('保存失败：$e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final suggestions =
        widget.store.allTags.where((t) => !_tags.contains(t)).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.anime == null ? '添加番剧' : '编辑番剧'),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: const Text('保存'),
          ),
        ],
      ),
      body: Stack(
        children: [
          AbsorbPointer(
            absorbing: _saving,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      children: [
                        GestureDetector(
                          onTap: _pickCover,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: SizedBox(
                              width: 110,
                              height: 156,
                              child: _cover == null
                                  ? Container(
                                      color: theme
                                          .colorScheme.surfaceContainerHighest,
                                      alignment: Alignment.center,
                                      child: const Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.add_photo_alternate_outlined),
                                          SizedBox(height: 4),
                                          Text('选择封面'),
                                        ],
                                      ),
                                    )
                                  : CoverImage(path: _cover),
                            ),
                          ),
                        ),
                        if (_cover != null)
                          TextButton(
                              onPressed: _clearCover,
                              child: const Text('移除封面')),
                      ],
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: TextField(
                        controller: _title,
                        decoration: const InputDecoration(
                          labelText: '名称 *',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _synopsis,
                  minLines: 3,
                  maxLines: 8,
                  decoration: const InputDecoration(
                    labelText: '简介',
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                Text('标签', style: theme.textTheme.titleMedium),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final t in _tags)
                      InputChip(
                        label: Text(t),
                        onDeleted: () => setState(() => _tags.remove(t)),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _tagInput,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: '输入标签，回车或逗号分隔',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.add),
                      onPressed: () => _addTags(_tagInput.text),
                    ),
                  ),
                  onSubmitted: _addTags,
                ),
                if (suggestions.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final t in suggestions)
                        ActionChip(
                          label: Text(t),
                          onPressed: () => setState(() => _tags.add(t)),
                        ),
                    ],
                  ),
                ],
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: Text('剧集（${_eps.length}）',
                          style: theme.textTheme.titleMedium),
                    ),
                    FilledButton.tonalIcon(
                      onPressed: _pickVideos,
                      icon: const Icon(Icons.video_file_outlined),
                      label: const Text('添加视频'),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const Text('长按并拖动可调整顺序；一次可选多个文件，会按文件名自然排序。'),
                const SizedBox(height: 8),
                ReorderableListView(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  onReorder: (o, n) {
                    setState(() {
                      if (n > o) n -= 1;
                      _eps.insert(n, _eps.removeAt(o));
                    });
                  },
                  children: [
                    for (var i = 0; i < _eps.length; i++)
                      Card(
                        key: ObjectKey(_eps[i]),
                        child: ListTile(
                          title: Text(_eps[i].title,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(
                            p.basename(_eps[i].path),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit_outlined),
                                onPressed: () => _renameEp(i),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () => _removeEp(i),
                              ),
                              const SizedBox(width: 24),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 80),
              ],
            ),
          ),
          if (_saving)
            Container(
              color: Colors.black54,
              alignment: Alignment.center,
              child: const Card(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 16),
                      Text('正在导入文件，请稍候…'),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
