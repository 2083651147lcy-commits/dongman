import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';

class EditMetaPage extends StatefulWidget {
  final LibraryStore store;
  final Anime anime;
  const EditMetaPage({super.key, required this.store, required this.anime});

  @override
  State<EditMetaPage> createState() => _EditMetaPageState();
}

class _EditMetaPageState extends State<EditMetaPage> {
  late final TextEditingController _synopsis;
  late final TextEditingController _release;
  final _tagInput = TextEditingController();
  late List<String> _tags;

  @override
  void initState() {
    super.initState();
    _synopsis = TextEditingController(text: widget.anime.synopsis);
    _release = TextEditingController(text: widget.anime.releaseDate);
    _tags = List.of(widget.anime.tags);
  }

  @override
  void dispose() {
    _synopsis.dispose();
    _release.dispose();
    _tagInput.dispose();
    super.dispose();
  }

  void _addTags(String raw) {
    final parts = raw
        .split(RegExp(r'[,，、;；\n]'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty);
    setState(() {
      for (final t in parts) {
        if (!_tags.contains(t)) _tags.add(t);
      }
      _tagInput.clear();
    });
  }

  Future<void> _save() async {
    if (_tagInput.text.trim().isNotEmpty) _addTags(_tagInput.text);
    widget.anime.synopsis = _synopsis.text.trim();
    widget.anime.releaseDate = _release.text.trim();
    widget.anime.tags = List.of(_tags);
    await widget.store.saveMeta(widget.anime);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final suggestions =
        widget.store.allTags.where((t) => !_tags.contains(t)).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('编辑'),
        actions: [TextButton(onPressed: _save, child: const Text('保存'))],
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(
            16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
        children: [
          Text(widget.anime.name, style: theme.textTheme.titleMedium),
          const SizedBox(height: 4),
          Text('名称就是文件夹名，要改名请在文件管理器里改文件夹。',
              style: theme.textTheme.bodySmall),
          const SizedBox(height: 16),
          TextField(
            controller: _release,
            decoration: const InputDecoration(
              labelText: '上映时间（可不填）',
              hintText: '例如：2024年4月、2024-04、春番',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _synopsis,
            minLines: 4,
            maxLines: 10,
            decoration: const InputDecoration(
              labelText: '简介',
              alignLabelWithHint: true,
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          Text('标签', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final t in _tags)
                InputChip(
                  label: Text(t),
                  onDeleted: () => setState(() => _tags.remove(t)),
                ),
            ],
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _tagInput,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              hintText: '输入标签，回车或逗号分隔',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.add),
                onPressed: () => _addTags(_tagInput.text),
              ),
            ),
            onSubmitted: _addTags,
          ),
          if (suggestions.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final t in suggestions)
                  ActionChip(
                    label: Text(t),
                    onPressed: () => setState(() => _tags.add(t)),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
