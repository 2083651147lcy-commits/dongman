import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../library.dart';
import '../models.dart';
import '../ui/progress_dialog.dart';
import '../ui/stills.dart';
import 'file_browser_page.dart';

/// 编辑番剧；也用来填写“导入”时的信息（anime 为 null，视频来自 importSources）
class EditMetaPage extends StatefulWidget {
  final LibraryStore store;
  final Anime? anime;
  final List<String> importSources;
  final List<String> stillSources; // 导入时一起带进来的图片（整个文件夹导入用）
  final String? defaultName; // 导入时名称的默认值（整个文件夹导入用文件夹名）
  final String? sourceFolder; // 整个文件夹导入：移动完后空了就删掉

  const EditMetaPage({super.key, required this.store, this.anime})
      : importSources = const [],
        stillSources = const [],
        defaultName = null,
        sourceFolder = null;

  const EditMetaPage.importing({
    super.key,
    required this.store,
    required this.importSources,
    this.stillSources = const [],
    this.defaultName,
    this.sourceFolder,
  }) : anime = null;

  @override
  State<EditMetaPage> createState() => _EditMetaPageState();
}

class _EditMetaPageState extends State<EditMetaPage> {
  late final TextEditingController _name;
  late final TextEditingController _synopsis;
  late final TextEditingController _release;
  final _tagInput = TextEditingController();
  late List<String> _tags;
  late List<DraftEp> _eps;
  List<DraftImg> _stills = [];
  Set<String> _origStills = {}; // 打开编辑页时已有的图片
  bool _stillsLoaded = false;
  bool _copy = false; // false = 移动，true = 复制

  bool get _importing => widget.anime == null;

  /// 编辑模式下，保存时会被永久删除的已有视频数量
  int get _removeCount {
    final a = widget.anime;
    if (a == null) return 0;
    return a.episodes.length - _eps.where((d) => d.existing != null).length;
  }

  /// 编辑模式下，保存时会被永久删除的已有图片数量
  int get _stillRemoveCount {
    if (!_stillsLoaded || _importing) return 0;
    return _origStills.length - _stills.where((d) => d.existing != null).length;
  }

  @override
  void initState() {
    super.initState();
    final a = widget.anime;
    final firstFile = widget.importSources.isNotEmpty
        ? widget.importSources.first
        : (widget.stillSources.isNotEmpty ? widget.stillSources.first : null);
    final first = firstFile == null ? '' : p.basenameWithoutExtension(firstFile);
    _name = TextEditingController(text: a?.name ?? widget.defaultName ?? first);
    _synopsis = TextEditingController(text: a?.synopsis ?? '');
    _release = TextEditingController(
        text: a != null ? a.releaseDate : fmtDateCn(DateTime.now()));
    _tags = List.of(a?.tags ?? const <String>[]);
    _eps = a != null
        ? [for (final e in a.episodes) DraftEp.existing(e)]
        : [for (final s in widget.importSources) DraftEp.source(s)];
    if (a != null) {
      _loadStills(a);
    } else {
      _stills = [for (final s in widget.stillSources) DraftImg.source(s)];
      _stillsLoaded = true;
    }
  }

  Future<void> _loadStills(Anime a) async {
    final dirs = <String>{a.path, for (final e in a.episodes) p.dirname(e.path)};
    final files = await listStills(dirs);
    if (!mounted) return;
    setState(() {
      _origStills = {for (final f in files) f.path};
      _stills = [for (final f in files) DraftImg.existing(f.path)];
      _stillsLoaded = true;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _synopsis.dispose();
    _release.dispose();
    _tagInput.dispose();
    super.dispose();
  }

  void _addTags(String raw) {
    final parts = raw
        .split(RegExp(r'[,，、;；\n]'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty);
    setState(() {
      for (final t in parts) {
        if (!_tags.contains(t)) _tags.add(t);
      }
      _tagInput.clear();
    });
  }

  void _snack(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<List<String>?> _pick({bool single = false}) =>
      Navigator.push<List<String>>(
        context,
        MaterialPageRoute(
          builder: (_) => FileBrowserPage(
            title: single ? '选择替换用的视频' : '选择要添加的视频',
            single: single,
          ),
        ),
      );

  /// 这个视频本来就在这部番剧的文件夹里
  bool _inside(String s) =>
      widget.anime != null && p.isWithin(widget.anime!.path, s);

  Future<void> _addVideos() async {
    final r = await _pick();
    if (r == null || r.isEmpty || !mounted) return;
    setState(() {
      for (final s in r) {
        if (_inside(s)) continue;
        if (_eps.any((d) => d.source == s || d.existing?.path == s)) continue;
        _eps.add(DraftEp.source(s));
      }
    });
  }

  Future<void> _replace(int i) async {
    final r = await _pick(single: true);
    if (r == null || r.isEmpty || !mounted) return;
    if (_inside(r.first)) {
      _snack('这个视频已经在这部番剧的文件夹里了');
      return;
    }
    setState(() => _eps[i] = DraftEp.source(r.first));
  }

  void _remove(int i) => setState(() => _eps.removeAt(i));

  Future<List<String>?> _pickImages({bool single = false}) =>
      Navigator.push<List<String>>(
        context,
        MaterialPageRoute(
          builder: (_) => FileBrowserPage(
            title: single ? '选择替换用的图片' : '选择要添加的图片',
            single: single,
            images: true,
          ),
        ),
      );

  Future<void> _addStills() async {
    final r = await _pickImages();
    if (r == null || r.isEmpty || !mounted) return;
    setState(() {
      for (final s in r) {
        if (_inside(s)) continue;
        if (_stills.any((d) => d.path == s)) continue;
        _stills.add(DraftImg.source(s));
      }
    });
  }

  Future<void> _replaceStill(int i) async {
    final r = await _pickImages(single: true);
    if (r == null || r.isEmpty || !mounted) return;
    if (_inside(r.first)) {
      _snack('这张图片已经在这部番剧的文件夹里了');
      return;
    }
    setState(() => _stills[i] = DraftImg.source(r.first));
  }

  void _removeStill(int i) => setState(() => _stills.removeAt(i));

  Future<void> _save() async {
    if (_tagInput.text.trim().isNotEmpty) _addTags(_tagInput.text);
    final name = _name.text.trim();
    if (name.isEmpty) {
      _snack('名称不能为空');
      return;
    }
    if (_eps.isEmpty && !_stillsLoaded) {
      _snack('剧照还在加载，请稍等一下再保存');
      return;
    }
    if (_eps.isEmpty && _stills.isEmpty) {
      _snack(_importing ? '至少要有一个视频或图片' : '至少要保留一个视频或图片；想整部删除请在主页删除这部番剧');
      return;
    }
    final a = widget.anime;
    if (_removeCount > 0 || _stillRemoveCount > 0) {
      final what = [
        if (_removeCount > 0) '$_removeCount 个视频文件',
        if (_stillRemoveCount > 0) '$_stillRemoveCount 张图片',
      ].join('、');
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('永久删除文件？'),
          content: Text(
              '保存后会从手机上永久删除 $what（包括被“更换”掉的旧文件），无法恢复。'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('删除并保存')),
          ],
        ),
      );
      if (ok != true || !mounted) return;
    }
    final res = await runWithProgress<OpResult>(
      context,
      _importing ? '正在导入' : '正在保存',
      (report) => a == null
          ? widget.store.importAnime(
              name: name,
              synopsis: _synopsis.text,
              release: _release.text,
              tags: _tags,
              sources: [for (final d in _eps) d.source!],
              stillSources: [for (final d in _stills) d.source!],
              cleanupFolder: widget.sourceFolder,
              copy: _copy,
              progress: report,
            )
          : widget.store.applyEdit(
              a,
              name: name,
              synopsis: _synopsis.text,
              release: _release.text,
              tags: _tags,
              eps: _eps,
              stills: _stillsLoaded ? _stills : null,
              origStills: _origStills,
              copy: _copy,
              progress: report,
            ),
    );
    if (!mounted) return;
    if (res.message != null) _snack(res.message!);
    if (res.done) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final suggestions =
        widget.store.allTags.where((t) => !_tags.contains(t)).toList();
    final verb = _copy ? '复制' : '移动';
    return Scaffold(
      appBar: AppBar(
        title: Text(_importing ? '导入番剧' : '编辑'),
        actions: [
          TextButton(
              onPressed: _save, child: Text(_importing ? '导入' : '保存')),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(
            16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
        children: [
          TextField(
            controller: _name,
            decoration: InputDecoration(
              labelText: '名称',
              helperText: _importing
                  ? '会在动漫库里新建这个名字的文件夹，重名时自动加 (2)'
                  : '修改名称会同时修改文件夹名',
              helperMaxLines: 2,
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _release,
            decoration: const InputDecoration(
              labelText: '导入时间（可不填）',
              hintText: '例如：2026年9月13日',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _synopsis,
            minLines: 4,
            maxLines: 10,
            decoration: const InputDecoration(
              labelText: '简介（可不填）',
              alignLabelWithHint: true,
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          Text('标签', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final t in _tags)
                InputChip(
                  label: Text(t),
                  onDeleted: () => setState(() => _tags.remove(t)),
                ),
            ],
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _tagInput,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              hintText: '输入标签，回车或逗号分隔',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.add),
                onPressed: () => _addTags(_tagInput.text),
              ),
            ),
            onSubmitted: _addTags,
          ),
          if (suggestions.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final t in suggestions)
                  ActionChip(
                    label: Text(t),
                    onPressed: () => setState(() => _tags.add(t)),
                  ),
              ],
            ),
          ],
          const SizedBox(height: 24),
          Row(
            children: [
              Text('剧集（${_eps.length}）', style: theme.textTheme.titleMedium),
              const Spacer(),
              TextButton.icon(
                onPressed: _addVideos,
                icon: const Icon(Icons.add),
                label: const Text('添加视频'),
              ),
            ],
          ),
          const SizedBox(height: 4),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment<bool>(value: false, label: Text('移动')),
              ButtonSegment<bool>(value: true, label: Text('复制')),
            ],
            selected: {_copy},
            showSelectedIcon: false,
            onSelectionChanged: (s) => setState(() => _copy = s.first),
          ),
          const SizedBox(height: 6),
          Text(
            _importing
                ? '保存时会把这些视频$verb进新的番剧文件夹'
                : '添加或更换的视频会$verb进这部番剧的文件夹',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 4),
          for (var i = 0; i < _eps.length; i++)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(_eps[i].source != null
                  ? Icons.note_add_outlined
                  : Icons.movie_outlined),
              title: Text(_eps[i].name,
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: _eps[i].source != null
                  ? Text('待添加 · ${p.dirname(_eps[i].source!)}',
                      maxLines: 1, overflow: TextOverflow.ellipsis)
                  : null,
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: '更换视频',
                    icon: const Icon(Icons.swap_horiz),
                    onPressed: () => _replace(i),
                  ),
                  IconButton(
                    tooltip: '删除',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => _remove(i),
                  ),
                ],
              ),
            ),
          if (_removeCount > 0)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                '保存时将从手机上永久删除 $_removeCount 个视频文件',
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.error),
              ),
            ),
          const SizedBox(height: 24),
          Row(
            children: [
              Text('剧照（${_stills.length}）', style: theme.textTheme.titleMedium),
              const Spacer(),
              TextButton.icon(
                onPressed: _addStills,
                icon: const Icon(Icons.add_photo_alternate_outlined),
                label: const Text('添加图片'),
              ),
            ],
          ),
          if (!_stillsLoaded)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Center(child: CircularProgressIndicator()),
            ),
          for (var i = 0; i < _stills.length; i++)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: SizedBox(
                  width: 56,
                  height: 56,
                  child: Image.file(
                    File(_stills[i].path),
                    fit: BoxFit.cover,
                    cacheWidth: 160,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.broken_image_outlined),
                  ),
                ),
              ),
              title: Text(_stills[i].name,
                  maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: _stills[i].source != null
                  ? Text('待添加 · ${p.dirname(_stills[i].source!)}',
                      maxLines: 1, overflow: TextOverflow.ellipsis)
                  : null,
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: '更换图片',
                    icon: const Icon(Icons.swap_horiz),
                    onPressed: () => _replaceStill(i),
                  ),
                  IconButton(
                    tooltip: '删除',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => _removeStill(i),
                  ),
                ],
              ),
            ),
          if (_stillRemoveCount > 0)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                '保存时将从手机上永久删除 $_stillRemoveCount 张图片',
                style: theme.textTheme.bodySmall
                    ?.copyWith(color: theme.colorScheme.error),
              ),
            ),
        ],
      ),
    );
  }
}
