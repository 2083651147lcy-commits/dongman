import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';
import '../selection.dart';
import '../settings.dart';
import 'collections_page.dart';
import 'history_page.dart';
import 'home_page.dart';
import 'settings_page.dart';

String fmtBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
  if (b < 1024 * 1024 * 1024) {
    return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  }
  return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

class AppShell extends StatefulWidget {
  final LibraryStore store;
  final SettingsStore settings;
  const AppShell({super.key, required this.store, required this.settings});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  final SelectionController _sel = SelectionController();

  @override
  void dispose() {
    _sel.dispose();
    super.dispose();
  }

  Future<void> _deleteSelected() async {
    final list = widget.store.items
        .where((a) => _sel.selected.contains(a.path))
        .toList();
    if (list.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _DeleteDialog(store: widget.store, list: list),
    );
    if (ok != true) return;
    _sel.clear();
    final failed = await widget.store.deleteAnimes(list);
    if (!mounted) return;
    final done = list.length - failed.length;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(failed.isEmpty
          ? '已删除 $done 部番剧'
          : '已删除 $done 部，${failed.length} 部失败：${failed.join('、')}'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _sel,
      builder: (context, _) {
        return PopScope(
          canPop: !_sel.active,
          onPopInvokedWithResult: (didPop, _) {
            if (!didPop) _sel.clear();
          },
          child: Scaffold(
            body: IndexedStack(
              index: _index,
              children: [
                HomePage(
                  store: widget.store,
                  settings: widget.settings,
                  selection: _sel,
                ),
                HistoryPage(store: widget.store, settings: widget.settings),
                const CollectionsPage(),
                SettingsPage(store: widget.store, settings: widget.settings),
              ],
            ),
            bottomNavigationBar: _sel.active
                ? _SelectionBar(onDelete: _deleteSelected, onCancel: _sel.clear)
                : NavigationBar(
                    selectedIndex: _index,
                    onDestinationSelected: (i) => setState(() => _index = i),
                    destinations: const [
                      NavigationDestination(
                        icon: Icon(Icons.home_outlined),
                        selectedIcon: Icon(Icons.home),
                        label: '主页',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.history),
                        selectedIcon: Icon(Icons.history),
                        label: '历史',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.favorite_border),
                        selectedIcon: Icon(Icons.favorite),
                        label: '收藏',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.settings_outlined),
                        selectedIcon: Icon(Icons.settings),
                        label: '设置',
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }
}

class _SelectionBar extends StatelessWidget {
  final VoidCallback onDelete;
  final VoidCallback onCancel;
  const _SelectionBar({required this.onDelete, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      elevation: 3,
      color: cs.surfaceContainer,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: [
              Expanded(
                child: TextButton.icon(
                  onPressed: onDelete,
                  icon: Icon(Icons.delete_outline, color: cs.error),
                  label: Text('删除', style: TextStyle(color: cs.error)),
                ),
              ),
              Expanded(
                child: TextButton.icon(
                  onPressed: onCancel,
                  icon: const Icon(Icons.close),
                  label: const Text('取消'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DeleteDialog extends StatefulWidget {
  final LibraryStore store;
  final List<Anime> list;
  const _DeleteDialog({required this.store, required this.list});

  @override
  State<_DeleteDialog> createState() => _DeleteDialogState();
}

class _DeleteDialogState extends State<_DeleteDialog> {
  late final Future<int> _size = widget.store.totalSize(widget.list);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final names = widget.list.map((a) => '· ${a.name}').toList();
    return AlertDialog(
      title: Text('删除 ${widget.list.length} 部番剧'),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 160),
              child: SingleChildScrollView(child: Text(names.join('\n'))),
            ),
            const SizedBox(height: 12),
            Text(
              '将永久删除这些番剧的所有视频文件和整个文件夹，无法恢复。',
              style: TextStyle(color: cs.error),
            ),
            const SizedBox(height: 8),
            FutureBuilder<int>(
              future: _size,
              builder: (_, snap) => Text(snap.hasData
                  ? '共释放约 ${fmtBytes(snap.data!)}'
                  : '正在计算大小…'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: cs.error),
          onPressed: () => Navigator.pop(context, true),
          child: const Text('删除'),
        ),
      ],
    );
  }
}
