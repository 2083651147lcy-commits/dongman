import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../library.dart';
import '../models.dart';
import '../selection.dart';
import '../settings.dart';
import '../ui/collection_sheet.dart';
import '../ui/delete_flow.dart';
import '../ui/selection_bar.dart';
import 'collections_page.dart';
import 'history_page.dart';
import 'home_page.dart';
import 'settings_page.dart';

class AppShell extends StatefulWidget {
  final LibraryStore store;
  final SettingsStore settings;
  const AppShell({super.key, required this.store, required this.settings});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  final SelectionController _sel = SelectionController();

  @override
  void dispose() {
    _sel.dispose();
    super.dispose();
  }

  List<Anime> _selected() => widget.store.items
      .where((a) => _sel.selected.contains(a.path))
      .toList();

  Future<void> _favoriteSelected() async {
    final list = _selected();
    if (list.isEmpty) return;
    final changed = await showCollectionSheet(context, widget.store, list);
    if (changed == true) {
      _sel.clear();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('已更新收藏夹')));
      }
    }
  }

  Future<void> _deleteSelected() async {
    final list = _selected();
    if (await deleteAnimesFlow(context, widget.store, list)) _sel.clear();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _sel,
      builder: (context, _) {
        return PopScope(
          canPop: !_sel.active,
          onPopInvokedWithResult: (didPop, _) {
            if (!didPop) _sel.clear();
          },
          child: Scaffold(
            body: IndexedStack(
              index: _index,
              children: [
                HomePage(
                  store: widget.store,
                  settings: widget.settings,
                  selection: _sel,
                ),
                HistoryPage(store: widget.store, settings: widget.settings),
                CollectionsPage(store: widget.store, settings: widget.settings),
                SettingsPage(store: widget.store, settings: widget.settings),
              ],
            ),
            bottomNavigationBar: _sel.active
                ? SelectionBar(actions: [
                    SelectionAction(
                      icon: Icons.favorite_border,
                      label: '收藏',
                      onTap: _favoriteSelected,
                    ),
                    SelectionAction(
                      icon: Icons.delete_outline,
                      label: '删除',
                      danger: true,
                      onTap: _deleteSelected,
                    ),
                    SelectionAction(
                      icon: Icons.close,
                      label: '取消',
                      onTap: _sel.clear,
                    ),
                  ])
                : NavigationBar(
                    selectedIndex: _index,
                    onDestinationSelected: (i) {
                      // 轻微的点按震动（比系统长按的震动弱）
                      HapticFeedback.selectionClick();
                      setState(() => _index = i);
                    },
                    destinations: const [
                      NavigationDestination(
                        icon: Icon(Icons.home_outlined),
                        selectedIcon: Icon(Icons.home),
                        label: '主页',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.history),
                        selectedIcon: Icon(Icons.history),
                        label: '历史',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.favorite_border),
                        selectedIcon: Icon(Icons.favorite),
                        label: '收藏',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.settings_outlined),
                        selectedIcon: Icon(Icons.settings),
                        label: '设置',
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }
}
