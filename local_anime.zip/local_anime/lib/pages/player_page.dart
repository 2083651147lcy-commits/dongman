import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';

import '../models.dart';
import '../store.dart';

class PlayerPage extends StatefulWidget {
  final LibraryStore store;
  final Anime anime;
  final int index;
  const PlayerPage({
    super.key,
    required this.store,
    required this.anime,
    required this.index,
  });

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final Player player = Player();
  late final VideoController controller = VideoController(player);
  final List<StreamSubscription> _subs = [];
  late int index;
  bool _switching = true;
  DateTime _lastDisk = DateTime.now();

  Episode get ep => widget.anime.episodes[index];

  @override
  void initState() {
    super.initState();
    index = widget.index;
    _subs.add(player.stream.position.listen(_onPosition));
    _subs.add(player.stream.completed.listen((done) {
      if (done) _onCompleted();
    }));
    _open(index);
  }

  Future<void> _open(int i) async {
    _switching = true;
    if (mounted) setState(() => index = i);
    widget.anime.lastEpisode = i;
    final e = widget.anime.episodes[i];

    if (!await File(e.path).exists()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('视频文件不存在')),
        );
      }
      return;
    }

    final durFuture = player.stream.duration
        .firstWhere((d) => d > Duration.zero)
        .timeout(const Duration(seconds: 8), onTimeout: () => Duration.zero);
    await player.open(Media(e.path), play: false);
    await durFuture;

    final start = e.finished ? 0 : e.positionMs;
    if (start > 3000) {
      await player.seek(Duration(milliseconds: start));
    }
    _switching = false;
    await player.play();
  }

  void _onPosition(Duration pos) {
    if (_switching) return;
    final e = ep;
    e.positionMs = pos.inMilliseconds;
    final d = player.state.duration.inMilliseconds;
    if (d > 0) e.durationMs = d;
    if (DateTime.now().difference(_lastDisk).inSeconds >= 10) {
      _lastDisk = DateTime.now();
      widget.store.save();
    }
  }

  void _onCompleted() {
    if (_switching) return;
    final e = ep;
    if (e.durationMs > 0) e.positionMs = e.durationMs;
    if (index + 1 < widget.anime.episodes.length) {
      _open(index + 1);
    } else {
      widget.store.save();
    }
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    widget.store.save();
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final eps = widget.anime.episodes;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '${widget.anime.title} · ${ep.title}',
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Column(
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Video(controller: controller),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: eps.length,
              itemBuilder: (_, i) {
                final selected = i == index;
                return ListTile(
                  selected: selected,
                  selectedTileColor: cs.primaryContainer.withOpacity(0.4),
                  leading: Icon(
                    selected ? Icons.play_arrow : Icons.movie_outlined,
                  ),
                  title: Text(eps[i].title,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: selected ? null : () => _open(i),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
