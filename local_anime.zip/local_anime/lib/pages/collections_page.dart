import 'package:flutter/material.dart';

/// 收藏夹：下一版加入
class CollectionsPage extends StatelessWidget {
  const CollectionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('收藏')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.favorite_border, size: 56, color: cs.outline),
              const SizedBox(height: 16),
              const Text('收藏夹功能下一版加入', textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
