import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';
import '../settings.dart';
import '../ui/anime_card.dart';
import '../ui/card_grid.dart';
import '../ui/collection_sheet.dart';
import 'collection_detail_page.dart';
import 'edit_collection_page.dart';

class CollectionsPage extends StatelessWidget {
  final LibraryStore store;
  final SettingsStore settings;
  const CollectionsPage({super.key, required this.store, required this.settings});

  void _open(BuildContext context, Collection c) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CollectionDetailPage(
            store: store, settings: settings, collectionId: c.id),
      ),
    );
  }

  Future<void> _menu(BuildContext context, Collection c) async {
    final v = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('编辑'),
              onTap: () => Navigator.pop(ctx, 'edit'),
            ),
            ListTile(
              leading: Icon(Icons.delete_outline,
                  color: Theme.of(ctx).colorScheme.error),
              title: Text('删除',
                  style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
          ],
        ),
      ),
    );
    if (v == null || !context.mounted) return;
    if (v == 'edit') {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => EditCollectionPage(store: store, collectionId: c.id),
        ),
      );
    } else if (v == 'delete') {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('删除收藏夹'),
          content: Text('删除收藏夹「${c.name}」？只删除收藏夹本身，里面的番剧和视频不受影响。'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('删除')),
          ],
        ),
      );
      if (ok == true) await store.deleteCollection(c);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([store, settings]),
      builder: (context, _) {
        final cols = store.collections;
        return Scaffold(
          appBar: AppBar(
            title: const Text('收藏'),
            actions: [
              IconButton(
                icon: const Icon(Icons.add),
                tooltip: '新建收藏夹',
                onPressed: () => showCreateCollectionDialog(context, store),
              ),
            ],
          ),
          body: cols.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      '还没有收藏夹。\n点右上角“+”新建，或在主页长按番剧后点“收藏”。',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : CardGrid(
                  settings: settings,
                  itemCount: cols.length,
                  itemBuilder: (ctx, i) {
                    final c = cols[i];
                    return AnimeCard(
                      title: c.name,
                      subtitle: '${store.countOf(c)} 部番剧',
                      coverPath: store.coverOf(c),
                      settings: settings,
                      onTap: () => _open(context, c),
                      onLongPress: () => _menu(context, c),
                    );
                  },
                ),
        );
      },
    );
  }
}
