import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../library.dart';
import '../selection.dart';
import '../models.dart';
import '../settings.dart';
import '../sorting.dart';
import '../ui/anime_card.dart';
import '../ui/card_grid.dart';
import 'detail_page.dart';

/// 选择动漫库文件夹（含权限申请），多个页面共用
Future<void> pickLibraryFolder(
  BuildContext context,
  LibraryStore store,
) async {
  final ok = await store.ensurePermission(request: true);
  if (!context.mounted) return;
  if (!ok) {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('需要文件访问权限'),
        content: const Text(
            '请在系统设置里给本应用打开“所有文件访问权限”（Android 11 及以上），然后回来再选一次文件夹。'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('知道了')),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              openAppSettings();
            },
            child: const Text('去设置'),
          ),
        ],
      ),
    );
    return;
  }
  final path = await FilePicker.platform.getDirectoryPath();
  if (path == null) return;
  await store.changeRoot(path);
}

class HomePage extends StatefulWidget {
  final LibraryStore store;
  final SettingsStore settings;
  final SelectionController selection;
  const HomePage({
    super.key,
    required this.store,
    required this.settings,
    required this.selection,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _searchCtl = TextEditingController();
  bool _searching = false;
  String _query = '';
  String? _tag;

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  List<Anime> _filtered() {
    final q = _query.trim().toLowerCase();
    final list = widget.store.items.where((a) {
      if (_tag != null && !a.tags.contains(_tag)) return false;
      if (q.isEmpty) return true;
      return a.name.toLowerCase().contains(q) ||
          a.synopsis.toLowerCase().contains(q) ||
          a.tags.any((t) => t.toLowerCase().contains(q));
    }).toList();
    final mode = widget.settings.sortMode;
    if (mode == 3) {
      return _random.pick(list, '$_tag|${_query.trim().toLowerCase()}');
    }
    sortAnimes(list, mode, widget.settings.sortReverse);
    return list;
  }

  final _random = RandomPicker();

  void _pickSort(int v) {
    final s = widget.settings;
    if (v == s.sortMode) {
      if (v == 3) {
        setState(() => _random.dirty = true);
      } else {
        s.update(() => s.sortReverse = !s.sortReverse);
      }
      return;
    }
    _random.dirty = true;
    s.update(() {
      s.sortMode = v;
      s.sortReverse = false;
    });
    if (v == 2) widget.store.loadAllDurations();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge(
          [widget.store, widget.settings, widget.selection]),
      builder: (context, _) {
        final store = widget.store;
        final s = widget.settings;
        final sel = widget.selection;
        final tags = store.allTags;
        if (_tag != null && !tags.contains(_tag)) _tag = null;
        final items = _filtered();

        final PreferredSizeWidget appBar = sel.active
            ? AppBar(
                leading: IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: sel.clear,
                ),
                title: Text('已选 ${sel.selected.length} 项'),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.select_all),
                    tooltip: '全选',
                    onPressed: () => sel.addAll(items.map((a) => a.path)),
                  ),
                ],
              )
            : AppBar(
                title: _searching
                    ? TextField(
                        controller: _searchCtl,
                        autofocus: true,
                        decoration: const InputDecoration(
                          hintText: '搜索名称、简介、标签',
                          border: InputBorder.none,
                        ),
                        onChanged: (v) => setState(() => _query = v),
                      )
                    : const Text('本地番剧库'),
                actions: [
                  IconButton(
                    icon: Icon(_searching ? Icons.close : Icons.search),
                    onPressed: () => setState(() {
                      _searching = !_searching;
                      if (!_searching) {
                        _query = '';
                        _searchCtl.clear();
                      }
                    }),
                  ),
                  PopupMenuButton<int>(
                    icon: const Icon(Icons.sort),
                    tooltip: '排序',
                    onSelected: _pickSort,
                    itemBuilder: (_) => [
                      for (final m in sortMenuOrder)
                        CheckedPopupMenuItem(
                          value: m,
                          checked: s.sortMode == m,
                          child: Text(sortLabel(m, s.sortMode, s.sortReverse)),
                        ),
                    ],
                  ),
                ],
              );

        return Scaffold(
          appBar: appBar,
          body: _body(context, store, s, sel, tags, items),
        );
      },
    );
  }

  Widget _body(
    BuildContext context,
    LibraryStore store,
    SettingsStore s,
    SelectionController sel,
    List<String> tags,
    List<Anime> items,
  ) {
    if (s.rootPath == null) {
      return _Message(
        icon: Icons.folder_open,
        text:
            '先选择存放动漫的根文件夹。\n\n里面每个子文件夹就是一部番剧，子文件夹里放视频，封面会自动截取视频画面。',
        button: '选择文件夹',
        onPressed: () => pickLibraryFolder(context, store),
      );
    }
    if (store.needPermission) {
      return _Message(
        icon: Icons.lock_outline,
        text: '需要“所有文件访问权限”才能读取你的动漫文件夹。',
        button: '授予权限',
        onPressed: () => store.refresh(requestPermission: true),
      );
    }
    if (store.error != null) {
      return _Message(
        icon: Icons.error_outline,
        text: store.error!,
        button: '重试',
        onPressed: () => store.refresh(),
      );
    }

    return Column(
      children: [
        if (store.scanning) const LinearProgressIndicator(minHeight: 2),
        if (tags.isNotEmpty)
          SizedBox(
            height: 52,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: tags.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final t = tags[i];
                return FilterChip(
                  label: Text(t),
                  selected: _tag == t,
                  onSelected: (v) => setState(() => _tag = v ? t : null),
                );
              },
            ),
          ),
        if (s.sortMode == 2 && store.durationsLoading)
          const LinearProgressIndicator(minHeight: 2),
        Expanded(
          child: RefreshIndicator(
            onRefresh: s.sortMode == 3
                ? () async {
                    // 随机模式下，下拉不是重新扫描，而是换一批
                    setState(() => _random.dirty = true);
                    await Future.delayed(const Duration(milliseconds: 300));
                  }
                : () => store.refresh(),
            child: items.isEmpty
                ? ListView(
                    children: [
                      const SizedBox(height: 120),
                      Center(
                        child: Text(store.items.isEmpty
                            ? (store.scanning
                                ? '正在扫描…'
                                : '没有找到番剧文件夹（下拉可重新扫描）')
                            : '没有匹配的结果'),
                      ),
                    ],
                  )
                : CardGrid(
                    settings: s,
                    itemCount: items.length,
                    itemBuilder: (ctx, i) => _card(items[i], s, sel),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _card(Anime a, SettingsStore s, SelectionController sel) {
    return AnimeCard(
      title: a.name,
      epCount: a.episodes.length,
      picCount: a.episodes.isEmpty ? a.stillCount : 0,
      totalMs: a.totalMs,
      tags: a.tags,
      coverPath: a.coverPath,
      settings: s,
      selectionMode: sel.active,
      selected: sel.isSelected(a.path),
      onTap: () => sel.active
          ? sel.toggle(a.path)
          : openAnimeDetail(context, widget.store, widget.settings, a),
      onLongPress: () => sel.toggle(a.path),
    );
  }
}

class _Message extends StatelessWidget {
  final IconData icon;
  final String text;
  final String button;
  final VoidCallback onPressed;
  const _Message({
    required this.icon,
    required this.text,
    required this.button,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 16),
            Text(text, textAlign: TextAlign.center),
            const SizedBox(height: 20),
            FilledButton(onPressed: onPressed, child: Text(button)),
          ],
        ),
      ),
    );
  }
}
