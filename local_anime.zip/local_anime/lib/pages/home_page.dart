import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../episode_parser.dart';
import '../library.dart';
import '../models.dart';
import '../settings.dart';
import '../ui/anime_card.dart';
import 'detail_page.dart';
import 'settings_page.dart';

/// 选择动漫库文件夹（含权限申请），多个页面共用
Future<void> pickLibraryFolder(
  BuildContext context,
  LibraryStore store,
) async {
  final ok = await store.ensurePermission(request: true);
  if (!context.mounted) return;
  if (!ok) {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('需要文件访问权限'),
        content: const Text(
            '请在系统设置里给本应用打开“所有文件访问权限”（Android 11 及以上），然后回来再选一次文件夹。'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('知道了')),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              openAppSettings();
            },
            child: const Text('去设置'),
          ),
        ],
      ),
    );
    return;
  }
  final path = await FilePicker.platform.getDirectoryPath();
  if (path == null) return;
  await store.changeRoot(path);
}

class HomePage extends StatefulWidget {
  final LibraryStore store;
  final SettingsStore settings;
  const HomePage({super.key, required this.store, required this.settings});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _searchCtl = TextEditingController();
  bool _searching = false;
  String _query = '';
  String? _tag;

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  List<Anime> _filtered() {
    final q = _query.trim().toLowerCase();
    final list = widget.store.visible.where((a) {
      if (_tag != null && !a.tags.contains(_tag)) return false;
      if (q.isEmpty) return true;
      return a.name.toLowerCase().contains(q) ||
          a.synopsis.toLowerCase().contains(q) ||
          a.tags.any((t) => t.toLowerCase().contains(q));
    }).toList();
    if (widget.settings.sortMode == 1) {
      list.sort((a, b) {
        final c = b.lastOpenedAt.compareTo(a.lastOpenedAt);
        return c != 0 ? c : naturalCompare(a.name, b.name);
      });
    } else {
      list.sort((a, b) => naturalCompare(a.name, b.name));
    }
    return list;
  }

  void _open(Anime a) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DetailPage(
          store: widget.store,
          settings: widget.settings,
          animePath: a.path,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([widget.store, widget.settings]),
      builder: (context, _) {
        final store = widget.store;
        final s = widget.settings;
        final tags = store.allTags;
        if (_tag != null && !tags.contains(_tag)) _tag = null;

        return Scaffold(
          appBar: AppBar(
            title: _searching
                ? TextField(
                    controller: _searchCtl,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: '搜索名称、简介、标签',
                      border: InputBorder.none,
                    ),
                    onChanged: (v) => setState(() => _query = v),
                  )
                : const Text('本地番剧库'),
            actions: [
              IconButton(
                icon: Icon(_searching ? Icons.close : Icons.search),
                onPressed: () => setState(() {
                  _searching = !_searching;
                  if (!_searching) {
                    _query = '';
                    _searchCtl.clear();
                  }
                }),
              ),
              PopupMenuButton<int>(
                icon: const Icon(Icons.sort),
                tooltip: '排序',
                onSelected: (v) => s.update(() => s.sortMode = v),
                itemBuilder: (_) => [
                  CheckedPopupMenuItem(
                      value: 0, checked: s.sortMode == 0, child: const Text('按名称')),
                  CheckedPopupMenuItem(
                      value: 1,
                      checked: s.sortMode == 1,
                      child: const Text('按最近观看')),
                ],
              ),
              IconButton(
                icon: const Icon(Icons.settings_outlined),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        SettingsPage(store: store, settings: s),
                  ),
                ),
              ),
            ],
          ),
          body: _body(context, store, s, tags),
        );
      },
    );
  }

  Widget _body(
    BuildContext context,
    LibraryStore store,
    SettingsStore s,
    List<String> tags,
  ) {
    if (s.rootPath == null) {
      return _Message(
        icon: Icons.folder_open,
        text: '先选择存放动漫的根文件夹。\n\n里面每个子文件夹就是一部番剧，子文件夹里放视频，再放一张图片当封面（没有图片会自动截取视频画面）。',
        button: '选择文件夹',
        onPressed: () => pickLibraryFolder(context, store),
      );
    }
    if (store.needPermission) {
      return _Message(
        icon: Icons.lock_outline,
        text: '需要“所有文件访问权限”才能读取你的动漫文件夹。',
        button: '授予权限',
        onPressed: () => store.refresh(requestPermission: true),
      );
    }
    if (store.error != null) {
      return _Message(
        icon: Icons.error_outline,
        text: store.error!,
        button: '重试',
        onPressed: () => store.refresh(),
      );
    }

    final items = _filtered();
    final landscape =
        MediaQuery.of(context).orientation == Orientation.landscape;
    final cols = landscape ? s.landscapeCols : s.portraitCols;
    final gap = s.gap;

    final recent = store.visible.where((a) => a.lastOpenedAt > 0).toList()
      ..sort((a, b) => b.lastOpenedAt.compareTo(a.lastOpenedAt));
    final showContinue = _query.isEmpty && _tag == null && recent.isNotEmpty;
    final offset = showContinue ? 1 : 0;
    final rowCount = (items.length / cols).ceil();

    return Column(
      children: [
        if (store.scanning) const LinearProgressIndicator(minHeight: 2),
        if (tags.isNotEmpty)
          SizedBox(
            height: 52,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: tags.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final t = tags[i];
                return FilterChip(
                  label: Text(t),
                  selected: _tag == t,
                  onSelected: (v) => setState(() => _tag = v ? t : null),
                );
              },
            ),
          ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: () => store.refresh(),
            child: items.isEmpty
                ? ListView(
                    children: [
                      const SizedBox(height: 120),
                      Center(
                        child: Text(store.visible.isEmpty
                            ? (store.scanning ? '正在扫描…' : '没有找到番剧文件夹（下拉可重新扫描）')
                            : '没有匹配的结果'),
                      ),
                    ],
                  )
                : ListView.builder(
                    padding: EdgeInsets.only(
                        top: 8, bottom: 24 + MediaQuery.of(context).padding.bottom),
                    itemCount: offset + rowCount,
                    itemBuilder: (context, i) {
                      if (showContinue && i == 0) {
                        return _ContinueStrip(
                          list: recent.take(8).toList(),
                          settings: s,
                          onTap: _open,
                        );
                      }
                      final r = i - offset;
                      final children = <Widget>[];
                      for (var c = 0; c < cols; c++) {
                        final idx = r * cols + c;
                        if (c > 0) children.add(SizedBox(width: gap));
                        children.add(Expanded(
                          child: idx < items.length
                              ? AnimeCard(
                                  title: items[idx].name,
                                  epCount: items[idx].episodes.length,
                                  watched: items[idx].watchedCount,
                                  tags: items[idx].tags,
                                  coverPath: items[idx].coverPath,
                                  settings: s,
                                  onTap: () => _open(items[idx]),
                                )
                              : const SizedBox(),
                        ));
                      }
                      return Padding(
                        padding: EdgeInsets.fromLTRB(12, 0, 12, gap + 4),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: children,
                        ),
                      );
                    },
                  ),
          ),
        ),
      ],
    );
  }
}

class _ContinueStrip extends StatelessWidget {
  final List<Anime> list;
  final SettingsStore settings;
  final void Function(Anime) onTap;
  const _ContinueStrip({
    required this.list,
    required this.settings,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    const w = 100.0;
    final ts = MediaQuery.textScalerOf(context);
    final h = w / settings.ratio + ts.scale(12) * 1.4 + ts.scale(12) * 1.4 + 20;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
          child: Text('继续观看', style: Theme.of(context).textTheme.titleMedium),
        ),
        SizedBox(
          height: h,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) {
              final a = list[i];
              return SizedBox(
                width: w,
                child: AnimeCard(
                  title: a.name,
                  subtitle: a.nextToWatch?.title,
                  coverPath: a.coverPath,
                  settings: settings,
                  compact: true,
                  onTap: () => onTap(a),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }
}

class _Message extends StatelessWidget {
  final IconData icon;
  final String text;
  final String button;
  final VoidCallback onPressed;
  const _Message({
    required this.icon,
    required this.text,
    required this.button,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 16),
            Text(text, textAlign: TextAlign.center),
            const SizedBox(height: 20),
            FilledButton(onPressed: onPressed, child: Text(button)),
          ],
        ),
      ),
    );
  }
}
