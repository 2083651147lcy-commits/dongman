import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets.dart';
import 'detail_page.dart';
import 'edit_page.dart';

class HomePage extends StatefulWidget {
  final LibraryStore store;
  const HomePage({super.key, required this.store});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _searchCtl = TextEditingController();
  bool _searching = false;
  String _query = '';
  String? _tag;

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  List<Anime> _filtered() {
    final q = _query.trim().toLowerCase();
    final list = widget.store.items.where((a) {
      if (_tag != null && !a.tags.contains(_tag)) return false;
      if (q.isEmpty) return true;
      return a.title.toLowerCase().contains(q) ||
          a.synopsis.toLowerCase().contains(q) ||
          a.tags.any((t) => t.toLowerCase().contains(q));
    }).toList();
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.store,
      builder: (context, _) {
        final store = widget.store;
        final items = _filtered();
        final tags = store.allTags;
        if (_tag != null && !tags.contains(_tag)) _tag = null;

        return Scaffold(
          appBar: AppBar(
            title: _searching
                ? TextField(
                    controller: _searchCtl,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: '搜索名称、简介、标签',
                      border: InputBorder.none,
                    ),
                    onChanged: (v) => setState(() => _query = v),
                  )
                : const Text('本地番剧库'),
            actions: [
              IconButton(
                icon: Icon(_searching ? Icons.close : Icons.search),
                onPressed: () => setState(() {
                  _searching = !_searching;
                  if (!_searching) {
                    _query = '';
                    _searchCtl.clear();
                  }
                }),
              ),
            ],
          ),
          body: Column(
            children: [
              if (tags.isNotEmpty)
                SizedBox(
                  height: 52,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    itemCount: tags.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) {
                      final t = tags[i];
                      return FilterChip(
                        label: Text(t),
                        selected: _tag == t,
                        onSelected: (s) =>
                            setState(() => _tag = s ? t : null),
                      );
                    },
                  ),
                ),
              Expanded(
                child: items.isEmpty
                    ? Center(
                        child: Text(store.items.isEmpty
                            ? '还没有番剧，点右下角添加'
                            : '没有匹配的结果'),
                      )
                    : GridView.builder(
                        padding: const EdgeInsets.all(12),
                        gridDelegate:
                            const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 180,
                          childAspectRatio: 0.58,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                        ),
                        itemCount: items.length,
                        itemBuilder: (_, i) => _AnimeCard(
                          anime: items[i],
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DetailPage(
                                store: store,
                                animeId: items[i].id,
                              ),
                            ),
                          ),
                        ),
                      ),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => EditPage(store: store)),
            ),
            icon: const Icon(Icons.add),
            label: const Text('添加番剧'),
          ),
        );
      },
    );
  }
}

class _AnimeCard extends StatelessWidget {
  final Anime anime;
  final VoidCallback onTap;
  const _AnimeCard({required this.anime, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: SizedBox(
                width: double.infinity,
                child: CoverImage(path: anime.coverPath),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    anime.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${anime.episodes.length} 集',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
