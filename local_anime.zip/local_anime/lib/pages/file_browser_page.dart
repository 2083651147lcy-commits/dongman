import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../episode_parser.dart';
import '../library.dart' show LibraryStore;

/// 内置的视频选择器：直接读真实路径，选中的视频不会先被复制一份。
/// 返回选中的视频路径列表（单选模式下只有一个）。
class FileBrowserPage extends StatefulWidget {
  final String title;
  final bool single;
  const FileBrowserPage({super.key, required this.title, this.single = false});

  @override
  State<FileBrowserPage> createState() => _FileBrowserPageState();
}

class _Root {
  final String label;
  final String path;
  const _Root(this.label, this.path);
}

class _Entry {
  final String path;
  final bool isDir;
  final int size;
  const _Entry(this.path, this.isDir, this.size);
  String get name => p.basename(path);
}

String _fmtSize(int b) {
  if (b >= 1 << 30) return '${(b / (1 << 30)).toStringAsFixed(2)} GB';
  if (b >= 1 << 20) return '${(b / (1 << 20)).toStringAsFixed(1)} MB';
  return '${(b / 1024).toStringAsFixed(0)} KB';
}

class _FileBrowserPageState extends State<FileBrowserPage> {
  static String? _lastDir; // 本次运行内记住上次浏览的位置

  List<_Root> _roots = [];
  String? _cur; // null = 存储位置列表
  List<_Entry> _entries = [];
  final Set<String> _picked = {};
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final roots = <_Root>[];
    const internal = '/storage/emulated/0';
    if (Directory(internal).existsSync()) {
      roots.add(const _Root('内部存储', internal));
    }
    try {
      await for (final e in Directory('/storage').list(followLinks: false)) {
        final n = p.basename(e.path);
        if (e is Directory && n != 'emulated' && n != 'self') {
          roots.add(_Root('存储卡 $n', e.path));
        }
      }
    } catch (_) {}
    _roots = roots;
    final last = _lastDir;
    if (last != null && Directory(last).existsSync()) {
      await _open(last);
    } else if (roots.isNotEmpty) {
      await _open(roots.first.path);
    } else if (mounted) {
      setState(() {
        _loading = false;
        _error = '找不到存储位置';
      });
    }
  }

  Future<void> _open(String path) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final dirs = <_Entry>[];
    final files = <_Entry>[];
    String? err;
    try {
      await for (final e in Directory(path).list(followLinks: false)) {
        final n = p.basename(e.path);
        if (n.startsWith('.')) continue;
        if (e is Directory) {
          dirs.add(_Entry(e.path, true, 0));
        } else if (e is File && LibraryStore.isVideoFile(e.path)) {
          var size = 0;
          try {
            size = e.lengthSync();
          } catch (_) {}
          files.add(_Entry(e.path, false, size));
        }
      }
      dirs.sort((a, b) => naturalCompare(a.name, b.name));
      files.sort((a, b) => naturalCompare(a.name, b.name));
    } catch (e) {
      err = '无法读取这个文件夹：$e';
    }
    if (!mounted) return;
    setState(() {
      _cur = path;
      _lastDir = path;
      _entries = [...dirs, ...files];
      _error = err;
      _loading = false;
    });
  }

  /// 返回上一级；在存储根目录时回到存储位置列表；在列表里则退出
  void _up() {
    final cur = _cur;
    if (cur == null) {
      Navigator.pop(context);
      return;
    }
    if (_roots.any((r) => p.equals(r.path, cur))) {
      setState(() {
        _cur = null;
        _entries = [];
        _error = null;
      });
      return;
    }
    _open(p.dirname(cur));
  }

  void _toggleAllHere() {
    final here = _entries.where((e) => !e.isDir).map((e) => e.path).toList();
    setState(() {
      if (here.every(_picked.contains)) {
        _picked.removeAll(here);
      } else {
        _picked.addAll(here);
      }
    });
  }

  Widget _list() {
    if (_cur == null) {
      return ListView(
        children: [
          for (final r in _roots)
            ListTile(
              leading: const Icon(Icons.sd_storage_outlined),
              title: Text(r.label),
              subtitle: Text(r.path),
              onTap: () => _open(r.path),
            ),
        ],
      );
    }
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(_error!, textAlign: TextAlign.center),
        ),
      );
    }
    if (_entries.isEmpty) {
      return const Center(child: Text('这里没有文件夹或视频'));
    }
    return ListView.builder(
      itemCount: _entries.length,
      itemBuilder: (context, i) {
        final e = _entries[i];
        if (e.isDir) {
          return ListTile(
            leading: const Icon(Icons.folder_outlined),
            title: Text(e.name, maxLines: 2, overflow: TextOverflow.ellipsis),
            onTap: () => _open(e.path),
          );
        }
        final title =
            Text(e.name, maxLines: 2, overflow: TextOverflow.ellipsis);
        final sub = Text(_fmtSize(e.size));
        if (widget.single) {
          return ListTile(
            leading: const Icon(Icons.movie_outlined),
            title: title,
            subtitle: sub,
            onTap: () => Navigator.pop(context, [e.path]),
          );
        }
        return CheckboxListTile(
          value: _picked.contains(e.path),
          controlAffinity: ListTileControlAffinity.leading,
          secondary: const Icon(Icons.movie_outlined),
          title: title,
          subtitle: sub,
          onChanged: (v) => setState(() {
            if (v == true) {
              _picked.add(e.path);
            } else {
              _picked.remove(e.path);
            }
          }),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasVideosHere = _cur != null && _entries.any((e) => !e.isDir);
    return PopScope(
      canPop: _cur == null,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _up();
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: _up,
          ),
          title: Text(widget.title),
          actions: [
            if (!widget.single && hasVideosHere)
              TextButton(onPressed: _toggleAllHere, child: const Text('全选本页')),
          ],
        ),
        body: Column(
          children: [
            if (_cur != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    _cur!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ),
            Expanded(child: _list()),
          ],
        ),
        bottomNavigationBar: widget.single
            ? null
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  child: FilledButton(
                    onPressed: _picked.isEmpty
                        ? null
                        : () => Navigator.pop(context, _picked.toList()),
                    child: Text('确定（已选 ${_picked.length} 个）'),
                  ),
                ),
              ),
      ),
    );
  }
}
