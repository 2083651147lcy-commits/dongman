import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../library.dart';
import '../models.dart';
import '../settings.dart';
import '../ui/anime_card.dart' show fmtDuration;
import '../ui/delete_flow.dart' show fmtBytes;
import 'detail_page.dart';

/// 查找相似视频。
///
/// 相似度得分（0~100）：
///  · 大小相同，并且文件头/中间/结尾的指纹也相同 → 100（完全一致）
///  · 否则 = 时长 50 分 + 名称 40 分 + 大小 10 分（最高 99）
///    - 时长：相差 ≤1 秒得满分，之后线性下降，相差超过较长那个的 2% 得 0
///    - 名称：去掉扩展名、分辨率/编码标记、括号内容、标点后比较；
///            编号（如 ABC-123）相同得满分，否则按字符相似度
///    - 大小：较小/较大 的比值（转码后大小会变，所以只占 10 分）
///  · 有一边读不到时长：名称 80 分 + 大小 20 分（最高 99）
/// 扫描时把所有得分 ≥ 50 的视频对都算出来，之后拖动阈值只是过滤，不用重新扫描。
class SimilarVideosPage extends StatefulWidget {
  final LibraryStore store;
  final SettingsStore settings;
  const SimilarVideosPage({super.key, required this.store, required this.settings});

  @override
  State<SimilarVideosPage> createState() => _SimilarVideosPageState();
}

class _Vid {
  final Anime anime;
  final Episode ep;
  int size = 0;
  int ms = 0;
  String norm = '';
  String? code;
  Set<int> bigrams = {};
  _Vid(this.anime, this.ep);
  String get path => ep.path;
}

class _Edge {
  final int a, b, score;
  const _Edge(this.a, this.b, this.score);
}

class _Group {
  final List<int> members;
  final int maxScore;
  final int keep; // 默认保留的那个
  _Group(this.members, this.maxScore, this.keep);
}

class _SimilarVideosPageState extends State<SimilarVideosPage> {
  static const _minScore = 50;
  static const _chunk = 256 * 1024;

  int _threshold = 90;
  bool _scanning = false;
  bool _scanned = false;
  String _progress = '';
  List<_Vid> _vids = [];
  List<_Edge> _edges = [];
  final Set<int> _dead = {}; // 已经删掉的
  final Map<int, bool> _override = {}; // 用户手动勾选/取消勾选的
  bool _deleting = false;

  // ---------- 文案 ----------
  String _level(int t) {
    if (t >= 100) return '完全一致（Exact Match）';
    if (t >= 90) return '高度相似（High Similarity）';
    if (t >= 70) return '部分相似';
    return '模糊匹配';
  }

  // ---------- 名称处理 ----------
  static final _noise = RegExp(
      r'(\d{3,4}p|4k|2k|hd|fhd|uhd|x26[45]|h26[45]|hevc|avc|aac|web-?dl|blu-?ray|bdrip|hdrip)',
      caseSensitive: false);
  static final _brackets = RegExp(r'\[[^\]]*\]|\([^)]*\)|【[^】]*】|（[^）]*）');
  static final _codeRe = RegExp(r'([a-z]{2,6})[-_ ]?(\d{2,5})');
  static final _keep = RegExp(r'[^\p{L}\p{N}]', unicode: true);

  String _normalize(String base) {
    var s = base.toLowerCase();
    s = s.replaceAll(_brackets, ' ').replaceAll(_noise, ' ');
    return s.replaceAll(_keep, '');
  }

  String? _extractCode(String base) {
    final m = _codeRe.firstMatch(base.toLowerCase());
    return m == null ? null : '${m.group(1)}${m.group(2)}';
  }

  Set<int> _bigramsOf(String s) {
    final r = <int>{};
    final u = s.runes.toList();
    for (var i = 0; i + 1 < u.length; i++) {
      r.add(u[i] * 0x110000 + u[i + 1]);
    }
    return r;
  }

  double _dice(_Vid x, _Vid y) {
    if (x.norm.isEmpty || y.norm.isEmpty) return 0;
    if (x.norm == y.norm) return 1;
    final a = x.bigrams, b = y.bigrams;
    if (a.isEmpty || b.isEmpty) return 0;
    final small = a.length <= b.length ? a : b;
    final big = identical(small, a) ? b : a;
    var inter = 0;
    for (final g in small) {
      if (big.contains(g)) inter++;
    }
    return 2 * inter / (a.length + b.length);
  }

  double _nameSim(_Vid x, _Vid y) {
    final d = _dice(x, y);
    if (x.code != null && y.code != null) {
      return x.code == y.code ? 1.0 : (d < 0.3 ? d : 0.3);
    }
    return d;
  }

  double _durSim(_Vid x, _Vid y) {
    final longer = x.ms > y.ms ? x.ms : y.ms;
    final diff = (x.ms - y.ms).abs();
    if (diff <= 1000) return 1;
    final tol = longer * 0.02;
    if (tol <= 0) return 0;
    final v = 1 - (diff - 1000) / tol;
    return v < 0 ? 0 : v;
  }

  double _sizeSim(_Vid x, _Vid y) {
    if (x.size <= 0 || y.size <= 0) return 0;
    return x.size < y.size ? x.size / y.size : y.size / x.size;
  }

  // ---------- 指纹 ----------
  final Map<String, String> _fp = {};

  Future<String> _fingerprint(_Vid v) async {
    final cached = _fp[v.path];
    if (cached != null) return cached;
    var h1 = 0x811c9dc5;
    var h2 = 5381;
    try {
      final raf = await File(v.path).open();
      try {
        final whole = v.size <= _chunk * 3;
        final offsets = whole ? [0] : [0, (v.size - _chunk) ~/ 2, v.size - _chunk];
        for (final off in offsets) {
          await raf.setPosition(off);
          final buf = await raf.read(whole ? v.size : _chunk);
          for (final b in buf) {
            h1 = ((h1 ^ b) * 0x01000193) & 0xFFFFFFFF;
            h2 = ((h2 * 33) + b) & 0xFFFFFFFF;
          }
        }
      } finally {
        await raf.close();
      }
    } catch (_) {
      return _fp[v.path] = 'err:${v.path}'; // 读不了的当作不相同
    }
    return _fp[v.path] = '${v.size}:$h1:$h2';
  }

  // ---------- 扫描 ----------
  Future<void> _scan() async {
    setState(() {
      _scanning = true;
      _scanned = false;
      _progress = '准备中…';
      _edges = [];
      _dead.clear();
      _override.clear();
      _fp.clear();
    });
    final store = widget.store;
    final vids = <_Vid>[];
    for (final a in store.items) {
      for (final e in a.episodes) {
        vids.add(_Vid(a, e));
      }
    }

    // 1. 时长（只读还没有记录的，读过的会缓存）
    final animes = store.items.where((a) => a.episodes.isNotEmpty).toList();
    for (var i = 0; i < animes.length; i++) {
      if (!mounted) return;
      setState(() => _progress = '读取时长 ${i + 1}/${animes.length}');
      await store.loadDurations(animes[i]);
    }
    for (final v in vids) {
      v.ms = v.anime.durations[v.anime.relOf(v.ep)] ?? 0;
    }

    // 2. 大小、名称
    for (var i = 0; i < vids.length; i++) {
      final v = vids[i];
      if (i % 50 == 0) {
        if (!mounted) return;
        setState(() => _progress = '读取文件信息 $i/${vids.length}');
        await Future<void>.delayed(Duration.zero);
      }
      try {
        v.size = await File(v.path).length();
      } catch (_) {}
      final base = p.basenameWithoutExtension(v.ep.name);
      v.norm = _normalize(base);
      v.code = _extractCode(base);
      v.bigrams = _bigramsOf(v.norm);
    }

    // 3. 候选对：时长相近 / 编号相同 / 名称相同
    final n = vids.length;
    final cand = <int>{};
    void addPair(int x, int y) {
      if (x == y) return;
      cand.add(x < y ? x * n + y : y * n + x);
    }

    final byDur = [
      for (var i = 0; i < n; i++)
        if (vids[i].ms > 0) i
    ]..sort((x, y) => vids[x].ms.compareTo(vids[y].ms));
    for (var i = 0; i < byDur.length; i++) {
      final a = vids[byDur[i]];
      for (var j = i + 1; j < byDur.length; j++) {
        final b = vids[byDur[j]];
        if (b.ms - a.ms > 1000 + b.ms * 0.02) break;
        addPair(byDur[i], byDur[j]);
      }
    }
    void bucket(String? Function(_Vid) keyOf) {
      final m = <String, List<int>>{};
      for (var i = 0; i < n; i++) {
        final k = keyOf(vids[i]);
        if (k == null || k.isEmpty) continue;
        (m[k] ??= []).add(i);
      }
      for (final l in m.values) {
        if (l.length > 200) continue; // 太大的桶多半是通用名字，跳过
        for (var i = 0; i < l.length; i++) {
          for (var j = i + 1; j < l.length; j++) {
            addPair(l[i], l[j]);
          }
        }
      }
    }

    bucket((v) => v.code);
    bucket((v) => v.norm.length >= 4 ? v.norm : null);

    // 4. 打分
    final edges = <_Edge>[];
    var done = 0;
    for (final key in cand) {
      final x = key ~/ n, y = key % n;
      if (++done % 2000 == 0) {
        if (!mounted) return;
        setState(() => _progress = '比较 $done/${cand.length}');
        await Future<void>.delayed(Duration.zero);
      }
      final a = vids[x], b = vids[y];
      int score;
      if (a.size > 0 && a.size == b.size &&
          await _fingerprint(a) == await _fingerprint(b)) {
        score = 100;
      } else {
        final name = _nameSim(a, b);
        final size = _sizeSim(a, b);
        double raw;
        if (a.ms > 0 && b.ms > 0) {
          raw = 50 * _durSim(a, b) + 40 * name + 10 * size;
        } else {
          raw = 80 * name + 20 * size;
        }
        score = raw.round();
        if (score > 99) score = 99;
      }
      if (score >= _minScore) edges.add(_Edge(x, y, score));
    }

    if (!mounted) return;
    setState(() {
      _vids = vids;
      _edges = edges;
      _scanning = false;
      _scanned = true;
      _progress = '';
    });
  }

  // ---------- 按阈值分组 ----------
  List<_Group> _groups() {
    final parent = <int, int>{};
    int find(int x) {
      var r = x;
      while ((parent[r] ?? r) != r) {
        r = parent[r]!;
      }
      var c = x;
      while ((parent[c] ?? c) != c) {
        final nx = parent[c]!;
        parent[c] = r;
        c = nx;
      }
      return r;
    }

    final live = [
      for (final e in _edges)
        if (e.score >= _threshold && !_dead.contains(e.a) && !_dead.contains(e.b)) e
    ];
    for (final e in live) {
      parent.putIfAbsent(e.a, () => e.a);
      parent.putIfAbsent(e.b, () => e.b);
      final ra = find(e.a), rb = find(e.b);
      if (ra != rb) parent[ra] = rb;
    }
    final members = <int, List<int>>{};
    for (final k in parent.keys) {
      (members[find(k)] ??= []).add(k);
    }
    final maxScore = <int, int>{};
    for (final e in live) {
      final r = find(e.a);
      if (e.score > (maxScore[r] ?? 0)) maxScore[r] = e.score;
    }
    final groups = <_Group>[];
    members.forEach((r, list) {
      list.sort((x, y) {
        final c = _vids[x].anime.addedAt.compareTo(_vids[y].anime.addedAt);
        return c != 0 ? c : _vids[y].size.compareTo(_vids[x].size);
      });
      // 默认保留：最早添加的（并列时取最大的）
      groups.add(_Group(list, maxScore[r] ?? _threshold, list.first));
    });
    int reclaim(_Group g) => g.members
        .where((i) => i != g.keep)
        .fold(0, (s, i) => s + _vids[i].size);
    groups.sort((a, b) {
      final c = b.maxScore.compareTo(a.maxScore);
      return c != 0 ? c : reclaim(b).compareTo(reclaim(a));
    });
    return groups;
  }

  bool _isSelected(_Group g, int i) => _override[i] ?? (i != g.keep);

  // ---------- 删除 ----------
  Future<void> _deleteSelected(List<_Group> groups) async {
    final picked = <int>[];
    var wholeGroups = 0;
    for (final g in groups) {
      final sel = g.members.where((i) => _isSelected(g, i)).toList();
      picked.addAll(sel);
      if (sel.length == g.members.length) wholeGroups++;
    }
    if (picked.isEmpty) return;
    final bytes = picked.fold(0, (s, i) => s + _vids[i].size);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('永久删除这些视频？'),
        content: Text(
          '将从手机上永久删除 ${picked.length} 个视频文件，释放约 ${fmtBytes(bytes)}，无法恢复。'
          '${wholeGroups > 0 ? '\n\n注意：有 $wholeGroups 组的所有视频都被勾选了，这几组会一个都不剩。' : ''}'
          '\n\n如果某部番剧的视频全部被删且没有图片，整部番剧的文件夹也会一并删除。',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true), child: const Text('删除')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _deleting = true);
    final byAnime = <Anime, List<int>>{};
    for (final i in picked) {
      (byAnime[_vids[i].anime] ??= []).add(i);
    }
    final failed = <String>[];
    for (final entry in byAnime.entries) {
      final f = await widget.store
          .deleteEpisodeFiles(entry.key, [for (final i in entry.value) _vids[i].ep]);
      final failedNames = f.toSet();
      for (final i in entry.value) {
        if (!failedNames.contains(_vids[i].ep.name)) _dead.add(i);
      }
      failed.addAll(f);
    }
    if (!mounted) return;
    setState(() => _deleting = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(failed.isEmpty
          ? '已删除 ${picked.length} 个视频'
          : '有 ${failed.length} 个删除失败：${failed.take(3).join('、')}'),
    ));
  }

  // ---------- 界面 ----------
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final groups = _scanned ? _groups() : const <_Group>[];
    var selCount = 0, selBytes = 0;
    for (final g in groups) {
      for (final i in g.members) {
        if (_isSelected(g, i)) {
          selCount++;
          selBytes += _vids[i].size;
        }
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('查找相似视频')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text('相似度阈值', style: theme.textTheme.titleMedium),
                    const Spacer(),
                    Text('$_threshold%',
                        style: theme.textTheme.titleLarge
                            ?.copyWith(color: theme.colorScheme.primary)),
                  ],
                ),
                const SizedBox(height: 2),
                Text(_level(_threshold), style: theme.textTheme.bodyMedium),
                SliderTheme(
                  data: SliderTheme.of(context)
                      .copyWith(showValueIndicator: ShowValueIndicator.always),
                  child: Slider(
                    min: 50,
                    max: 100,
                    divisions: 50,
                    value: _threshold.toDouble(),
                    label: '$_threshold%',
                    onChanged: (v) => setState(() => _threshold = v.round()),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('50%', style: theme.textTheme.bodySmall),
                    Text('100%', style: theme.textTheme.bodySmall),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: (_scanning || _deleting) ? null : _scan,
                    icon: const Icon(Icons.search),
                    label: Text(_scanned ? '重新扫描' : '开始扫描'),
                  ),
                ),
              ],
            ),
          ),
          if (_scanning)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2.5)),
                  const SizedBox(width: 12),
                  Expanded(child: Text(_progress)),
                ],
              ),
            ),
          Expanded(child: _body(theme, groups)),
          if (selCount > 0)
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: theme.colorScheme.error,
                      foregroundColor: theme.colorScheme.onError,
                    ),
                    onPressed: _deleting ? null : () => _deleteSelected(groups),
                    icon: const Icon(Icons.delete_outline),
                    label: Text('删除所选（$selCount 个，释放约 ${fmtBytes(selBytes)}）'),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _body(ThemeData theme, List<_Group> groups) {
    if (_scanning) return const SizedBox.shrink();
    if (!_scanned) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text('点“开始扫描”，按名称、大小、时长找出重复或相似的视频。\n'
              '扫描一次后，拖动阈值只是筛选，不用重新扫描。\n'
              '第一次要先读出所有视频的时长，视频多的话会比较久。',
              textAlign: TextAlign.center),
        ),
      );
    }
    if (groups.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('没有找到相似度 ≥ $_threshold% 的视频，可以把阈值调低再看看。',
              textAlign: TextAlign.center),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
      itemCount: groups.length,
      itemBuilder: (ctx, gi) {
        final g = groups[gi];
        final total = g.members.fold(0, (s, i) => s + _vids[i].size);
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 6),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Text(
                  '${g.members.length} 个视频 · 最高相似度 ${g.maxScore}% · 共 ${fmtBytes(total)}',
                  style: theme.textTheme.titleSmall,
                ),
              ),
              for (final i in g.members)
                CheckboxListTile(
                  dense: true,
                  controlAffinity: ListTileControlAffinity.leading,
                  value: _isSelected(g, i),
                  onChanged: (v) => setState(() => _override[i] = v ?? false),
                  title: Text(_vids[i].ep.name,
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                    '${_vids[i].anime.name}\n'
                    '${fmtBytes(_vids[i].size)}'
                    '${_vids[i].ms > 0 ? ' · ${fmtDuration(_vids[i].ms)}' : ''}'
                    '${i == g.keep ? ' · 默认保留' : ''}',
                  ),
                  secondary: IconButton(
                    tooltip: '打开所在番剧',
                    icon: const Icon(Icons.open_in_new),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DetailPage(
                          store: widget.store,
                          settings: widget.settings,
                          animePath: _vids[i].anime.path,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
