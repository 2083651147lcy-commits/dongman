import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';
import '../settings.dart';
import '../ui/anime_card.dart';
import 'detail_page.dart';

String _ago(int ms) {
  final t = DateTime.fromMillisecondsSinceEpoch(ms);
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return '刚刚';
  if (d.inMinutes < 60) return '${d.inMinutes} 分钟前';
  if (d.inHours < 24) return '${d.inHours} 小时前';
  if (d.inDays < 30) return '${d.inDays} 天前';
  return '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
}

class HistoryPage extends StatelessWidget {
  final LibraryStore store;
  final SettingsStore settings;
  const HistoryPage({super.key, required this.store, required this.settings});

  Future<void> _confirmClear(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('清空历史记录'),
        content: const Text('只清除历史列表，不会删除视频。'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('清空')),
        ],
      ),
    );
    if (ok == true) await store.clearHistory();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([store, settings]),
      builder: (context, _) {
        final list = store.recent(settings.historyLimit);
        final theme = Theme.of(context);
        final bottom = MediaQuery.of(context).padding.bottom;
        return Scaffold(
          appBar: AppBar(
            title: const Text('历史记录'),
            actions: [
              if (list.isNotEmpty)
                IconButton(
                  icon: const Icon(Icons.delete_sweep_outlined),
                  tooltip: '清空历史',
                  onPressed: () => _confirmClear(context),
                ),
            ],
          ),
          body: list.isEmpty
              ? const Center(child: Text('还没有观看记录'))
              : ListView.builder(
                  padding: EdgeInsets.fromLTRB(12, 8, 12, 16 + bottom),
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final Anime a = list[i];
                    final last = a.hasResume ? a.resumeEpisode : null;
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () =>
                            openAnimeDetail(context, store, settings, a),
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Row(
                            children: [
                              ClipRRect(
                                borderRadius:
                                    BorderRadius.circular(settings.coverRadius),
                                child: SizedBox(
                                  width: 64,
                                  height: 64 / settings.ratio,
                                  child: CoverImage(path: a.coverPath),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      a.name,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      last == null
                                          ? _ago(a.lastOpenedAt)
                                          : '上次看到：${last.title} · ${_ago(a.lastOpenedAt)}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: theme.textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                              IconButton(
                                tooltip: '从历史中移除',
                                icon: const Icon(Icons.close),
                                onPressed: () => store.removeFromHistory(a),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}
