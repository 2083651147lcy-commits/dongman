import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';
import '../selection.dart';
import '../settings.dart';
import '../ui/anime_card.dart';
import '../ui/card_grid.dart';
import '../ui/collection_sheet.dart';
import '../ui/delete_flow.dart';
import '../ui/selection_bar.dart';
import 'detail_page.dart';
import 'edit_collection_page.dart';

class CollectionDetailPage extends StatefulWidget {
  final LibraryStore store;
  final SettingsStore settings;
  final String collectionId;
  const CollectionDetailPage({
    super.key,
    required this.store,
    required this.settings,
    required this.collectionId,
  });

  @override
  State<CollectionDetailPage> createState() => _CollectionDetailPageState();
}

class _CollectionDetailPageState extends State<CollectionDetailPage> {
  final SelectionController _sel = SelectionController();

  @override
  void dispose() {
    _sel.dispose();
    super.dispose();
  }

  List<Anime> _selected(Collection c) => widget.store
      .animesOf(c)
      .where((a) => _sel.selected.contains(a.path))
      .toList();

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _remove(Collection c) async {
    final list = _selected(c);
    if (list.isEmpty) return;
    await widget.store.removeFromCollection(c, list);
    _sel.clear();
    _snack('已移出 ${list.length} 部番剧');
  }

  Future<void> _favorite(Collection c) async {
    final list = _selected(c);
    if (list.isEmpty) return;
    final changed = await showCollectionSheet(context, widget.store, list);
    if (changed == true) {
      _sel.clear();
      _snack('已更新收藏夹');
    }
  }

  Future<void> _delete(Collection c) async {
    final list = _selected(c);
    if (await deleteAnimesFlow(context, widget.store, list)) _sel.clear();
  }

  Widget _header(Collection c, List<Anime> list) {
    final theme = Theme.of(context);
    final s = widget.settings;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(s.coverRadius),
                child: SizedBox(
                  width: 110,
                  height: 110 / s.ratio,
                  child: CoverImage(path: widget.store.coverOf(c)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(c.name, style: theme.textTheme.titleLarge),
                    const SizedBox(height: 4),
                    Text('${list.length} 部番剧',
                        style: theme.textTheme.bodyMedium),
                  ],
                ),
              ),
            ],
          ),
          if (c.synopsis.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(c.synopsis.trim()),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    final s = widget.settings;
    return ListenableBuilder(
      listenable: Listenable.merge([store, s, _sel]),
      builder: (context, _) {
        final c = store.collectionById(widget.collectionId);
        if (c == null) {
          return Scaffold(
            appBar: AppBar(),
            body: const Center(child: Text('这个收藏夹已不存在')),
          );
        }
        final list = store.animesOf(c);

        final PreferredSizeWidget appBar = _sel.active
            ? AppBar(
                leading: IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: _sel.clear,
                ),
                title: Text('已选 ${_sel.selected.length} 项'),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.select_all),
                    tooltip: '全选',
                    onPressed: () => _sel.addAll(list.map((a) => a.path)),
                  ),
                ],
              )
            : AppBar(
                title: Text(c.name, overflow: TextOverflow.ellipsis),
                actions: [
                  IconButton(
                    icon: const Icon(Icons.edit_outlined),
                    tooltip: '编辑收藏夹',
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            EditCollectionPage(store: store, collectionId: c.id),
                      ),
                    ),
                  ),
                ],
              );

        return PopScope(
          canPop: !_sel.active,
          onPopInvokedWithResult: (didPop, _) {
            if (!didPop) _sel.clear();
          },
          child: Scaffold(
            appBar: appBar,
            body: list.isEmpty
                ? ListView(
                    padding: const EdgeInsets.only(top: 8),
                    children: [
                      _header(c, list),
                      const Padding(
                        padding: EdgeInsets.all(32),
                        child: Center(
                          child: Text(
                            '收藏夹是空的。\n在主页长按番剧后点“收藏”来添加。',
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    ],
                  )
                : CardGrid(
                    settings: s,
                    itemCount: list.length,
                    header: _header(c, list),
                    itemBuilder: (ctx, i) {
                      final a = list[i];
                      return AnimeCard(
                        title: a.name,
                        epCount: a.episodes.length,
                        tags: a.tags,
                        coverPath: a.coverPath,
                        settings: s,
                        selectionMode: _sel.active,
                        selected: _sel.isSelected(a.path),
                        onTap: () => _sel.active
                            ? _sel.toggle(a.path)
                            : openAnimeDetail(context, store, s, a),
                        onLongPress: () => _sel.toggle(a.path),
                      );
                    },
                  ),
            bottomNavigationBar: _sel.active
                ? SelectionBar(actions: [
                    SelectionAction(
                      icon: Icons.bookmark_remove_outlined,
                      label: '移出收藏夹',
                      onTap: () => _remove(c),
                    ),
                    SelectionAction(
                      icon: Icons.favorite_border,
                      label: '收藏',
                      onTap: () => _favorite(c),
                    ),
                    SelectionAction(
                      icon: Icons.delete_outline,
                      label: '删除',
                      danger: true,
                      onTap: () => _delete(c),
                    ),
                    SelectionAction(
                      icon: Icons.close,
                      label: '取消',
                      onTap: _sel.clear,
                    ),
                  ])
                : null,
          ),
        );
      },
    );
  }
}
