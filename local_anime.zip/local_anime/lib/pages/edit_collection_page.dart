import 'package:flutter/material.dart';

import '../library.dart';
import '../models.dart';
import '../ui/second_picker.dart';

class EditCollectionPage extends StatefulWidget {
  final LibraryStore store;
  final String collectionId;
  const EditCollectionPage({
    super.key,
    required this.store,
    required this.collectionId,
  });

  @override
  State<EditCollectionPage> createState() => _EditCollectionPageState();
}

class _EditCollectionPageState extends State<EditCollectionPage> {
  late final TextEditingController _name;
  late final TextEditingController _synopsis;
  String? _coverUid;
  int _coverMs = 0;

  Collection? get _c => widget.store.collectionById(widget.collectionId);

  @override
  void initState() {
    super.initState();
    final c = _c;
    _name = TextEditingController(text: c?.name ?? '');
    _synopsis = TextEditingController(text: c?.synopsis ?? '');
    _coverUid = c?.coverUid;
    _coverMs = c?.coverMs ?? 0;
  }

  @override
  void dispose() {
    _name.dispose();
    _synopsis.dispose();
    super.dispose();
  }

  String _coverText() {
    if (_coverMs > 0 && _coverUid != null) {
      final a = widget.store.byUid(_coverUid!);
      if (a != null) return '《${a.name}》${fmtMinSec(_coverMs ~/ 1000)}';
    }
    return '自动（用里面第一部番剧的封面）';
  }

  /// 这部番剧第一集的时长（毫秒）；没读到返回 0
  int _firstEpMs(List<Anime> animes, String uid) {
    for (final a in animes) {
      if (a.uid == uid && a.episodes.isNotEmpty) {
        return a.durations[a.relOf(a.episodes.first)] ?? 0;
      }
    }
    return 0;
  }

  /// 分钟上限：视频有多长就到多少分钟；没读到时长按 60
  int _maxMinOf(List<Anime> animes, String uid) {
    final ms = _firstEpMs(animes, uid);
    return ms > 0 ? ms ~/ 60000 : 60;
  }

  int _clampSec(List<Anime> animes, String uid, int sec) {
    final ms = _firstEpMs(animes, uid);
    return ms > 0 && sec > ms ~/ 1000 ? ms ~/ 1000 : sec;
  }

  Future<void> _pickCover() async {
    final c = _c;
    if (c == null) return;
    final animes = widget.store.animesOf(c);
    if (animes.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('收藏夹里还没有番剧')));
      return;
    }
    var uid = animes.any((a) => a.uid == _coverUid) ? _coverUid! : animes.first.uid;
    var sec = _coverMs > 0
        ? _coverMs ~/ 1000
        : widget.store.settings.coverSecond;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('截取封面'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('选一部番剧，截取它第一集的某一秒作封面'),
              const SizedBox(height: 12),
              DropdownButton<String>(
                isExpanded: true,
                value: uid,
                items: [
                  for (final a in animes)
                    DropdownMenuItem(
                      value: a.uid,
                      child: Text(a.name, overflow: TextOverflow.ellipsis),
                    ),
                ],
                onChanged: (v) => setLocal(() => uid = v ?? uid),
              ),
              const SizedBox(height: 8),
              const Text('截取第几秒'),
              // 固定宽高：滚轮控件不支持 AlertDialog 的自适应尺寸计算
              SizedBox(
                width: 260,
                height: 150,
                child: MinSecWheel(
                  key: ValueKey(uid),
                  initialSeconds: _clampSec(animes, uid, sec),
                  maxMinutes: _maxMinOf(animes, uid),
                  haptic: widget.store.settings.navHaptic,
                  onChanged: (v) => sec = v,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('确定')),
          ],
        ),
      ),
    );
    if (ok == true && sec >= 0) {
      setState(() {
        _coverUid = uid;
        final fixed = _clampSec(animes, uid, sec);
        _coverMs = (fixed < 1 ? 1 : fixed) * 1000;
      });
    }
  }

  Future<void> _save() async {
    final c = _c;
    if (c == null) return;
    final name = _name.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('请先填写名称')));
      return;
    }
    c.name = name;
    c.synopsis = _synopsis.text.trim();
    c.coverUid = _coverMs > 0 ? _coverUid : null;
    c.coverMs = _coverMs > 0 ? _coverMs : 0;
    await widget.store.updateCollection(c);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('编辑收藏夹'),
        actions: [TextButton(onPressed: _save, child: const Text('保存'))],
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(
            16, 16, 16, 16 + MediaQuery.of(context).padding.bottom),
        children: [
          TextField(
            controller: _name,
            decoration: const InputDecoration(
              labelText: '名称 *',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _synopsis,
            minLines: 3,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: '简介',
              alignLabelWithHint: true,
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: ListTile(
              title: const Text('封面'),
              subtitle: Text(_coverText()),
              trailing: const Icon(Icons.chevron_right),
              onTap: _pickCover,
            ),
          ),
          if (_coverMs > 0)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                onPressed: () => setState(() {
                  _coverUid = null;
                  _coverMs = 0;
                }),
                child: const Text('恢复自动封面'),
              ),
            ),
        ],
      ),
    );
  }
}
